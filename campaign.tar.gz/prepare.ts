import { readFileSync, writeFileSync, mkdirSync, readdirSync, copyFileSync } from 'node:fs'
import { execFileSync, spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { join } from 'node:path'
import { parseOptions } from '/workspace/trident/unified/options.ts'
import { communityCandidate } from '/workspace/trident/unified/project-update.ts'
import { prepareCommunity, verifyProvidedCommunityArtifact } from '/workspace/trident/unified/community.ts'
import { prepareCommunityBrowsers } from '/workspace/trident/unified/community-browser.ts'
const root='/workspace/am-zm-2026-10-29', trident='/workspace/trident', zm=root+'/zombie'
const digest=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex')
const git=(cwd:string)=>execFileSync('git',['rev-parse','HEAD'],{cwd,encoding:'utf8'}).trim()
const projects=[{id:'adewale/agentic-mermaid',source:'/workspace/agentic-mermaid',short:'am'},{id:'dfadler/zombie-mermaid',source:zm,short:'zm'}]
const catalog=JSON.parse(readFileSync(trident+'/catalog/mermaid-community.json','utf8'))
catalog.nodes=catalog.nodes.filter((n:any)=>projects.some(p=>p.id===n.id));catalog.edges=catalog.edges.filter((e:any)=>catalog.nodes.some((n:any)=>n.id===e.from)&&catalog.nodes.some((n:any)=>n.id===e.to))
for(const n of catalog.nodes){const p=projects.find(p=>p.id===n.id)!;n.head=git(p.source);n.benchmark.outputs=['svg','terminal'];delete n.benchmark.cli}
// Both are explicit source candidates; catalog release identities remain in their original fields.
const catalogFile=root+'/catalog.json';writeFileSync(catalogFile,JSON.stringify(catalog,null,2)+'\n')
process.env.AM_COMMUNITY_CACHE=root+'/cache'
const prepared:any[]=[], browsers:any[]=[], receipts:any[]=[]
for(const p of projects){
 const out=root+'/preparation/'+p.short;mkdirSync(out,{recursive:true})
 const options=parseOptions(['--out',out,'--projects',p.id,'--community-catalog',catalogFile,'--profile','full','--rounds','5','--executable','/usr/bin/chromium','--community-outputs','svg,terminal'])
 let candidate:any
 if(p.short==='zm'){
  const env={...process.env,PNPM_HOME:'/workspace/.cloud-tools/pnpm-home',XDG_DATA_HOME:'/workspace/.local/share'}
  const paths=['packages/core','packages/mermaid-parser','packages/svg-renderer','packages/ascii-renderer','packages/mcp','.']
  for(const path of paths){const r=spawnSync('npx',['--yes','pnpm@11.13.1','pack','--pack-destination',root+'/packs','--json'],{cwd:join(zm,path),env,encoding:'utf8',timeout:120000});writeFileSync(out+'/'+(path==='.'?'root':path.split('/')[1])+'-pack.log',r.stdout+r.stderr);if(r.status!==0)throw Error('ZM package packing failed: '+path)}
  const version=JSON.parse(readFileSync(zm+'/package.json','utf8')).version, tarball=root+'/packs/zombie-mermaid-'+version+'.tgz',sha256=digest(tarball)
  candidate=communityCandidate({tarball,sha256},options)
  // Install every source workspace package together, using public packed archives.
  const prefix=root+'/cache/candidates/zombie-mermaid@'+sha256;mkdirSync(prefix,{recursive:true});copyFileSync(tarball,prefix+'/candidate.tgz')
  const archives=readdirSync(root+'/packs').filter(x=>x.endsWith('.tgz')).map(x=>root+'/packs/'+x)
  const install=spawnSync('npm',['install','--prefix',prefix,'--ignore-scripts','--no-audit','--no-fund',prefix+'/candidate.tgz',...archives.filter(x=>x!==tarball)],{encoding:'utf8',timeout:300000})
  writeFileSync(out+'/workspace-install.log',install.stdout+install.stderr);if(install.status!==0)throw Error('ZM source package installation failed')
  receipts.push({project:p.id,source:p.source,revision:git(p.source),archives:archives.map(path=>({path,sha256:digest(path)})),installation:'All six public source archives installed together; no published workspace substitution.'})
 } else candidate=communityCandidate({directory:p.source},options)
 options.communityCandidate=candidate
 const peers=await prepareCommunity(options);if(peers.length!==1||!peers[0]!.artifact)throw Error(JSON.stringify(peers))
 verifyProvidedCommunityArtifact(peers[0]!.artifact!)
 const browser=await prepareCommunityBrowsers(peers,options);if(browser.length!==1||browser[0]!.browserStatus!=='prepared')throw Error(JSON.stringify(browser))
 prepared.push(...peers);browsers.push(...browser)
 receipts.push({project:p.id,source:p.source,revision:git(p.source),candidate,artifact:peers[0]!.artifact,sourceStatus:execFileSync('git',['status','--porcelain'],{cwd:p.source,encoding:'utf8'})})
 console.log('Prepared '+p.id+' '+peers[0]!.artifact!.version)
}
writeFileSync(root+'/prepared.json',JSON.stringify(prepared,null,2)+'\n');writeFileSync(root+'/browsers.json',JSON.stringify(browsers,null,2)+'\n')
writeFileSync(root+'/artifacts.json',JSON.stringify({preparedAt:new Date().toISOString(),trident:git(trident),selection:'Current main source candidates for both projects',receipts},null,2)+'\n')
