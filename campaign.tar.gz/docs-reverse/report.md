# Official documentation SVG return

548 occurrences; 546 distinct inputs; 34 pinned syntax pages.

| Project | Round | SVG returned | Failed | Unexecuted |
|---|---|---|---|---|
| dfadler/zombie-mermaid | 1 | 245 | 303 | 0 |
| dfadler/zombie-mermaid | 2 | 245 | 303 | 0 |
| dfadler/zombie-mermaid | 3 | 245 | 303 | 0 |
| dfadler/zombie-mermaid | 4 | 245 | 303 | 0 |
| dfadler/zombie-mermaid | 5 | 245 | 303 | 0 |
| adewale/agentic-mermaid | 1 | 441 | 107 | 0 |
| adewale/agentic-mermaid | 2 | 441 | 107 | 0 |
| adewale/agentic-mermaid | 3 | 441 | 107 | 0 |
| adewale/agentic-mermaid | 4 | 441 | 107 | 0 |
| adewale/agentic-mermaid | 5 | 441 | 107 | 0 |

A returned SVG is weak compatibility evidence. Timing samples are in result.json; compare only pairwise common successful inputs. No overall speed rank or calibrated performance pass.
