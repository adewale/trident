import json,math,statistics,collections,hashlib
from pathlib import Path
R=Path('/workspace/am-zm-2026-10-29')
projects=['adewale/agentic-mermaid','dfadler/zombie-mermaid']
names={projects[0]:'Agentic Mermaid',projects[1]:'Zombie Mermaid'}
load=lambda n:json.loads((R/n).read_text())
percent=lambda n,d:round(100*n/d,3)
docs=[load('docs-result.json'),load('docs-reverse-result.json')]
inv=load('docs/inventory.json');N=inv['occurrences']
byproject={p:{block:{case['id']:[] for case in inv['cases']} for block in range(2)}for p in projects}
coverage=[]
for p in projects:
 outcomes=[]
 for block,result in enumerate(docs):
  rr=[o for o in result['observations'] if o['metrics'].get('project')==p and o['operation']=='render']
  assert len(rr)==N*5
  for round_id in range(1,6):
   rows=[o for o in rr if o['metrics']['round']==round_id];assert len(rows)==N and {o['caseId']for o in rows}=={c['id']for c in inv['cases']}
   counts=dict(collections.Counter(o['status'] for o in rows));outcomes.append({'block':block,'round':round_id,**counts})
  for o in rr:byproject[p][block][o['caseId']].append(o)
 accepted=[c for c in byproject[p][0] if all(o['status']=='passed' for block in range(2) for o in byproject[p][block][c])]
 same_counts=len({tuple(sorted((k,v)for k,v in o.items()if k not in ('block','round')))for o in outcomes})==1
 errors=collections.Counter(o.get('detail','') for items in byproject[p][0].values() for o in items if o['status']!='passed')
 coverage.append({'project':p,'returnedEveryRound':len(accepted),'planned':N,'rate':percent(len(accepted),N),'countsStable':same_counts,'rounds':outcomes,'errorExamples':errors.most_common(5)})
common=[c['id']for c in inv['cases']if all(len(byproject[p][b][c['id']])==5 and all(o['status']=='passed'for o in byproject[p][b][c['id']])for p in projects for b in range(2))]
assert common
cost=[]
for p in projects:
 blockstats=[]
 for b in range(2):
  samples=[statistics.median([o['samplesMs'][0]for o in byproject[p][b][c]])for c in common]
  blockstats.append({'block':b,'sumInputMediansMs':sum(samples),'medianInputMedianMs':statistics.median(samples),'p95InputMedianMs':sorted(samples)[math.ceil(.95*len(samples))-1]})
 medians=[statistics.median([o['samplesMs'][0] for b in range(2)for o in byproject[p][b][c]])for c in common]
 cost.append({'project':p,'commonOccurrences':len(common),'samplesPerInput':10,'sumInputMediansMs':sum(medians),'medianInputMedianMs':statistics.median(medians),'p95InputMedianMs':sorted(medians)[math.ceil(.95*len(medians))-1],'geometricMeanInputMedianMs':math.exp(statistics.mean(math.log(v) for v in medians))if min(medians)>0 else None,'zeroOrNegativeMedians':sum(v<=0 for v in medians),'blocks':blockstats,'qualification':'Descriptive only; two project-order blocks, no independent A/A performance qualification; SVG-return success does not establish equal paint.'})
fid=load('fidelity-result.json');meaning=[]
for p in projects:
 surfaces={}
 for surface in ['browser-owned-ink','browser-public-api','native-public-api']:
  rows=[o for o in fid['observations']if o['metrics'].get('implementation')==p and o['surface']==surface]
  assert len({o['caseId']for o in rows})==len(rows)
  surfaces[surface]={'planned':len(rows),**dict(collections.Counter(o['status']for o in rows))}
 failures=[o for o in fid['observations']if o['metrics'].get('implementation')==p and o['status']=='failed']
 meaning.append({'project':p,'surfaces':surfaces,'failedChecks':failures})
sets=[{o['caseId']for o in fid['observations']if o['metrics'].get('implementation')==p and o['surface']=='browser-owned-ink'}for p in projects]
assert sets[0]==sets[1]
compat=[]
for p,short in zip(projects,['am','zm']):
 x=load('community-'+short+'-corrected-result.json');rows=x['observations']
 groups=[]
 for surface,format,mode,operation in sorted({(o['surface'],o['format'],o['mode'],o['operation'])for o in rows}):
  rr=[o for o in rows if(o['surface'],o['format'],o['mode'],o['operation'])==(surface,format,mode,operation)]
  groups.append({'surface':surface,'format':format,'mode':mode,'operation':operation,'observations':len(rr),'uniqueInputs':len({o['caseId']for o in rr}),**dict(collections.Counter(o['status']for o in rr))})
 compat.append({'project':p,'totalObservations':len(rows),'groups':groups,'setupFailures':[o for o in rows if o['caseId']=='*']})
art=load('artifacts.json')
summary={'projects':projects,'names':names,'artifacts':art,'measuredAt':'2026-10-29','documentation':coverage,'renderCost':cost,'meaning':meaning,'compatibility':compat,'commonDocumentationCaseIds':common,'fidelityCases':len(fid['selectedCaseIds']),'notes':['Both freshly pulled main branches built through their own canonical build commands and packed as explicit source candidates.','Zombie workspace package archives were installed together, preserving the actual source dependency closure.','Only corrected community attempts are summarized; the initial missing-candidate-selector setup failures remain retained.','Two five-round docs blocks use opposite project orders. This is not an A/A-calibrated performance campaign.','Public model/replay adapters are absent for Zombie, so those optional APIs earn no comparative score.','No full portable scaling/release qualification was run.']}
(R/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('DOCS',json.dumps([{k:x[k]for k in ['project','returnedEveryRound','planned','rate','countsStable']}for x in coverage]))
print('COST',json.dumps(cost,indent=2))
print('MEANING',json.dumps([{'project':x['project'],'surfaces':x['surfaces']}for x in meaning],indent=2))
print('COMPAT',json.dumps(compat,indent=2))
