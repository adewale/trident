import {readFileSync,writeFileSync}from'node:fs';
const root='/workspace/am-zm-2026-10-29/',read=p=>JSON.parse(readFileSync(root+p));
const summary=read('summary.json'),data=[read('docs-result.json'),read('docs-reverse-result.json')];
const median=values=>{const a=[...values].sort((x,y)=>x-y),i=Math.floor(a.length/2);return a.length%2?a[i]:(a[i-1]+a[i])/2};
const checks=[];
for(const p of summary.projects){
 const rows=data.flatMap(x=>x.observations).filter(x=>x.metrics.project===p&&x.operation==='render');
 const groups=new Map();for(const row of rows){const g=groups.get(row.caseId)??[];g.push(row);groups.set(row.caseId,g)}
 const complete=[...groups].filter(([id,rows])=>rows.length===10&&rows.every(r=>r.status==='passed')).map(([id])=>id);
 if(complete.length!==summary.documentation.find(x=>x.project===p).returnedEveryRound)throw Error('coverage disagreement');
 const costs=summary.commonDocumentationCaseIds.map(id=>median(groups.get(id).map(r=>r.samplesMs[0])));
 const sum=costs.reduce((a,b)=>a+b,0),expected=summary.renderCost.find(x=>x.project===p);
 if(Math.abs(sum-expected.sumInputMediansMs)>1e-8||Math.abs(median(costs)-expected.medianInputMedianMs)>1e-8)throw Error('cost disagreement');
 checks.push({project:p,coverage:complete.length,commonCosts:costs.length,sum,median:median(costs),verified:true});
}
writeFileSync(root+'independent-reduction.json',JSON.stringify(checks,null,2)+'\n');console.log(JSON.stringify(checks));
