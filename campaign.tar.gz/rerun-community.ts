import { readFileSync, writeFileSync } from 'node:fs'
import { parseOptions } from '/workspace/trident/unified/options.ts'
import { runCommunitySuite } from '/workspace/trident/unified/community.ts'
const root='/workspace/am-zm-2026-10-29', prepared=JSON.parse(readFileSync(root+'/prepared.json','utf8'))
process.env.AM_COMMUNITY_CACHE=root+'/cache'
const campaign=JSON.parse(readFileSync(root+'/campaign.json','utf8'))
for(const peer of prepared){
 const project=peer.node.id,short=project.includes('agentic')?'am':'zm',out=root+'/community-'+short+'-corrected'
 const options=parseOptions(['--out',out,'--projects',project,'--community-catalog',root+'/catalog.json','--profile','full','--rounds','5','--executable','/usr/bin/chromium','--community-outputs','svg,terminal'])
 options.communityPreparedFile=root+'/prepared-'+short+'.json';options.communityBrowserPreparedFile=root+'/browsers.json'
 options.communityCandidate={project,...peer.artifact.candidate}
 const startedAt=new Date().toISOString();console.log(startedAt+' START corrected community '+project)
 try{const value=await runCommunitySuite(options);writeFileSync(root+'/community-'+short+'-corrected-result.json',JSON.stringify(value)+'\n');campaign.results.push({suite:'community',project,status:value.status,startedAt,finishedAt:new Date().toISOString(),observations:value.observations.length,out,correction:'Explicit candidate project selector; prior Node attempt retained, not combined.',gaps:value.gaps})}
 catch(error){campaign.results.push({suite:'community',project,status:'blocked',startedAt,finishedAt:new Date().toISOString(),out,error:String(error),stack:(error as Error).stack})}
 campaign.updatedAt=new Date().toISOString();writeFileSync(root+'/campaign.json',JSON.stringify(campaign,null,2)+'\n');console.log('END '+project+' '+campaign.results.at(-1).status)
}
