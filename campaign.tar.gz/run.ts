import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { parseOptions } from '/workspace/trident/unified/options.ts'
import { runDocsBenchmark } from '/workspace/trident/unified/docs-benchmark.ts'
import { runCommunityFidelitySuite } from '/workspace/trident/fidelity/community.ts'
import { runCommunitySuite } from '/workspace/trident/unified/community.ts'
const root='/workspace/am-zm-2026-10-29'
const prepared=JSON.parse(readFileSync(root+'/prepared.json','utf8'))
const projects=prepared.map((p:any)=>p.node.id), results:any[]=[]
process.env.AM_COMMUNITY_CACHE=root+'/cache'
const base=parseOptions(['--out',root+'/campaign','--projects',projects.join(','),'--community-catalog',root+'/catalog.json','--profile','full','--rounds','5','--executable','/usr/bin/chromium','--community-outputs','svg,terminal'])
base.communityBrowserPreparedFile=root+'/browsers.json'
base.benchmarkRecordStore=root+'/records'
base.benchmarkForce=true
const save=()=>writeFileSync(root+'/campaign.json',JSON.stringify({startedAt,updatedAt:new Date().toISOString(),projects,selection:'Current main source candidates for both projects',profile:'full',rounds:5,requestedSuites:['docs','fidelity','community'],results},null,2)+'\n')
const startedAt=new Date().toISOString();save()
const collect=async(suite:string,project:string|undefined,run:()=>Promise<any>)=>{
 const t=new Date().toISOString();console.log(t+' START '+suite+' '+(project??'both'))
 try{const result=await run();writeFileSync(root+'/'+suite+(project?'-'+(project.includes('agentic')?'am':'zm'):'')+'-result.json',JSON.stringify(result)+'\n');results.push({suite,project,status:result.status,startedAt:t,finishedAt:new Date().toISOString(),observations:result.observations?.length??null,gaps:result.gaps})}
 catch(error){results.push({suite,project,status:'blocked',startedAt:t,finishedAt:new Date().toISOString(),error:String(error),stack:(error as Error).stack})}
 save();console.log(new Date().toISOString()+' END '+suite+' '+(project??'both')+' '+results.at(-1).status)
}
await collect('docs',undefined,()=>runDocsBenchmark({...base,out:root+'/docs'}))
await collect('fidelity',undefined,()=>runCommunityFidelitySuite({...base,out:root+'/fidelity',rounds:1,communityFidelityPng:'basic-families'}))
for(const peer of prepared){
 const short=peer.node.id.includes('agentic')?'am':'zm',out=root+'/community-'+short
 mkdirSync(out,{recursive:true})
 const one=root+'/prepared-'+short+'.json';writeFileSync(one,JSON.stringify([peer],null,2)+'\n')
 await collect('community',peer.node.id,()=>runCommunitySuite({...base,out,communityProjects:[peer.node.id],communityPreparedFile:one,communityCandidate:peer.artifact.candidate}))
}
console.log('COMPLETED '+root+'/campaign.json')
