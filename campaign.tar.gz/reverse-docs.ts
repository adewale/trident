import { readFileSync,writeFileSync } from 'node:fs'
import { parseOptions } from '/workspace/trident/unified/options.ts'
import { runDocsBenchmark } from '/workspace/trident/unified/docs-benchmark.ts'
const root='/workspace/am-zm-2026-10-29',browsers=JSON.parse(readFileSync(root+'/browsers.json','utf8')).reverse(),file=root+'/browsers-reverse.json'
writeFileSync(file,JSON.stringify(browsers,null,2)+'\n')
const options=parseOptions(['--out',root+'/docs-reverse','--projects',browsers.map((x:any)=>x.node.id).join(','),'--community-catalog',root+'/catalog.json','--profile','full','--rounds','5','--executable','/usr/bin/chromium'])
options.communityBrowserPreparedFile=file
const value=await runDocsBenchmark(options);writeFileSync(root+'/docs-reverse-result.json',JSON.stringify(value)+'\n')
const campaign=JSON.parse(readFileSync(root+'/campaign.json','utf8'));campaign.results.push({suite:'docs',status:value.status,out:options.out,startedAt:value.startedAt,finishedAt:value.finishedAt,observations:value.observations.length,scope:'Same artifacts and protocol, reversed project order; separate timing block.'});campaign.updatedAt=new Date().toISOString();writeFileSync(root+'/campaign.json',JSON.stringify(campaign,null,2)+'\n')
console.log('DONE reversed documentation block')
