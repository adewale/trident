import { runDocsBenchmark } from '/workspace/trident/unified/docs-benchmark.ts'
import { writeFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
const directory = '/workspace/trident-benchmark-repair-2026-10-30'
const options = {
 root: '/workspace/trident', harnessRoot: '/workspace/trident', out: directory + '/docs', profile: 'full' as const, rounds: 1,
 nodeExecutable: execFileSync('which',['node'],{encoding:'utf8'}).trim(), executable: '/usr/bin/chromium',
 communityBrowserPreparedFile: '/workspace/trident-ecosystem-b0-2026-10-30/campaign/preparation/community-browser-prepared.json',
 communityProjects: ['mermaid-js/mermaid','obsidianmd/pele','adewale/agentic-mermaid','lukilabs/beautiful-mermaid','sandyyst/dsh-plugin-mermaid-gb-svg'],
 collectionDeadline: Date.now()+30*60*1000,
}
writeFileSync(directory+'/docs-invocation.json',JSON.stringify({source:execFileSync('git',['rev-parse','HEAD'],{cwd:options.root,encoding:'utf8'}).trim(),createdAt:new Date().toISOString(),options,scope:'One full-inventory correctness collection with retained SVG witnesses; descriptive clocks are not performance qualification. No artifact acquisition or repeated timing campaign.'},null,2)+'\n')
const result = await runDocsBenchmark(options)
console.log(JSON.stringify({status:result.status,observations:result.observations.length,out:options.out}))
