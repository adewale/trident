import { expandedFidelityCases } from '/workspace/trident/fidelity/cases.ts'
import { runCommunityFidelitySuite } from '/workspace/trident/fidelity/community.ts'
import { writeFileSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
const directory = '/workspace/trident-benchmark-repair-2026-10-30'
const extra = ['features:flowchart:owned-style-effect', 'features:flowchart:nesting-parallel-unicode', 'features:flowchart:two-ended-and-undirected', 'features:flowchart:font-size-reset', 'features:flowchart:controlled-image']
const cases = expandedFidelityCases().filter(item => /^meaning:family:[^:]+$/.test(item.id) || extra.includes(item.id))
if (cases.length !== 30) throw Error('Qualification selection must contain 30 declared cases')
const options = {
 root: '/workspace/trident', harnessRoot: '/workspace/trident', out: directory + '/features', profile: 'full' as const, rounds: 1,
 nodeExecutable: execFileSync('which',['node'],{encoding:'utf8'}).trim(), executable: '/usr/bin/chromium',
 communityCatalogFile: '/workspace/trident-ecosystem-b0-2026-10-30/campaign/preparation/catalog.json',
 communityBrowserPreparedFile: '/workspace/trident-ecosystem-b0-2026-10-30/campaign/preparation/community-browser-prepared.json',
 communityProjects: ['mermaid-js/mermaid','obsidianmd/pele','adewale/agentic-mermaid','lukilabs/beautiful-mermaid','sandyyst/dsh-plugin-mermaid-gb-svg'],
 fidelityCaseIds: cases.map(item=>item.id), communityFidelityPng: 'none' as const,
 benchmarkRecordStore: directory + '/feature-records', collectionDeadline: Date.now()+30*60*1000,
}
writeFileSync(directory+'/feature-invocation.json',JSON.stringify({source:execFileSync('git',['rev-parse','HEAD'],{cwd:options.root,encoding:'utf8'}).trim(),createdAt:new Date().toISOString(),options,scope:'One untimed qualification pass; frozen artifacts, no acquisition, no throughput or full-corpus claims'},null,2)+'\n')
const result = await runCommunityFidelitySuite(options)
console.log(JSON.stringify({status:result.status,observations:result.observations.length,out:options.out}))
