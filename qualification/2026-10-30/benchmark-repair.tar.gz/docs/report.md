# Official documentation SVG return

548 occurrences; 546 distinct inputs; 34 pinned syntax pages.

| Project | Round | SVG returned | Failed | Unexecuted |
|---|---|---|---|---|
| adewale/agentic-mermaid | 1 | 441 | 107 | 0 |
| lukilabs/beautiful-mermaid | 1 | 231 | 317 | 0 |
| obsidianmd/pele | 1 | 532 | 16 | 0 |
| sandyyst/dsh-plugin-mermaid-gb-svg | 1 | 548 | 0 | 0 |
| mermaid-js/mermaid | 1 | 547 | 1 | 0 |

A returned SVG is weak compatibility evidence. Timing samples are in result.json; compare only pairwise common successful inputs. No overall speed rank or calibrated performance pass.
