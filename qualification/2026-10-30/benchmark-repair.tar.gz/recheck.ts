import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { resolve, relative, join } from 'node:path'
import { gunzipSync } from 'node:zlib'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
const base=resolve(process.argv[2] ?? '/workspace/trident-benchmark-repair-2026-10-30'), root=resolve(process.argv[3] ?? '/workspace/trident')
const { expandedFidelityCases } = await import(root+'/fidelity/cases.ts')
const { inspectFidelityPaint } = await import(root+'/fidelity/paint.ts')
const { inspectQuantitativePaint } = await import(root+'/fidelity/paint-values.ts')
const { assessSvgCases, summarizeSvgCases } = await import(root+'/fidelity/svg-assessment.ts')
const { fidelityCriteriaProtocol } = await import(root+'/fidelity/protocol.ts')
const { inspectTerminalMeaning } = await import(root+'/fidelity/terminal.ts')
const { admitDocsReviews, reviewedDocsCase, assessDocsDrawing } = await import(root+'/unified/docs-drawings.ts')
const { docsArtifactServer } = await import(root+'/unified/docs-benchmark.ts')
const { qualifyOutput } = await import(root+'/unified/qualification.ts')
const { readBenchmarkDocument } = await import(root+'/portable/project-records.ts')
const { protocolIdentity } = await import(root+'/unified/protocol-identity.ts')
const source=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(), date=new Date().toISOString(), digest=(b:Buffer|string)=>createHash('sha256').update(b).digest('hex')
const relocate=(path:string)=>path.replace('/workspace/trident-benchmark-repair-2026-10-30/',base+'/')
const require=createRequire(root+'/package.json'),{chromium}=require('playwright')
const server=docsArtifactServer(root);await new Promise<void>(done=>server.listen(0,'127.0.0.1',done));const origin='http://127.0.0.1:'+(server.address() as any).port
const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium'}),context=await browser.newContext({viewport:{width:1400,height:1000}}),page=await context.newPage();await page.goto(origin+'/observer')
const inputs:any[]=[]
async function inspect(svg:string,testCase:any){
 await page.setContent(svg)
 const paint=await page.evaluate(inspectFidelityPaint,{family:testCase.family,expected:testCase.expected,paint:testCase.paint})
 const quantitative=await page.evaluate(inspectQuantitativePaint,{family:testCase.family,expected:testCase.expected,source:testCase.source,nodes:paint.nodes})
 return [...paint.checks,...quantitative]
}
try{
 const initial:any=readBenchmarkDocument(base+'/features/community-fidelity-report.json'),follow:any=readBenchmarkDocument(base+'/configuration/community-fidelity-report.json')
 const selected=expandedFidelityCases().filter(c=>initial.selectedCaseIds.includes(c.id)),originalHash=digest(readFileSync(base+'/features/community-fidelity-report.json'))
 let observations=structuredClone(initial.observations)
 const checks:any[]=[]
 for(const assessment of initial.svgAssessments){
  const project=assessment.project,directory=base+'/features/'+Buffer.from(project).toString('base64url')
  const artifact=initial.artifacts.map(relocate).find((p:string)=>p.startsWith(directory+'/')&&p.endsWith('community-fidelity-cases.json'))
  if(!artifact)throw Error('Missing owning SVG receipt '+project)
  const receipt=JSON.parse(readFileSync(artifact,'utf8'))
  for(const entry of receipt.rows){
   if(!entry.svgEvidence)continue
   if(!observations.some((row:any)=>row.metrics?.implementation===project&&row.metrics?.authoredCase===entry.caseId&&row.operation.startsWith('painted-group:')&&row.status==='blocked'))continue
   const path=resolve(relocate(entry.svgEvidence.path));if(!path.startsWith(directory+'/'))throw Error('SVG witness outside its owner')
   const svg=gunzipSync(readFileSync(path)).toString('utf8');if(digest(svg)!==entry.svgEvidence.sha256)throw Error('Changed retained SVG')
   const testCase=selected.find(c=>c.id===entry.caseId)!;const result=await inspect(svg,testCase)
   inputs.push({path:relative(base,path),sha256:entry.svgEvidence.sha256,caseId:entry.caseId,project})
   for(const row of observations.filter((r:any)=>r.metrics?.implementation===project&&r.metrics?.authoredCase===entry.caseId&&r.surface==='browser-owned-ink'&&r.operation.startsWith('painted-group:'))){
    const item=result.find((c:any)=>c.criterion===row.operation);if(!item)throw Error('Recheck omitted a declared group criterion')
    const before=row.status;row.status=item.status==='unavailable'?'blocked':item.status;row.detail=JSON.stringify(item);row.metrics={...row.metrics,recheckedAt:date,observerSource:source};checks.push({project,caseId:entry.caseId,criterion:row.operation,before,after:row.status})
   }
  }
 }
 // Replace only the incorrectly invoked configuration case, with the separately
 // measured and sealed two-size follow-up. Other renderer outputs are untouched.
 observations=observations.filter((r:any)=>r.metrics?.authoredCase!=='features:flowchart:font-size-reset')
 observations.push(...follow.observations.filter((r:any)=>r.metrics?.authoredCase==='features:flowchart:font-size-reset'))
 const svgAssessments=initial.svgAssessments.map((a:any)=>{const cases=assessSvgCases(selected,observations.filter((r:any)=>r.metrics?.implementation===a.project));return{project:a.project,version:a.version,...summarizeSvgCases(cases),cases}})
 const features={...initial,finishedAt:follow.finishedAt,measurementWindows:[{source:"features",startedAt:initial.startedAt,finishedAt:initial.finishedAt},{source:"configuration",startedAt:follow.startedAt,finishedAt:follow.finishedAt}],observations,svgAssessments,criteriaProtocol:fidelityCriteriaProtocol(root,'/usr/bin/chromium'),recheck:{source,recheckedAt:date,parentReceiptSha256:originalHash,inputs,checks,configurationSource:follow.startedAt,scope:'Group verdicts rechecked from the exact retained SVGs; one configuration case replaced by the explicit corrected-binding follow-up. No other rendering was repeated and no timing claim is made.'}}
 mkdirSync(base+'/rechecked/features',{recursive:true});writeFileSync(base+'/rechecked/features/result.json',JSON.stringify(features)+'\n')
 const original:any=JSON.parse(readFileSync(base+'/docs/result.json','utf8')),inventory=JSON.parse(readFileSync(base+'/docs/inventory.json','utf8')),reviewBytes=readFileSync(root+'/corpus/docs-reviewed.json'),reviewed=admitDocsReviews(inventory.cases,JSON.parse(reviewBytes.toString()))
 const docRows=original.observations.filter((r:any)=>r.operation==='render').map((row:any)=>{const{samplesMs,...rest}=row;return rest})
 const docChecks:any[]=[]
 for(const prior of original.observations.filter((r:any)=>r.operation==='drawing-checks')){
  const input=inventory.cases.find((c:any)=>c.id===prior.caseId),review=reviewed.find(c=>c.id===prior.caseId)!.review,rendered=original.observations.find((r:any)=>r.operation==='render'&&r.metrics.project===prior.metrics.project&&r.caseId===prior.caseId)
  let assessment:any
  if(review?.intent==='drawing'&&prior.metrics.witness){
   const path=resolve(base+'/docs',prior.metrics.witness);if(!path.startsWith(base+'/docs/drawings/'))throw Error('Witness outside doc archive')
   const svg=gunzipSync(readFileSync(path)).toString('utf8');if(!path.endsWith('/'+digest(svg)+'.svg.gz'))throw Error('Changed documentation witness')
   const authored=reviewedDocsCase(input,review),admission=qualifyOutput({id:input.id,family:authored.family,source:input.source,features:[],provenance:review.review,expectedLabels:authored.expected.labels},svg,'svg')
   assessment=assessDocsDrawing(input,review,rendered.status,admission.ok,await inspect(svg,authored))
  }else assessment=assessDocsDrawing(input,review,rendered?.status??'blocked',false,[])
  const row={...prior,status:assessment.status==='correct'?'passed':assessment.status==='incorrect'?'failed':assessment.status==='not-applicable'?'not-applicable':'blocked',detail:JSON.stringify(assessment),metrics:{...prior.metrics,reviewedSource:!!review,recheckedAt:date,observerSource:source}}
  docRows.push(row);if(review)docChecks.push({project:row.metrics.project,caseId:row.caseId,...assessment})
 }
 const docInventory={...inventory,drawingReview:{protocol:'reviewed-docs-svg-content-v1',sha256:digest(reviewBytes),cases:reviewed,observerProducers:protocolIdentity(root,['fidelity/paint.ts','fidelity/paint-values.ts','unified/docs-drawings.ts'])},producers:inventory.producers}
 const docs={...original,observations:docRows,recheck:{source,recheckedAt:date,parentSha256:digest(readFileSync(base+'/docs/result.json')),scope:'Retained SVGs only; added source contracts reuse the earlier controlled-PNG source facts. Every render timestamp remains original and timing samples are omitted.'}}
 mkdirSync(base+'/rechecked/docs',{recursive:true});writeFileSync(base+'/rechecked/docs/result.json',JSON.stringify(docs)+'\n');writeFileSync(base+'/rechecked/docs/inventory.json',JSON.stringify(docInventory,null,2)+'\n');writeFileSync(base+'/rechecked/docs/reviewed-cases.json',JSON.stringify(docChecks,null,2)+'\n')
 const terminal=JSON.parse(readFileSync(base+'/terminal/report.json','utf8'))
 const terminalRows=terminal.rows.map((row:any)=>row.role==='source-reference-only'?row:{...row,...inspectTerminalMeaning(readFileSync(base+'/terminal/'+row.witness,'utf8'),terminal.cases.find((c:any)=>c.id===row.caseId))})
 writeFileSync(base+'/terminal/rechecked.json',JSON.stringify({...terminal,rows:terminalRows,recheck:{source,recheckedAt:date,parentSha256:digest(readFileSync(base+'/terminal/report.json')),scope:'Observer-only recheck of identical terminal output bytes; no public renderer called again.'},observerProducers:protocolIdentity(root,['fidelity/terminal.ts'])},null,2)+'\n')
 const projects=initial.svgAssessments.map((r:any)=>r.project),campaign={schema:'trident-campaign-v2',startedAt:initial.startedAt,updatedAt:date,projects,profile:'full',rounds:1,requestedSuites:['docs','fidelity'],options:{out:base+'/rechecked'},results:[{suite:'fidelity',out:base+'/rechecked/features',status:'failed',completed:true},{suite:'docs',out:base+'/rechecked/docs',status:'failed',completed:true}],qualificationOnly:true,scope:'Dated qualification/recheck view, not a replacement for ecosystem release scores. All unsupported and unknown cases stay in the planned inventory.'}
 writeFileSync(base+'/rechecked/report.json',JSON.stringify(campaign,null,2)+'\n')
 console.log(JSON.stringify({source,features:svgAssessments.map(({cases,...a}:any)=>a),groups:checks,terminal:terminalRows.filter((r:any)=>r.role==='terminal-output').map((r:any)=>({project:r.project,id:r.caseId,status:r.status}))},null,2))
}finally{await context.close();await browser.close();await new Promise<void>(done=>server.close(()=>done()))}
