import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { inspectTerminalMeaning } from '/workspace/trident/fidelity/terminal.ts'
import { createMeaningAdapter } from '/workspace/trident/fidelity/adapters.ts'
import { assessMeaning } from '/workspace/trident/fidelity/meaning.ts'
import { protocolIdentity } from '/workspace/trident/unified/protocol-identity.ts'
import { qualifyOutput } from '/workspace/trident/unified/qualification.ts'
const out='/workspace/trident-benchmark-repair-2026-10-30/terminal';mkdirSync(out,{recursive:true})
const node=(id:string)=>({id,label:id}),edge=(source:string,target:string,label?:string)=>({source,target,...(label?{label}:{})})
const cases=[
 {id:'chain',source:'flowchart LR\nAlpha --> Beta\nBeta --> Gamma',nodes:['Alpha','Beta','Gamma'].map(node),edges:[edge('Alpha','Beta'),edge('Beta','Gamma')]},
 {id:'branch',source:'flowchart LR\nAlpha --> Beta\nAlpha --> Gamma',nodes:['Alpha','Beta','Gamma'].map(node),edges:[edge('Alpha','Beta'),edge('Alpha','Gamma')]},
 {id:'labelled',source:'flowchart LR\nAlpha -->|send| Beta',nodes:['Alpha','Beta'].map(node),edges:[edge('Alpha','Beta','send')]},
 {id:'vertical',source:'flowchart TD\nAlpha --> Beta',nodes:['Alpha','Beta'].map(node),edges:[edge('Alpha','Beta')]},
]
const digest=(bytes:Buffer|string)=>createHash('sha256').update(bytes).digest('hex')
const prepared=JSON.parse(readFileSync('/workspace/trident-ecosystem-b0-2026-10-30/campaign/preparation/community-prepared.json','utf8'))
const ascii=prepared.find((p:any)=>p.node.id==='AlexanderGrooff/mermaid-ascii'),python=prepared.find((p:any)=>p.node.id==='fasouto/termaid')
if(digest(readFileSync(ascii.artifact.executable))!==ascii.artifact.sha256)throw Error('ASCII artifact changed')
for(const file of python.artifact.files)if(digest(readFileSync(file.path))!==file.sha256)throw Error('Python wheel changed')
const referenceRoot='/workspace/.cloud-tools/mermaid-reference'
const reference=await createMeaningAdapter({tool:'mermaid',packageRoot:referenceRoot+'/node_modules/mermaid',referenceRoot})
const rows:any[]=[]
for(const item of cases){const parsed=await reference.parse(item.source,'flowchart');const checks=assessMeaning({family:'flowchart',expected:{labels:item.nodes.map(n=>n.label),nodes:item.nodes,edges:item.edges.map(e=>({...e,directed:true}))}},parsed.meaning);if(!checks.passed)throw Error('Mermaid source-reference check failed: '+item.id);rows.push({project:'mermaid-js/mermaid',version:reference.version,role:'source-reference-only',caseId:item.id,sourceAccepted:true,declaredGraphMatches:true,terminalVerdict:null})}
for(const item of cases){const stdout=execFileSync(ascii.artifact.executable,[],{input:item.source,encoding:'utf8',timeout:15_000,maxBuffer:1024*1024});writeFileSync(out+'/ascii-'+item.id+'.txt',stdout);rows.push({project:ascii.node.id,version:ascii.artifact.version,role:'terminal-output',caseId:item.id,witness:'ascii-'+item.id+'.txt',sha256:digest(stdout),...inspectTerminalMeaning(stdout,item)})}
const pythonScript=`import sys,json,termaid,importlib.metadata,pathlib,zipfile,hashlib\njob=json.load(sys.stdin)\nroot=pathlib.Path(termaid.__file__).parent.parent\nwith zipfile.ZipFile(job['wheel']) as z:\n for n in z.namelist():\n  if n.endswith('.py'):\n   assert hashlib.sha256((root/n).read_bytes()).digest()==hashlib.sha256(z.read(n)).digest(), n\nprint(json.dumps({'version':importlib.metadata.version('termaid'),'rows':[{'id':c['id'],'output':termaid.render(c['source'])} for c in job['cases']]}))`
const result=JSON.parse(execFileSync(python.artifact.python,['-c',pythonScript],{input:JSON.stringify({wheel:python.artifact.files[0].path,cases}),encoding:'utf8',timeout:30_000,maxBuffer:1024*1024}))
if(result.version!==python.artifact.version)throw Error('Python imported version differs from freeze')
for(const rendered of result.rows){const item=cases.find(c=>c.id===rendered.id)!;writeFileSync(out+'/termaid-'+item.id+'.txt',rendered.output);rows.push({project:python.node.id,version:result.version,role:'terminal-output',caseId:item.id,witness:'termaid-'+item.id+'.txt',sha256:digest(rendered.output),...inspectTerminalMeaning(rendered.output,item)})}
const chain=cases[0]!,drawing=readFileSync(out+'/ascii-chain.txt','utf8')
const mutants=[{id:'wrong-arrow',output:drawing.replace('►','◄')},{id:'broken-stem',output:drawing.replace('├────►','├─ ──►')},{id:'missing-node',output:drawing.replace('Beta','Gone')},{id:'wrong-topology',output:drawing.replace(' Beta ','Gamma ').replace(' Gamma ',' Beta  ')}]
const controls=mutants.map(item=>{const verdict=inspectTerminalMeaning(item.output,chain);if(verdict.status!=='incorrect')throw Error('Mutation survived: '+item.id);return{id:item.id,oldLabelAdmission:qualifyOutput({id:item.id,family:'flowchart',source:chain.source,expectedLabels:chain.nodes.map(n=>n.label),features:[],provenance:'Declared terminal source facts'},item.output,'terminal').ok,verdict:verdict.status}})
const report={source:execFileSync('git',['rev-parse','HEAD'],{cwd:'/workspace/trident',encoding:'utf8'}).trim(),generatedAt:new Date().toISOString(),producers:protocolIdentity('/workspace/trident',['fidelity/terminal.ts','fidelity/adapters.ts','unified/qualification.ts']),cases,artifacts:[{project:ascii.node.id,version:ascii.artifact.version,executableSha256:ascii.artifact.sha256},{project:python.node.id,version:result.version,wheelFiles:python.artifact.files,installedPythonSourcesMatchWheel:true}],rows,controls,scope:'One untimed 4-case flowchart prototype. Mermaid is a source-reference participant without a terminal score. No performance or ecosystem-wide correctness claim.'}
writeFileSync(out+'/report.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({rows:rows.map(r=>({project:r.project,case:r.caseId,status:r.status??r.role})),controls},null,2))
