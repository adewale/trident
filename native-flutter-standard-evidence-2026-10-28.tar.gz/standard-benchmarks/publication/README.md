# Trident benchmark evidence

Published 2026-10-28T20:37:42.152Z. Measurement dates below belong to the original campaigns.

Unranked scorecards. Coverage, output correctness, optional model evidence, time and resources have different units. Missing adapters and unavailable observers receive no pass credit. No global winner or validated production holdout is claimed.

Evidence is copied below. Original absolute paths inside raw records remain provenance; the links here point to the copied files.

| Campaign | Measured from | Last recorded update | Profile / rounds | Projects | Completion |
|---|---|---|---|---:|---|
| [1](evidence/1/report.json) | 2026-10-28T20:26:48.698Z | 2026-10-28T20:30:03.010Z | full / 5 | 2 | no completion receipt: partial |

## Campaign 1

Selected projects: orestesgaolin/mermaid, obsidianmd/pele.

| Suite | Project scope | Status / disposition | Counts and limits | Owning evidence |
|---|---|---|---|---|
| community | orestesgaolin/mermaid, obsidianmd/pele | failed | {"not-applicable":1091,"passed":1457,"unsupported":70,"failed":51,"blocked":4}; editor:kanban: pinned Mermaid rejected source (Parse error on line 5:); portfolio:mindmap:46: pinned Mermaid rejected source (There can be only one root. No parent could be found for ("accDescr: Official shapes, formatted labels, local icons, and accessible metadata")); portfolio:mindmap:47: pinned Mermaid rejected source (There can be only one root. No parent could be found for ("accDescr: A broad operational map with more than eleven second-level nodes")); scaling:architecture:16-junctions: pinned Mermaid returned no nonempty authored label expectations; scaling:architecture:32-junctions: pinned Mermaid returned no nonempty authored label expectations; scaling:architecture:32-large-junctions: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-gantt-bench:ps-dateformat-lowercase: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-gantt-bench:ps-inclusive-end-dates: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-gantt-bench:ps-excludes-multiline-6270: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-gantt-bench:ps-weekday-monday: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-gantt-bench:ps-weekday-tuesday: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-gantt-bench:ps-weekday-wednesday: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-gantt-bench:ps-weekday-thursday: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-gantt-bench:ps-weekday-friday: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-gantt-bench:ps-weekday-saturday: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-gantt-bench:ps-weekday-sunday: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-gantt-bench:db-todaymarker-style: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-packet-bench:packet-spec-1: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-packet-bench:packet-spec-2: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-packet-bench:packet-header-1: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-packet-bench:packet-header-2: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-packet-bench:packet-header-3: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-packet-bench:packet-header-5: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-packet-bench:packet-header-6: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-packet-bench:packet-header-7: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-upstream-suite-bench:architecture-upstream-should-handle-a-simple-radar-definition: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-upstream-suite-bench:architecture-upstream-should-handle-accessibility-title-and-description: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-upstream-suite-bench:architecture-upstream-should-handle-multiline-accessibility-description: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-upstream-suite-bench:class-upstream-should-handle-acctitle-and-accdescr: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-upstream-suite-bench:class-upstream-should-handle-acctitle-and-multiline-accdescr: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-upstream-suite-bench:flowchart-upstream-should-accept-swimlane-as-a-graph-keyword: pinned Mermaid rejected source (No diagram type detected matching given configuration for text: swimlane LR;A-->B;); corpus:mermaid-upstream-suite-bench:flowchart-upstream-should-keep-node-label-text-if-already-defined-when-a-style-is-applied: pinned Mermaid rejected source (Parse error on line 1:); corpus:mermaid-upstream-suite-bench:quadrant-upstream-should-be-able-to-handle-constructor-as-a-classname: pinned Mermaid rejected source (style named fill is not supported.); corpus:mermaid-upstream-suite-bench:sequence-upstream-should-not-hang-when-as-is-used-without-a-space-before-the-alias-text: pinned Mermaid rejected source (Parse error on line 2:); corpus:mermaid-upstream-suite-bench:state-upstream-should-handle-arrow-directions-definitions: pinned Mermaid rejected source (Parse error on line 3:); corpus:mermaid-upstream-suite-bench:state-upstream-should-handle-arrow-directions-definitions-2: pinned Mermaid rejected source (Parse error on line 3:); corpus:mermaid-upstream-suite-bench:state-upstream-should-handle-floating-notes-2: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-upstream-suite-bench:state-upstream-should-handle-floating-notes-4: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-upstream-suite-bench:xychart-upstream-parse-x-axis-without-axis-name-and-range-data: pinned Mermaid returned no nonempty authored label expectations; corpus:mermaid-upstream-suite-bench:xychart-upstream-parse-y-axis-without-axis-name-with-range-data: pinned Mermaid returned no nonempty authored label expectations; authored:architecture-edge-no-spaces: pinned Mermaid returned no nonempty authored label expectations; family:zenuml: pinned Mermaid has no label getter projection; SVG XML/canvas and authored-label checks do not establish complete semantic identity, multiplicity, route geometry or visual fidelity. Dedicated family feature assertions remain separate.; Core repeat cases calibrate to20ms/256iterations. With communityCoverageOnce, feature-corpus inputs qualify one actual call in round1 without warm/repeated speed samples; later rounds contain core only. These protocols never share a speed aggregate. API clocks exclude validation/cleanup; internal DOM measurement belongs to the API. JS heap excludes native/WASM/process memory. | [owning directory](evidence/1/community/) |
| docs | orestesgaolin/mermaid, obsidianmd/pele | failed | {"unsupported":1,"passed":2660,"failed":80}; orestesgaolin/mermaid: Error: This community capability does not expose SVG rendering.; SVG return only; no meaning/paint qualification. Distinct protocol from historical AM Davebench: complete pinned upstream syntax directory, all catalog browser bindings. Latency comparisons require pairwise common successes; no overall speed score. | [owning directory](evidence/1/docs/) |
| fidelity | orestesgaolin/mermaid, obsidianmd/pele | failed | {"blocked":690,"passed":1164,"unsupported":71,"failed":2}; Native public-model criteria are unavailable for this noncore peer; public SVG success supplies no model passes.; Quantitative and graph projections are bounded reviewed checks, not whole-family visual equivalence. | [owning directory](evidence/1/fidelity/) |

### community observations

Counts are recorded observations within each public surface/mode/round. Unexecuted inputs and planned denominators remain in the owning inventory; no acceptance percentage is inferred.

| Project | Version / artifact role | Surface / runtime | Mode / round | Distinct case IDs | Recorded observations | Dispositions |
|---|---|---|---|---:|---:|---|
| obsidianmd/pele | see frozen artifact receipt / default | browser:public-api / chromium-v8 | after-round-1 / 1 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | see frozen artifact receipt / default | browser:public-api / chromium-processes | after-round-1 / 1 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | see frozen artifact receipt / default | browser:public-api / chromium-v8 | after-round-2 / 2 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | see frozen artifact receipt / default | browser:public-api / chromium-processes | after-round-2 / 2 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | see frozen artifact receipt / default | browser:public-api / chromium-v8 | after-round-3 / 3 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | see frozen artifact receipt / default | browser:public-api / chromium-processes | after-round-3 / 3 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | see frozen artifact receipt / default | browser:public-api / chromium-v8 | after-round-4 / 4 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | see frozen artifact receipt / default | browser:public-api / chromium-processes | after-round-4 / 4 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | see frozen artifact receipt / default | browser:public-api / chromium-v8 | after-round-5 / 5 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | see frozen artifact receipt / default | browser:public-api / chromium-processes | after-round-5 / 5 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | cold-round-1 / not round-based | 1 | 1 | {"passed":1} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | cold-round-2 / not round-based | 1 | 1 | {"passed":1} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | cold-round-3 / not round-based | 1 | 1 | {"passed":1} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | cold-round-4 / not round-based | 1 | 1 | {"passed":1} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | cold-round-5 / not round-based | 1 | 1 | {"passed":1} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | core-api-repeat / 1 | 6 | 6 | {"passed":6} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | core-api-repeat / 2 | 6 | 6 | {"passed":6} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | core-api-repeat / 3 | 6 | 6 | {"passed":6} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | core-api-repeat / 4 | 6 | 6 | {"passed":6} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | core-api-repeat / 5 | 6 | 6 | {"passed":6} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | family-support-probe / 1 | 33 | 33 | {"passed":32,"unsupported":1} |
| obsidianmd/pele | see frozen artifact receipt / default | browser:public-api / chromium | feature-corpus-attempt / 0 | 363 | 363 | {"not-applicable":363} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | feature-corpus-qualification / 1 | 717 | 717 | {"failed":7,"passed":710} |
| obsidianmd/pele | see frozen artifact receipt / default | browser:public-api / chromium | feature-corpus-qualification / 1 | 1 | 1 | {"unsupported":1} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | round-1 / 1 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | round-2 / 2 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | round-3 / 3 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | round-4 / 4 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | 1.9.0 / default | browser:public-api / chromium | round-5 / 5 | 1 | 1 | {"passed":1} |
| obsidianmd/pele | see frozen artifact receipt / default | node:public-api / Node | capability / not round-based | 1 | 1 | {"not-applicable":1} |
| obsidianmd/pele | see frozen artifact receipt / default | node:public-api / Node | feature-corpus-attempt / 1 | 363 | 363 | {"not-applicable":363} |
| orestesgaolin/mermaid | see frozen artifact receipt / default | browser:public-api / chromium | capability / not round-based | 1 | 1 | {"not-applicable":1} |
| orestesgaolin/mermaid | 0.3.2 / default | native:in-process-api / Native Linux Flutter release / Dart 3.13.7 | core-api-repeat / 1 | 6 | 6 | {"passed":6} |
| orestesgaolin/mermaid | 0.3.2 / default | native:in-process-api / Native Linux Flutter release / Dart 3.13.7 | core-api-repeat / 2 | 6 | 6 | {"passed":6} |
| orestesgaolin/mermaid | 0.3.2 / default | native:in-process-api / Native Linux Flutter release / Dart 3.13.7 | core-api-repeat / 3 | 6 | 6 | {"passed":6} |
| orestesgaolin/mermaid | 0.3.2 / default | native:in-process-api / Native Linux Flutter release / Dart 3.13.7 | core-api-repeat / 4 | 6 | 6 | {"passed":6} |
| orestesgaolin/mermaid | 0.3.2 / default | native:in-process-api / Native Linux Flutter release / Dart 3.13.7 | core-api-repeat / 5 | 6 | 6 | {"passed":6} |
| orestesgaolin/mermaid | 0.3.2 / default | native:in-process-api / Native Linux Flutter release / Dart 3.13.7 | family-support-probe / 1 | 33 | 33 | {"passed":28,"unsupported":5} |
| orestesgaolin/mermaid | see frozen artifact receipt / default | native:in-process-api / Native Linux Flutter release / Dart 3.13.7 | feature-corpus-qualification / 1 | 63 | 63 | {"unsupported":63} |
| orestesgaolin/mermaid | 0.3.2 / default | native:in-process-api / Native Linux Flutter release / Dart 3.13.7 | feature-corpus-qualification / 1 | 655 | 655 | {"blocked":4,"failed":44,"passed":607} |
| orestesgaolin/mermaid | see frozen artifact receipt / default | node:public-api / Node | feature-corpus-attempt / 1 | 363 | 363 | {"not-applicable":363} |

### docs observations

Counts are recorded observations within each public surface/mode/round. Unexecuted inputs and planned denominators remain in the owning inventory; no acceptance percentage is inferred.

| Project | Version / artifact role | Surface / runtime | Mode / round | Distinct case IDs | Recorded observations | Dispositions |
|---|---|---|---|---:|---:|---|
| obsidianmd/pele | 1.9.0 / default | browser:svg / Chromium | one-public-call / 1 | 548 | 548 | {"failed":16,"passed":532} |
| obsidianmd/pele | 1.9.0 / default | browser:svg / Chromium | one-public-call / 2 | 548 | 548 | {"failed":16,"passed":532} |
| obsidianmd/pele | 1.9.0 / default | browser:svg / Chromium | one-public-call / 3 | 548 | 548 | {"failed":16,"passed":532} |
| obsidianmd/pele | 1.9.0 / default | browser:svg / Chromium | one-public-call / 4 | 548 | 548 | {"failed":16,"passed":532} |
| obsidianmd/pele | 1.9.0 / default | browser:svg / Chromium | one-public-call / 5 | 548 | 548 | {"failed":16,"passed":532} |
| orestesgaolin/mermaid | see frozen artifact receipt / default | browser:svg / Chromium | not-executed / not round-based | 1 | 1 | {"unsupported":1} |

### fidelity observations

Counts are recorded observations within each public surface/mode/round. Unexecuted inputs and planned denominators remain in the owning inventory; no acceptance percentage is inferred.

| Project | Version / artifact role | Surface / runtime | Mode / round | Distinct case IDs | Recorded observations | Dispositions |
|---|---|---|---|---:|---:|---|
| obsidianmd/pele | 1.9.0 / default | browser-owned-ink / Chromium | independent-authored-criteria / not round-based | 975 | 975 | {"blocked":67,"failed":2,"passed":906} |
| obsidianmd/pele | 1.9.0 / default | browser-owned-ink / not-observed | independent-authored-criteria / not round-based | 60 | 60 | {"unsupported":60} |
| obsidianmd/pele | 1.9.0 / default | browser-public-api / Chromium | independent-authored-criteria / not round-based | 264 | 264 | {"passed":258,"unsupported":6} |
| obsidianmd/pele | 1.9.0 / default | browser-public-api / not-observed | independent-authored-criteria / not round-based | 5 | 5 | {"unsupported":5} |
| obsidianmd/pele | 1.9.0 / default | native-public-api / not-observed | independent-authored-criteria / not round-based | 623 | 623 | {"blocked":623} |

Raw samples, input inventories, versions and failure outputs remain in the owning evidence; no denominator or speed comparison is reconstructed from process completion.
