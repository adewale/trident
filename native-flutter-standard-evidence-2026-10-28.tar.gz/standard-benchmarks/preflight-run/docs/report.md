# Official documentation SVG return

548 occurrences; 546 distinct inputs; 34 pinned syntax pages.

| Project | Round | SVG returned | Failed | Unexecuted |
|---|---|---|---|---|
| orestesgaolin/mermaid | 1 | 0 | 0 | 548 |
| orestesgaolin/mermaid | 2 | 0 | 0 | 548 |
| orestesgaolin/mermaid | 3 | 0 | 0 | 548 |
| orestesgaolin/mermaid | 4 | 0 | 0 | 548 |
| orestesgaolin/mermaid | 5 | 0 | 0 | 548 |
| obsidianmd/pele | 1 | 532 | 16 | 0 |
| obsidianmd/pele | 2 | 532 | 16 | 0 |
| obsidianmd/pele | 3 | 532 | 16 | 0 |
| obsidianmd/pele | 4 | 532 | 16 | 0 |
| obsidianmd/pele | 5 | 532 | 16 | 0 |

A returned SVG is weak compatibility evidence. Timing samples are in result.json; compare only pairwise common successful inputs. No overall speed rank or calibrated performance pass.
