# Native Flutter / Chromium standard benchmark evidence

Use `scorecards.md` for distinct input/criterion counts, limitations and named
completion boundaries. `published/README.md` is Trident's normal
surface/mode/round index, produced by `results:campaign --copy-evidence`.

- `community-run/`: final compatibility owning evidence, including manifests, raw samples,
  PNGs, SVGs, input inventories, observers, attempt logs and completion receipt.
- `reduction-published/`: per-input CSV, core timing CSV, all nonpasses with source,
  summary JSON. Different formats have different qualification strengths.
- `environment.json`: exact host/SDK/runtime/font details.
- `png-bundle-serialized/`: complete measured native Linux Flutter release bundle.
- `measured-run/`: owning evidence for the unaffected docs and Meaning suites.
- `source-community.tar.gz` and `source.tar.gz`: exact compatibility and docs/Meaning producer commits. The installed libraries are
  pinned by the source lockfiles and preparation receipts.
- `STANDARD.md`: reproduction commands copied from the source documentation.
- `AUDIT.md`, `ATTEMPTS.md`, `verification.json`: audit findings, disposition of
  earlier attempts, checks and explicit test limitations.
- `representative/`: unchanged actual output bytes selected from final evidence.
- `SHA256SUMS`: hashes for every retained file except the manifest itself.

All nonpasses are retained. A collection-completion receipt is not a qualification
pass. No cross-format/runtime speed ratio or full native semantics score is claimed.
The original absolute paths inside raw records are provenance; after extraction,
locate their corresponding file under the same relative attempt directory.

Earlier attempts and setup failures remain in their named directories and do not
supply final scorecard numbers. `source-community.tar.gz` owns final compatibility; `source.tar.gz` owns docs/Meaning; the separate
`measured-source/` snapshot owns the older exploratory run only.
