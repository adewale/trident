import {readBenchmarkDocument} from '/workspace/trident/portable/project-records.ts'
import {writeFileSync} from 'node:fs'
writeFileSync('/workspace/standard-benchmarks/normalized-inputs.json',JSON.stringify(readBenchmarkDocument('/workspace/standard-benchmarks/run/community/community-inputs.json')))
