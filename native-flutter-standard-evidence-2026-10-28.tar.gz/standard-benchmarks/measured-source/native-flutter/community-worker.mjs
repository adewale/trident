#!/usr/bin/env node
// Adapter transport only: the native Flutter child owns every renderToPng call.
import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {qualifyOutput} from '../unified/qualification.ts';
const [jobPath,resultPath]=process.argv.slice(2);
if(!jobPath||!resultPath)throw Error('Expected JOB RESULT arguments');
const job=JSON.parse(fs.readFileSync(jobPath,'utf8'));
if(job.output!=='png')throw Error('Native Flutter binding exposes the advertised PNG API only');
const dir=resultPath+'.native';fs.mkdirSync(dir);
const raw=path.join(dir,'raw.jsonl');
const fd=fs.openSync(resultPath,'wx');let emitted=0;
const child=spawn(process.env.FLUTTER_COMMUNITY_EXECUTABLE||'/workspace/standard-benchmarks/png-bundle/native_bench',[],{env:{...process.env,FLUTTER_COMMUNITY_JOB:path.resolve(jobPath),FLUTTER_COMMUNITY_RAW:raw,FLUTTER_COMMUNITY_DIR:path.resolve(dir)},stdio:['ignore','inherit','inherit']});
function collect(){
 if(!fs.existsSync(raw))return;
 const lines=fs.readFileSync(raw,'utf8').split('\n');lines.pop();
 for(;emitted<lines.length;emitted++){
  const r=JSON.parse(lines[emitted]);const w=job.workloads.find(w=>w.id===r.workload);
  if(!w||r.release!==true)throw Error('Unowned workload or non-release output');
  if(r.status==='ok'){
   const png=fs.readFileSync(r.png);const q=qualifyOutput({id:w.id,source:w.source,expectedLabels:w.expected},png,'png');
   r.status=q.ok?'ok':q.unavailable?'blocked':'error';r.qualificationScope=q.scope;r.qualification=q;
   if(!q.ok){r.rejected=false;r.detail=q.findings.join('; ');}
  }
  fs.writeSync(fd,JSON.stringify(r)+'\n');fs.fsyncSync(fd);
 }
}
const monitor=setInterval(collect,100);
const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',resolve)});
clearInterval(monitor);collect();fs.closeSync(fd);process.exitCode=code??1;
