/** Additive cohorts. Dave and the historical six-core comparison stay unchanged. */
export const PORTABLE_COHORT_PROTOCOL = 'portable-authored-family-scaling-v3'
export type PortableCohort = 'family' | 'scaling' | 'adversarial' | 'invalid'
export type Json = null | boolean | number | string | Json[] | { [key: string]: Json }
export interface PortableEdge {
  source: string
  target: string
}
export interface PortableCase {
  id: string
  family: string
  source: string
  cohort: PortableCohort
  scale?: number
  expected: {
    accept: boolean
    labels: string[]
    model?: { path: (string | number | { map: string })[]; value: Json; comparison?: 'display-text' }[]
    topology?: { nodes: string[]; edges: PortableEdge[]; nodeLabels?: Record<string, string>; groups?: { id: string; members: string[] }[] }
  }
  /** Semantic configuration intent translated through a reviewed public API. */
  renderOptions?: Record<string, Json>
  prelude?: { source: string; accept: boolean }[]
  edit?: { source: string; expected: PortableCase['expected']; renderOptions?: Record<string, Json> }
}

const edge = (source: string, target: string): PortableEdge => ({ source, target })
const familyCases: PortableCase[] = [
  {
    id: 'family:flowchart',
    family: 'flowchart',
    cohort: 'family',
    source: 'flowchart LR\nA[Alpha] --> B[Beta]\nB --> C[Gamma]',
    expected: { accept: true, labels: ['Alpha', 'Beta', 'Gamma'], topology: { nodes: ['A', 'B', 'C'], edges: [edge('A', 'B'), edge('B', 'C')], nodeLabels: { A: 'Alpha', B: 'Beta', C: 'Gamma' } } },
  },
  { id: 'family:sequence', family: 'sequence', cohort: 'family', source: 'sequenceDiagram\nparticipant A as Alpha\nparticipant B as Beta\nA->>B: Request\nB-->>A: Reply', expected: { accept: true, labels: ['Alpha', 'Beta', 'Request', 'Reply'], topology: { nodes: ['A', 'B'], edges: [edge('A', 'B'), edge('B', 'A')] } } },
  { id: 'family:state', family: 'state', cohort: 'family', source: 'stateDiagram-v2\nstate "Alpha" as A\nstate "Beta" as B\nA --> B: advance', expected: { accept: true, labels: ['Alpha', 'Beta', 'advance'], topology: { nodes: ['A', 'B'], edges: [edge('A', 'B')] } } },
  { id: 'family:class', family: 'class', cohort: 'family', source: 'classDiagram\nclass Alpha\nclass Beta\nAlpha --> Beta: uses', expected: { accept: true, labels: ['Alpha', 'Beta', 'uses'], topology: { nodes: ['Alpha', 'Beta'], edges: [edge('Alpha', 'Beta')] } } },
  { id: 'family:er', family: 'er', cohort: 'family', source: 'erDiagram\nALPHA ||--o{ BETA : owns', expected: { accept: true, labels: ['ALPHA', 'BETA', 'owns'], topology: { nodes: ['ALPHA', 'BETA'], edges: [edge('ALPHA', 'BETA')] } } },
  { id: 'family:timeline', family: 'timeline', cohort: 'family', source: 'timeline\ntitle Delivery\n2026 : Launch : Review', expected: { accept: true, labels: ['Delivery', '2026', 'Launch', 'Review'], model: [{ path: ['periods', 0, 'events'], value: ['Launch', 'Review'], comparison: 'display-text' }] } },
  {
    id: 'family:journey',
    family: 'journey',
    cohort: 'family',
    source: 'journey\ntitle Delivery\nsection Plan\nReview: 4: Builder',
    expected: {
      accept: true,
      labels: ['Delivery', 'Plan', 'Review', 'Builder'],
      model: [
        { path: ['tasks', 0, 'score'], value: 4 },
        { path: ['tasks', 0, 'people'], value: ['Builder'] },
      ],
    },
  },
  {
    id: 'family:architecture',
    family: 'architecture',
    cohort: 'family',
    source: 'architecture-beta\ngroup app(cloud)[App]\nservice api(server)[API] in app\nservice db(database)[Data] in app\napi:R --> L:db',
    expected: { accept: true, labels: ['App', 'API', 'Data'], topology: { nodes: ['api', 'db'], edges: [edge('api', 'db')], groups: [{ id: 'app', members: ['api', 'db'] }] } },
  },
  {
    id: 'family:xychart',
    family: 'xychart',
    cohort: 'family',
    source: 'xychart-beta\ntitle "Series"\nx-axis [One, Two, Three]\ny-axis "Count" 0 --> 10\nbar [3, 7, 5]\nline [2, 6, 4]',
    expected: {
      accept: true,
      labels: ['Series', 'One', 'Two', 'Three', 'Count'],
      model: [
        { path: ['xAxis', 'categories'], value: ['One', 'Two', 'Three'] },
        {
          path: ['plots', 0, 'data'],
          value: [
            ['One', 3],
            ['Two', 7],
            ['Three', 5],
          ],
        },
        {
          path: ['plots', 1, 'data'],
          value: [
            ['One', 2],
            ['Two', 6],
            ['Three', 4],
          ],
        },
      ],
    },
  },
  {
    id: 'family:pie',
    family: 'pie',
    cohort: 'family',
    source: 'pie title Shares\n"Alpha" : 7\n"Beta" : 3',
    expected: {
      accept: true,
      labels: ['Shares', 'Alpha', 'Beta'],
      model: [
        { path: ['sections', { map: 'Alpha' }], value: 7 },
        { path: ['sections', { map: 'Beta' }], value: 3 },
      ],
    },
  },
  {
    id: 'family:quadrant',
    family: 'quadrant',
    cohort: 'family',
    source: 'quadrantChart\ntitle Priority\nx-axis Low effort --> High effort\ny-axis Low value --> High value\nAlpha: [0.2, 0.8]\nBeta: [0.8, 0.2]',
    expected: {
      accept: true,
      labels: ['Priority', 'Alpha', 'Beta', 'Low effort', 'High effort', 'Low value', 'High value'],
      model: [
        { path: ['points', 0, 'x'], value: 0.2 },
        { path: ['points', 0, 'y'], value: 0.8 },
        { path: ['points', 1, 'x'], value: 0.8 },
        { path: ['points', 1, 'y'], value: 0.2 },
      ],
    },
  },
  {
    id: 'family:gantt',
    family: 'gantt',
    cohort: 'family',
    source: 'gantt\ntitle Delivery\ndateFormat YYYY-MM-DD\ntodayMarker off\nsection Build\nDesign :taskAlpha, 2026-01-01, 2d\nReview :taskBeta, after taskAlpha, 3d',
    expected: {
      accept: true,
      labels: ['Delivery', 'Build', 'Design', 'Review'],
      model: [
        { path: ['tasks', 0, 'id'], value: 'taskAlpha' },
        { path: ['tasks', 1, 'id'], value: 'taskBeta' },
        { path: ['tasks', 1, 'raw', 'start'], value: 'after taskAlpha' },
      ],
    },
  },
  {
    id: 'family:mindmap',
    family: 'mindmap',
    cohort: 'family',
    source: 'mindmap\nroot((Root))\n  Alpha\n    Beta\n  Gamma',
    expected: {
      accept: true,
      labels: ['Root', 'Alpha', 'Beta', 'Gamma'],
      model: [
        { path: ['nodes', 0, 'descr'], value: 'Root' },
        { path: ['nodes', 0, 'children', 0, 'descr'], value: 'Alpha' },
        { path: ['nodes', 0, 'children', 0, 'children', 0, 'descr'], value: 'Beta' },
      ],
    },
  },
  {
    id: 'family:gitgraph',
    family: 'gitgraph',
    cohort: 'family',
    source: 'gitGraph\ncommit id:"Alpha" tag:"v1"\nbranch feature\ncommit id:"Beta"\ncheckout main\nmerge feature id:"Gamma"',
    expected: {
      accept: true,
      labels: ['Alpha', 'Beta', 'Gamma', 'v1'],
      model: [
        { path: ['commits', { map: 'Alpha' }, 'tags'], value: ['v1'] },
        { path: ['commits', { map: 'Gamma' }, 'parents'], value: ['Alpha', 'Beta'] },
      ],
    },
  },
  {
    id: 'family:radar',
    family: 'radar',
    cohort: 'family',
    source: 'radar-beta\ntitle Skills\naxis speed["Speed"], power["Power"], range["Range"]\ncurve now["Current"]{3, 4, 2}\nmax 5\nshowLegend true',
    expected: {
      accept: true,
      labels: ['Skills', 'Speed', 'Power', 'Range', 'Current'],
      model: [
        { path: ['curves', 0, 'entries'], value: [3, 4, 2] },
        { path: ['axes', 0, 'label'], value: 'Speed' },
      ],
    },
  },
  {
    id: 'family:sankey',
    family: 'sankey',
    cohort: 'family',
    source: 'sankey-beta\nAlpha,Beta,5\nBeta,Gamma,5',
    expected: {
      accept: true,
      labels: ['Alpha', 'Beta', 'Gamma'],
      topology: { nodes: ['Alpha', 'Beta', 'Gamma'], edges: [edge('Alpha', 'Beta'), edge('Beta', 'Gamma')] },
      model: [
        { path: ['links', 0, 'value'], value: 5 },
        { path: ['links', 1, 'value'], value: 5 },
      ],
    },
  },
  { id: 'family:c4', family: 'c4', cohort: 'family', source: 'C4Context\nPerson(user, "User")\nSystem(api, "API", "Service")\nRel(user, api, "Uses")', expected: { accept: true, labels: ['User', 'API', 'Service', 'Uses'], topology: { nodes: ['user', 'api'], edges: [edge('user', 'api')] } } },
  {
    id: 'family:packet',
    family: 'packet',
    cohort: 'family',
    source: 'packet\n0-7: "Header"\n8-15: "Payload"',
    expected: {
      accept: true,
      labels: ['Header', 'Payload'],
      model: [
        { path: ['rows', 0, 0, 'bits'], value: 8 },
        { path: ['rows', 0, 1, 'start'], value: 8 },
        { path: ['rows', 0, 1, 'end'], value: 15 },
      ],
    },
  },
  {
    id: 'family:kanban',
    family: 'kanban',
    cohort: 'family',
    source: 'kanban\nbacklog[Backlog]\n  TaskA[Build]\ndone[Done]\n  TaskB[Test]',
    expected: {
      accept: true,
      labels: ['Backlog', 'Build', 'Done', 'Test'],
      model: [
        { path: ['sections', 0, 'id'], value: 'backlog' },
        { path: ['sections', 0, 'items', 0, 'id'], value: 'TaskA' },
        { path: ['sections', 1, 'items', 0, 'id'], value: 'TaskB' },
      ],
    },
  },
  {
    id: 'family:requirement',
    family: 'requirement',
    cohort: 'family',
    source: 'requirementDiagram\nrequirement reliable {\nid: R1\ntext: Requests retain meaning\nrisk: high\nverifymethod: test\n}\nelement suite {\ntype: "test"\n}\nsuite - verifies -> reliable',
    expected: {
      accept: true,
      labels: ['reliable', 'suite', 'Requests retain meaning'],
      topology: { nodes: ['reliable', 'suite'], edges: [edge('suite', 'reliable')] },
      model: [
        { path: ['requirements', { map: 'reliable' }, 'requirementId'], value: 'R1' },
        { path: ['requirements', { map: 'reliable' }, 'text'], value: 'Requests retain meaning' },
      ],
    },
  },
  {
    id: 'family:treemap',
    family: 'treemap',
    cohort: 'family',
    source: 'treemap\n"Root"\n  "Alpha": 7\n  "Beta": 3',
    expected: {
      accept: true,
      labels: ['Root', 'Alpha', 'Beta'],
      model: [
        { path: ['roots', 0, 'children', 0, 'value'], value: 7 },
        { path: ['roots', 0, 'children', 1, 'value'], value: 3 },
      ],
    },
  },
  {
    id: 'family:ishikawa',
    family: 'ishikawa',
    cohort: 'family',
    source: 'ishikawa\n  Delay\n  Process\n    Review\n  Tooling\n    Build',
    expected: {
      accept: true,
      labels: ['Delay', 'Process', 'Review', 'Tooling', 'Build'],
      model: [
        { path: ['root', 'text'], value: 'Delay' },
        { path: ['root', 'children', 0, 'text'], value: 'Process' },
        { path: ['root', 'children', 0, 'children', 0, 'text'], value: 'Review' },
      ],
    },
  },
  {
    id: 'family:block',
    family: 'block',
    cohort: 'family',
    source: 'block\ncolumns 2\nAlpha["Alpha"] Beta["Beta"]\nAlpha --> Beta',
    expected: {
      accept: true,
      labels: ['Alpha', 'Beta'],
      model: [
        { path: ['byId', { map: 'Alpha' }, 'label'], value: 'Alpha' },
        { path: ['edges', 0, 'start'], value: 'Alpha' },
        { path: ['edges', 0, 'end'], value: 'Beta' },
      ],
    },
  },
]

function scalingCase(family: string, size: number): PortableCase {
  const nodes = Array.from({ length: size }, (_, index) => `N${index}`)
  const edges = nodes.slice(1).map((target, index) => edge(nodes[index]!, target))
  let source: string,
    labels: string[],
    topology = { nodes, edges }
  if (family === 'flowchart') {
    source =
      'flowchart LR\n' +
      nodes
        .map(id => `${id}[${id}]`)
        .concat(edges.map(item => `${item.source} --> ${item.target}`))
        .join('\n')
    labels = nodes
  } else if (family === 'class') {
    source =
      'classDiagram\n' +
      nodes
        .map(id => `class ${id}`)
        .concat(edges.map(item => `${item.source} --> ${item.target}`))
        .join('\n')
    labels = nodes
  } else if (family === 'er') {
    source = 'erDiagram\n' + edges.map(item => `${item.source} ||--o{ ${item.target} : owns`).join('\n')
    labels = [...nodes, 'owns']
  } else if (family === 'state') {
    source = 'stateDiagram-v2\n' + edges.map(item => `${item.source} --> ${item.target}`).join('\n')
    labels = nodes
  } else if (family === 'architecture') {
    const groups = Array.from({ length: Math.ceil(size / 8) }, (_, index) => ({ id: `G${index}`, members: nodes.slice(index * 8, (index + 1) * 8) }))
    source = 'architecture-beta\n' + groups.map(group => `group ${group.id}(cloud)[${group.id}]`).concat(nodes.map((id, index) => `service ${id}(server)[${id}] in G${Math.floor(index / 8)}`), edges.map(item => `${item.source}:R --> L:${item.target}`)).join('\n')
    labels = [...groups.map(group => group.id), ...nodes]
    return { id: `scaling:${family}:${size}`, family, source, cohort: 'scaling', scale: size, expected: { accept: true, labels, topology: { nodes, edges, groups } } }
  } else {
    source = 'sequenceDiagram\nparticipant A as Alpha\nparticipant B as Beta\n' + nodes.map((id, index) => (index % 2 ? `B-->>A: ${id}` : `A->>B: ${id}`)).join('\n')
    labels = ['Alpha', 'Beta', ...nodes]
    topology = { nodes: ['A', 'B'], edges: nodes.map((_id, index) => (index % 2 ? edge('B', 'A') : edge('A', 'B'))) }
  }
  return { id: `scaling:${family}:${size}`, family, source, cohort: 'scaling', scale: size, expected: { accept: true, labels, topology: { ...topology, ...(family === 'flowchart' ? { nodeLabels: Object.fromEntries(nodes.map(id => [id, id])) } : {}) } } }
}
const adversarialCases: PortableCase[] = [
  {
    id: 'adversarial:label-edit',
    family: 'flowchart',
    cohort: 'adversarial',
    source: 'flowchart LR\nA[Base label] --> B[Stable label]',
    expected: { accept: true, labels: ['Base label', 'Stable label'], topology: { nodes: ['A', 'B'], edges: [edge('A', 'B')], nodeLabels: { A: 'Base label', B: 'Stable label' } } },
    edit: { source: 'flowchart LR\nA[Edited label] --> B[Stable label]', expected: { accept: true, labels: ['Edited label', 'Stable label'], topology: { nodes: ['A', 'B'], edges: [edge('A', 'B')], nodeLabels: { A: 'Edited label', B: 'Stable label' } } } },
  },
  {
    id: 'adversarial:parallel-reciprocal',
    family: 'flowchart',
    cohort: 'adversarial',
    source: 'flowchart LR\nA[Alpha] --> B[Beta]\nA --> B\nB --> A\nB --> C[Gamma]',
    expected: { accept: true, labels: ['Alpha', 'Beta', 'Gamma'], topology: { nodes: ['A', 'B', 'C'], edges: [edge('A', 'B'), edge('A', 'B'), edge('B', 'A'), edge('B', 'C')] } },
  },
  {
    id: 'adversarial:nested-groups',
    family: 'flowchart',
    cohort: 'adversarial',
    source: 'flowchart TB\nsubgraph Outer[Outer group]\nsubgraph Inner[Inner group]\nA[Alpha] --> B[Beta]\nend\nC[Gamma]\nend\nB --> C',
    expected: {
      accept: true,
      labels: ['Outer group', 'Inner group', 'Alpha', 'Beta', 'Gamma'],
      topology: {
        nodes: ['A', 'B', 'C'],
        edges: [edge('A', 'B'), edge('B', 'C')],
        groups: [
          { id: 'Inner', members: ['A', 'B'] },
          { id: 'Outer', members: ['Inner', 'C'] },
        ],
      },
    },
  },
  {
    id: 'adversarial:wide-unicode',
    family: 'flowchart',
    cohort: 'adversarial',
    source: 'flowchart LR\nA["工程 🧑‍💻 é A very long authored label that must survive"] --> B["部署 🚀"]',
    expected: { accept: true, labels: ['工程', '🧑‍💻', 'é', 'A very long authored label that must survive', '部署', '🚀'], topology: { nodes: ['A', 'B'], edges: [edge('A', 'B')] } },
  },
  {
    id: 'adversarial:generated-looking-ids',
    family: 'flowchart',
    cohort: 'adversarial',
    source: 'flowchart LR\nL_A_B_0[First] --> A_B[Second]\nA_B --> C[Third]',
    expected: { accept: true, labels: ['First', 'Second', 'Third'], topology: { nodes: ['L_A_B_0', 'A_B', 'C'], edges: [edge('L_A_B_0', 'A_B'), edge('A_B', 'C')] } },
  },
  { id: 'adversarial:quoted-labels', family: 'flowchart', cohort: 'adversarial', source: 'flowchart LR\nA["Authored A & B"] --> B["Less than #60; stays text"]', expected: { accept: true, labels: ['Authored A & B', 'Less than < stays text'], topology: { nodes: ['A', 'B'], edges: [edge('A', 'B')] } } },
  { id: 'adversarial:invalid-recovery', family: 'flowchart', cohort: 'adversarial', prelude: [{ source: 'flowchart LR\n --> -->', accept: false }], source: 'flowchart LR\nA[Recovered] --> B[Ready]', expected: { accept: true, labels: ['Recovered', 'Ready'], topology: { nodes: ['A', 'B'], edges: [edge('A', 'B')] } } },
  {
    id: 'adversarial:configuration-reset',
    family: 'flowchart',
    cohort: 'adversarial',
    prelude: [{ source: '%%{init: {"flowchart": {"nodeSpacing": 100}}}%%\nflowchart LR\nA[Previous] --> B[Configuration]', accept: true }],
    source: 'flowchart TB\nA[Current] --> B[Configuration]',
    renderOptions: { fontSize: 14 },
    expected: { accept: true, labels: ['Current', 'Configuration'], topology: { nodes: ['A', 'B'], edges: [edge('A', 'B')] }, model: [{ path: ['direction'], value: 'TB' }] },
    edit: { source: 'flowchart TB\nA[Current] --> B[Configuration]', renderOptions: { fontSize: 24 }, expected: { accept: true, labels: ['Current', 'Configuration'], topology: { nodes: ['A', 'B'], edges: [edge('A', 'B')] }, model: [{ path: ['direction'], value: 'TB' }] } },
  },
]
const invalidCases: PortableCase[] = [
  { id: 'invalid:unknown-header', family: 'invalid-source', cohort: 'invalid', source: 'This is not Mermaid. @@@ {{{', expected: { accept: false, labels: [] } },
  { id: 'invalid:missing-endpoints', family: 'flowchart', cohort: 'invalid', source: 'flowchart LR\n --> -->', expected: { accept: false, labels: [] } },
  { id: 'invalid:unfinished-sequence', family: 'sequence', cohort: 'invalid', source: 'sequenceDiagram\nA->>', expected: { accept: false, labels: [] } },
]
export function portableCases(selection?: readonly PortableCohort[], caseIds?: readonly string[]): PortableCase[] {
  // Keep the original familyCases array as the historical 23-family mark;
  // the v2 current cohort also exercises both required first-party families.
  const required = [newerFamilyCases.find(testCase => testCase.family === 'eventmodeling')!, ...requiredExternalFamilyCases()]
  const cases = [...familyCases, ...required, ...['flowchart', 'sequence', 'class', 'state', 'er', 'architecture'].flatMap(family => [8, 32, 128].map(size => scalingCase(family, size))), ...adversarialCases, ...invalidCases]
  const selected = selection ? cases.filter(testCase => selection.includes(testCase.cohort)) : cases
  if (!caseIds) return selected
  if (!caseIds.length || caseIds.some(id => !id.trim()) || new Set(caseIds).size !== caseIds.length) throw Error('Case selection needs unique nonempty IDs')
  for (const id of caseIds) if (!selected.some(testCase => testCase.id === id)) throw Error('Unknown case or excluded by --cohort: ' + id)
  return selected.filter(testCase => caseIds.includes(testCase.id))
}

/** A family is supported when the renderer accepts its canonical family-cohort source.
 * Rejecting this probe marks the family unsupported before any of its cases run; an
 * accepted probe keeps every later failure in that family a failure. */
export const FAMILY_SUPPORT_PROTOCOL = 'family-cohort-source-acceptance-v1'
/** Mermaid's nine newest families (11.12.3 to 12.0.0), all but eventmodeling declared with a
 * `-beta` keyword. They are probed beyond the historical 23-family mark, and stay out of
 * the current mark unless individually required; Event Modeling belongs to the
 * v2 portable cohort while the original 23-family array stays historical. */
const newerFamilyCases: PortableCase[] = [
  { id: 'family:venn', family: 'venn', cohort: 'family', source: 'venn-beta\n  set Alpha\n  set Beta\n  union Alpha,Beta["Both"]', expected: { accept: true, labels: ['Alpha', 'Beta', 'Both'] } },
  { id: 'family:treeview', family: 'treeview', cohort: 'family', source: 'treeView-beta\n├── Alpha\n│   └── Beta.txt\n└── Gamma.txt', expected: { accept: true, labels: ['Alpha', 'Beta.txt', 'Gamma.txt'] } },
  { id: 'family:wardley', family: 'wardley', cohort: 'family', source: 'wardley-beta\ntitle Value\ncomponent Alpha [0.80, 0.30]\ncomponent Beta [0.40, 0.60]\nAlpha -> Beta', expected: { accept: true, labels: ['Value', 'Alpha', 'Beta'] } },
  { id: 'family:eventmodeling', family: 'eventmodeling', cohort: 'family', source: 'eventmodeling\n\ntf 01 ui AlphaScreen\ntf 02 cmd BetaCommand\ntf 03 evt GammaEvent', expected: { accept: true, labels: ['AlphaScreen', 'BetaCommand', 'GammaEvent'] } },
  { id: 'family:cynefin', family: 'cynefin', cohort: 'family', source: 'cynefin-beta\n  title Alpha\n  complex\n    "Beta"\n  clear\n    "Gamma"\n  complex --> clear : "Delta"', expected: { accept: true, labels: ['Alpha', 'Beta', 'Gamma', 'Delta'] } },
  { id: 'family:railroad', family: 'railroad', cohort: 'family', source: 'railroad-ebnf-beta\nalpha = "beta" | gamma ;\ngamma = "delta" ;', expected: { accept: true, labels: ['alpha', 'beta', 'gamma', 'delta'] } },
  { id: 'family:swimlane', family: 'swimlane', cohort: 'family', source: 'swimlane-beta LR\n  subgraph Alpha\n    A[Beta]\n  end\n  subgraph Gamma\n    B[Delta]\n  end\n  A --> B', expected: { accept: true, labels: ['Alpha', 'Beta', 'Gamma', 'Delta'] } },
  { id: 'family:agentflow', family: 'agentflow', cohort: 'family', source: 'agentflow-beta TB\n  flow alpha["Alpha"]\n    b["Beta"]@{ shape: task }\n    c["Gamma"]@{ shape: tool }\n    b --> c\n  end', expected: { accept: true, labels: ['Alpha', 'Beta', 'Gamma'] } },
  { id: 'family:usecase', family: 'usecase', cohort: 'family', source: 'usecase-beta\nactor Alpha("Alpha")\nsystemBoundary "Beta"\n  Gamma("Gamma")\nend\nAlpha --> Gamma', expected: { accept: true, labels: ['Alpha', 'Beta', 'Gamma'] } },
]
/** First-party external diagrams remain required even when the core bundle omits them. */
export const requiredExternalFamilyCases = (): PortableCase[] => [
  { id: 'family:zenuml', family: 'zenuml', cohort: 'family', source: 'zenuml\ntitle Demo\nAlice->John: Hello John, how are you?\nJohn->Alice: Great!', expected: { accept: true, labels: ['Alice', 'John', 'Hello John, how are you?', 'Great!'] } },
]
/** The original 23-family mark, retained for historical comparisons. */
export const legacyScoredFamilies = (): string[] => [...new Set(familyCases.map(testCase => testCase.family))]
/** The current mark also includes Event Modeling, whose pinned syntax docs do not
 * label the diagram beta or experimental. Required first-party external diagrams
 * also belong in the mark. A family's age is not a maturity rule. */
export const scoredFamilies = (): string[] => [...legacyScoredFamilies(), 'eventmodeling', ...requiredExternalFamilyCases().map(testCase => testCase.family)]
/** Additional documented families imported beside the original portable cohorts. */
export const newerFamilies = (): string[] => newerFamilyCases.map(testCase => testCase.family)
export function familySupportProbe(family: string): PortableCase | undefined {
  const canonical = familyCases.find(testCase => testCase.family === family) ?? newerFamilyCases.find(testCase => testCase.family === family) ?? requiredExternalFamilyCases().find(testCase => testCase.family === family)
  return canonical && { ...canonical, id: `family-support:${family}` }
}
