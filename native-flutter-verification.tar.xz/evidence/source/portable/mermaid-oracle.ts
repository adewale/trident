import { spawn, spawnSync } from 'node:child_process'
import { existsSync, readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { dirname, join, resolve } from 'node:path'
import { createInterface } from 'node:readline'
import { fileURLToPath } from 'node:url'
import pins from '../tool-versions.json' with { type: 'json' }

/** The one pinned Mermaid every run consults: which sources are valid Mermaid, which
 * families exist, Dave's comparator and the tests. It is an installed npm reference
 * (mermaid, its parser and jsdom), never the artifact under measurement. */
export const MERMAID_ORACLE_PIN = {
  version: pins.tools[pins.mermaidOracle.tool as 'mermaid-js/mermaid'].version,
  parser: pins.mermaidOracle.dependencies['@mermaid-js/parser'],
  dom: pins.mermaidOracle.dependencies.jsdom,
}
export interface MermaidOracle {
  directory: string
  version: string
  parserVersion: string
  domVersion: string
  integrity: string | null
}
export interface MermaidVerdict {
  accepted: boolean
  diagramType: string | null
  error: string | null
}

const here = dirname(fileURLToPath(import.meta.url))
const packageName = (directory: string) => {
  try {
    return JSON.parse(readFileSync(join(directory, 'package.json'), 'utf8')).name as string
  } catch {
    return undefined
  }
}
/** Defaults belong to Trident (or the compiled kit), independent of any benchmarked project. */
function harnessRoot(_environment: NodeJS.ProcessEnv): string {
  for (let directory = here, depth = 0; depth < 3; depth++, directory = dirname(directory)) if (packageName(directory) === 'trident') return directory
  return here
}
export const mermaidOracleDirectory = (environment: NodeJS.ProcessEnv = process.env) => resolve(environment.MERMAID_REFERENCE_DIR ?? join(harnessRoot(environment), '../mermaid-reference'))
/** The pinned Mermaid source checkout that upstream-test and Dave corpora read. */
export const mermaidUpstreamDirectory = (environment: NodeJS.ProcessEnv = process.env) => resolve(environment.MERMAID_UPSTREAM_DIR ?? join(harnessRoot(environment), '../mermaid'))

function installHint(_environment: NodeJS.ProcessEnv) {
  return 'Install it with `node commands.ts mermaid:install`, or set MERMAID_REFERENCE_DIR to an existing install.'
}

/** Verify the installed oracle is exactly the pin; throw an actionable refusal otherwise. */
export function admitMermaidOracle(directory: string, environment: NodeJS.ProcessEnv = process.env): MermaidOracle {
  const pin = MERMAID_ORACLE_PIN
  const refuse = (problem: string): never => {
    throw Error(`Trident needs the pinned Mermaid oracle (mermaid ${pin.version}, @mermaid-js/parser ${pin.parser}, jsdom ${pin.dom}) at ${directory}: ${problem}. ${installHint(environment)}`)
  }
  // Node honours package exports, which need not expose package.json; find the directory instead.
  const manifest = (require: NodeJS.Require, name: string) => require.resolve.paths(name)?.map(directory => join(directory, name, 'package.json')).find(path => existsSync(path)) ?? refuse(`${name} is not installed`)
  const version = (require: NodeJS.Require, name: string) => JSON.parse(readFileSync(manifest(require, name), 'utf8')).version as string
  if (!existsSync(join(directory, 'package.json'))) refuse('no install exists')
  const require = createRequire(join(directory, 'package.json'))
  const installed = { version: version(require, 'mermaid'), parserVersion: version(createRequire(manifest(require, 'mermaid')), '@mermaid-js/parser'), domVersion: version(require, 'jsdom') }
  if (installed.version !== pin.version || installed.parserVersion !== pin.parser || installed.domVersion !== pin.dom) refuse(`found mermaid ${installed.version}, @mermaid-js/parser ${installed.parserVersion}, jsdom ${installed.domVersion}`)
  let integrity: string | null = null
  try {
    integrity = JSON.parse(readFileSync(join(directory, 'package-lock.json'), 'utf8')).packages?.['node_modules/mermaid']?.integrity ?? null
  } catch {}
  return { directory, ...installed, integrity }
}

/** Every benchmark run and test run refuses to start without the oracle. Children inherit
 * the admitted directory, so a worker trusts its controller's admission. */
export function assertMermaidOracle(environment: NodeJS.ProcessEnv = process.env): MermaidOracle {
  const directory = mermaidOracleDirectory(environment)
  if (environment.TRIDENT_MERMAID_ORACLE === `${MERMAID_ORACLE_PIN.version} ${directory}` && existsSync(directory)) return { directory, version: MERMAID_ORACLE_PIN.version, parserVersion: MERMAID_ORACLE_PIN.parser, domVersion: MERMAID_ORACLE_PIN.dom, integrity: null }
  const oracle = admitMermaidOracle(directory, environment)
  environment.MERMAID_REFERENCE_DIR = directory
  environment.TRIDENT_MERMAID_ORACLE = `${oracle.version} ${directory}`
  return oracle
}

/** Install the independently pinned reference and its declared dependencies with npm. */
export function installMermaidOracle(directory = mermaidOracleDirectory()): MermaidOracle {
  const pin = MERMAID_ORACLE_PIN
  const result = spawnSync('npm', ['install', '--prefix', directory, '--save-exact', '--no-audit', '--no-fund', '--ignore-scripts', `mermaid@${pin.version}`, `@mermaid-js/parser@${pin.parser}`, `jsdom@${pin.dom}`, `@mermaid-js/mermaid-zenuml@${pins.tools['@mermaid-js/mermaid-zenuml'].version}`], { stdio: 'inherit' })
  if (result.status !== 0) throw Error(`npm could not install the Mermaid oracle into ${directory}`)
  return admitMermaidOracle(directory)
}

export interface MermaidSnapshot extends MermaidVerdict {
  snapshot?: { data: Record<string, unknown>; errors: Record<string, string> }
}
/** ZenUML is an independently versioned first-party addon, never an unpinned CDN. */
export function mermaidZenumlAddon(directory = mermaidOracleDirectory(), configured = process.env.MERMAID_ZENUML_BENCHMARK_ROOT): { root: string; entry: string; version: string } {
  const root = resolve(configured ?? join(directory, 'node_modules/@mermaid-js/mermaid-zenuml'))
  const version = pins.tools['@mermaid-js/mermaid-zenuml'].version
  let manifest: { name?: string; version?: string }
  try { manifest = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')) } catch { throw Error(`ZenUML needs the pinned @mermaid-js/mermaid-zenuml ${version}; rerun mermaid:install or set MERMAID_ZENUML_BENCHMARK_ROOT`) }
  const entry = 'dist/mermaid-zenuml.esm.min.mjs'
  if (manifest.name !== '@mermaid-js/mermaid-zenuml' || manifest.version !== version || !existsSync(join(root, entry))) throw Error(`ZenUML addon must be @mermaid-js/mermaid-zenuml ${version} with its public browser distribution: ${root}`)
  return { root, entry, version }
}
/** Ask the oracle about each source in one Node/jsdom process; with snapshot, also return
 * the diagram DB's getter values, the source of authored label expectations. */
export async function mermaidVerdicts(oracle: MermaidOracle, sources: readonly string[], options: { snapshot?: boolean } = {}): Promise<MermaidSnapshot[]> {
  if (!sources.length) return []
  const addon = sources.some(source => /^\s*zenuml\b/m.test(source)) ? mermaidZenumlAddon(oracle.directory) : undefined
  const child = spawn(process.env.NODE_BIN ?? 'node', [join(here, 'mermaid-oracle-worker.mjs'), oracle.directory, ...(addon ? [join(addon.root, addon.entry)] : [])], { stdio: ['pipe', 'pipe', 'pipe'] })
  let stderr = ''
  child.stderr.on('data', data => (stderr = (stderr + String(data)).slice(-2000)))
  const replies: MermaidSnapshot[] = []
  const lines = createInterface({ input: child.stdout })
  const done = new Promise<void>((resolveDone, reject) => {
    lines.on('line', line => {
      replies.push(JSON.parse(line))
      if (replies.length === sources.length) child.stdin.end()
    })
    child.once('error', reject)
    child.once('close', code => (replies.length === sources.length ? resolveDone() : reject(Error(`Mermaid oracle stopped after ${replies.length}/${sources.length} replies (exit ${code}): ${stderr}`))))
  })
  for (const source of sources) child.stdin.write(JSON.stringify({ source, snapshot: options.snapshot === true }).replace(/[\u2028\u2029]/g, c => `\\u${c.charCodeAt(0).toString(16)}`) + '\n')
  await done
  return replies
}

export interface OracleExpectation {
  id: string
  source: string
  accept: boolean
}
/** Refuse a run whose authored accept/reject expectations the pinned Mermaid contradicts;
 * return the oracle's diagram type for each accepted source. */
export async function assertOracleAgrees(oracle: MermaidOracle, expectations: readonly OracleExpectation[]): Promise<Record<string, string | null>> {
  const verdicts = await mermaidVerdicts(oracle, expectations.map(expectation => expectation.source))
  const disagreements = expectations.flatMap((expectation, index) => (verdicts[index]!.accepted === expectation.accept ? [] : [`${expectation.id} (${expectation.accept ? `rejected: ${verdicts[index]!.error}` : 'accepted'})`]))
  if (disagreements.length) throw Error(`Pinned Mermaid ${oracle.version} contradicts authored expectations; fix these sources before measuring: ${disagreements.join('; ')}`)
  return Object.fromEntries(expectations.flatMap((expectation, index) => (verdicts[index]!.accepted ? [[expectation.id, verdicts[index]!.diagramType]] : [])))
}
