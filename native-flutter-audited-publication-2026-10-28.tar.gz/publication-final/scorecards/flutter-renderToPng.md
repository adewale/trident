# mermaid_flutter 0.3.2: renderToPng / Native Linux Flutter

Suite: historical native-entrypoint campaign; current portable protocol qualification unavailable.
Environment receipt date: Wed Oct 28 18:18:43 UTC 2026. Mode: release.

## Coverage

Main inventory: 31 inputs (29 positive, 2 negative/unavailable-support probes). Attempted distinct main inputs: 31. Unattempted: none.
Supplemental inventory: 1; attempted distinct supplemental inputs: 1.
Planned main input/phase cells: 93; recorded main cells: 93. Sampling counts are printed below and in the per-case CSV.
The scope is public development fixtures, not exhaustive family support or a production holdout. Lineage/branding selection receipt unavailable; this was an explicit two-package investigation.

| Population | Raw | Measured records | Warmups | Preparation failures (raw/measured) |
| --- | --- | --- | --- | --- |
| main | 1953 | 1395 | 558 | 0/0 |
| supplemental edit | 63 | 45 | 18 | 0/0 |
| first use | 5 | 5 | 0 | 0/0 |

## Outcomes

Counts below are records, not semantic passes. Errors include preparation failures; do not add those columns. An unattempted case has unavailable outcome. Unsupported ZenUML and malformed-source rejection are different observations.

| Input | Family | Measured | Nonblank | Errors | Blank | Preparation failures | Qualification |
| --- | --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:tree50 | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:seq20 | sequence | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:class80 | class | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:er40 | er | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:state80 | state | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:flowchart | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:state | state | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:sequence | sequence | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:timeline | timeline | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:class | class | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:er | er | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:journey | journey | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:architecture | architecture | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:xychart | xychart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:pie | pie | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable; manual finding on representative captures: Black triangular corner marks outside the pie circumference in native captures; cause not isolated between library and Impeller/software backend. |
| registry:quadrant | quadrant | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:gantt | gantt | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:mindmap | mindmap | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:gitgraph | gitgraph | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:radar | radar | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:sankey | sankey | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:c4 | c4 | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:packet | packet | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:kanban | kanban | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:requirement | requirement | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:treemap | treemap | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:ishikawa | ishikawa | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:block | block | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| invalid:syntax | invalid | 45 | 0 | 45 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| unsupported:zenuml | zenuml | 45 | 0 | 45 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:tree50-visible-edit | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |

Native nonblank pixels come from widget capture or decoded PNG. Chromium nonblank pixels and hashes come from offscreen SVG rasterization; DOM screenshots cover selected fresh/update samples only. Manual findings apply to representative captures, not every recorded round/phase.

## Cost

Historical protocol qualifications:

- Pele render UPDATE is invalid as an alternating-transition workload: the harness
  restores the original baseline before each call. Its costs describe calls after
  that preparation, not alternating transitions or persistent mounted updates.
- MermaidView repeat includes a forced second frame. Report legacy two-frame cost
  only; it does not establish that an unchanged rebuild requires two render frames.
- Preparation failures are observations, not measured entrypoint calls. In particular,
  Pele render repeat/update can throw while preparing the original negative source.
- Pele nonblank counts and update hashes describe offscreen SVG rasterization.
  Retained DOM screenshots validate selected samples separately, not every call.
  Native widget counts use repaint-boundary captures; PNG counts use decoded output.
- Manual artifact/clipping findings qualify inspected captures. They are not full
  passes, automated per-sample assertions, or proof of a library-wide defect.
- Semantic/model fidelity, A/A calibration and confidence intervals are unavailable.
  This publication does not upgrade the historical campaign to the current portable
  protocol. Missing resources and observers are unavailable, never zero or passes.


Costs use only nonblank non-warmup records, including manually qualified clipped/artifact-bearing output. They do not imply complete-diagram delivery. Retained frame joins supply native raster-completion estimates; UI completion, capture raster, pixel readback and PNG conversion remain separate. renderToPng is an opaque combined export cost; Flutter PNG conversion includes another readback. Browser two-rAF is a paint opportunity, not compositor presentation. Canvas draw may defer work to readback.

Full per-case/phase/stage costs: [CSV](flutter-renderToPng.csv). Sampling is derived per cell; n counts observations, not independent processes or rounds. p95 uses linear interpolation and is descriptive, not a confidence bound.

### Family representatives and scaling within this entrypoint

Each input retains its own row; no aggregate across families or other interfaces. Primary recorded boundary: render_png_ms.

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:class80 | fresh | render_png_ms | 15 | 290.7380 | 328.6141 | historical descriptive cost only |
| core:class80 | repeat | render_png_ms | 15 | 280.3690 | 313.6570 | historical descriptive cost only |
| core:class80 | update | render_png_ms | 15 | 286.1650 | 326.6821 | historical descriptive cost only |
| core:er40 | fresh | render_png_ms | 15 | 412.8680 | 449.0304 | historical descriptive cost only |
| core:er40 | repeat | render_png_ms | 15 | 421.4620 | 445.7840 | historical descriptive cost only |
| core:er40 | update | render_png_ms | 15 | 426.0680 | 454.7586 | historical descriptive cost only |
| core:flow5 | fresh | render_png_ms | 15 | 11.6310 | 13.1104 | historical descriptive cost only |
| core:flow5 | repeat | render_png_ms | 15 | 11.0330 | 14.9353 | historical descriptive cost only |
| core:flow5 | update | render_png_ms | 15 | 11.1020 | 12.7925 | historical descriptive cost only |
| core:seq20 | fresh | render_png_ms | 15 | 60.5020 | 68.9595 | historical descriptive cost only |
| core:seq20 | repeat | render_png_ms | 15 | 61.8190 | 72.3939 | historical descriptive cost only |
| core:seq20 | update | render_png_ms | 15 | 59.2790 | 69.6401 | historical descriptive cost only |
| core:state80 | fresh | render_png_ms | 15 | 73.1290 | 83.4014 | historical descriptive cost only |
| core:state80 | repeat | render_png_ms | 15 | 71.8720 | 88.0746 | historical descriptive cost only |
| core:state80 | update | render_png_ms | 15 | 80.2120 | 97.7534 | historical descriptive cost only |
| core:tree50 | fresh | render_png_ms | 15 | 143.2920 | 148.8629 | historical descriptive cost only |
| core:tree50 | repeat | render_png_ms | 15 | 150.8710 | 169.7565 | historical descriptive cost only |
| core:tree50 | update | render_png_ms | 15 | 149.4100 | 165.7799 | historical descriptive cost only |
| registry:architecture | fresh | render_png_ms | 15 | 12.8660 | 16.0464 | historical descriptive cost only |
| registry:architecture | repeat | render_png_ms | 15 | 13.0080 | 16.1257 | historical descriptive cost only |
| registry:architecture | update | render_png_ms | 15 | 13.5480 | 17.9243 | historical descriptive cost only |
| registry:block | fresh | render_png_ms | 15 | 5.1720 | 7.0461 | historical descriptive cost only |
| registry:block | repeat | render_png_ms | 15 | 5.1650 | 6.5324 | historical descriptive cost only |
| registry:block | update | render_png_ms | 15 | 4.9520 | 5.3815 | historical descriptive cost only |
| registry:c4 | fresh | render_png_ms | 15 | 11.1950 | 15.2874 | historical descriptive cost only |
| registry:c4 | repeat | render_png_ms | 15 | 11.3150 | 13.3534 | historical descriptive cost only |
| registry:c4 | update | render_png_ms | 15 | 10.4360 | 13.2933 | historical descriptive cost only |
| registry:class | fresh | render_png_ms | 15 | 7.8930 | 17.4420 | historical descriptive cost only |
| registry:class | repeat | render_png_ms | 15 | 8.1450 | 9.5355 | historical descriptive cost only |
| registry:class | update | render_png_ms | 15 | 8.0010 | 8.7701 | historical descriptive cost only |
| registry:er | fresh | render_png_ms | 15 | 7.6850 | 9.2564 | historical descriptive cost only |
| registry:er | repeat | render_png_ms | 15 | 7.4430 | 8.6003 | historical descriptive cost only |
| registry:er | update | render_png_ms | 15 | 7.2390 | 8.9827 | historical descriptive cost only |
| registry:flowchart | fresh | render_png_ms | 15 | 9.3290 | 10.7885 | historical descriptive cost only |
| registry:flowchart | repeat | render_png_ms | 15 | 10.1750 | 13.7279 | historical descriptive cost only |
| registry:flowchart | update | render_png_ms | 15 | 9.4360 | 11.9015 | historical descriptive cost only |
| registry:gantt | fresh | render_png_ms | 15 | 14.3460 | 24.0004 | historical descriptive cost only |
| registry:gantt | repeat | render_png_ms | 15 | 15.3780 | 16.6469 | historical descriptive cost only |
| registry:gantt | update | render_png_ms | 15 | 15.3170 | 18.2633 | historical descriptive cost only |
| registry:gitgraph | fresh | render_png_ms | 15 | 9.3210 | 11.7931 | historical descriptive cost only |
| registry:gitgraph | repeat | render_png_ms | 15 | 8.4880 | 11.6004 | historical descriptive cost only |
| registry:gitgraph | update | render_png_ms | 15 | 8.9910 | 11.9734 | historical descriptive cost only |
| registry:ishikawa | fresh | render_png_ms | 15 | 20.5100 | 24.8076 | historical descriptive cost only |
| registry:ishikawa | repeat | render_png_ms | 15 | 20.1300 | 23.4094 | historical descriptive cost only |
| registry:ishikawa | update | render_png_ms | 15 | 21.3430 | 26.7121 | historical descriptive cost only |
| registry:journey | fresh | render_png_ms | 15 | 20.0530 | 23.4780 | historical descriptive cost only |
| registry:journey | repeat | render_png_ms | 15 | 22.0980 | 36.4908 | historical descriptive cost only |
| registry:journey | update | render_png_ms | 15 | 19.7130 | 22.2518 | historical descriptive cost only |
| registry:kanban | fresh | render_png_ms | 15 | 8.1330 | 9.2820 | historical descriptive cost only |
| registry:kanban | repeat | render_png_ms | 15 | 7.8830 | 10.0873 | historical descriptive cost only |
| registry:kanban | update | render_png_ms | 15 | 8.3150 | 13.2762 | historical descriptive cost only |
| registry:mindmap | fresh | render_png_ms | 15 | 19.2350 | 28.1148 | historical descriptive cost only |
| registry:mindmap | repeat | render_png_ms | 15 | 18.5080 | 29.4584 | historical descriptive cost only |
| registry:mindmap | update | render_png_ms | 15 | 17.7380 | 20.0241 | historical descriptive cost only |
| registry:packet | fresh | render_png_ms | 15 | 9.5960 | 12.7772 | historical descriptive cost only |
| registry:packet | repeat | render_png_ms | 15 | 9.4860 | 12.6624 | historical descriptive cost only |
| registry:packet | update | render_png_ms | 15 | 9.7980 | 10.7846 | historical descriptive cost only |
| registry:pie | fresh | render_png_ms | 15 | 17.8900 | 22.5471 | historical descriptive cost only |
| registry:pie | repeat | render_png_ms | 15 | 17.1970 | 18.9202 | historical descriptive cost only |
| registry:pie | update | render_png_ms | 15 | 18.8280 | 23.4359 | historical descriptive cost only |
| registry:quadrant | fresh | render_png_ms | 15 | 19.8540 | 23.2710 | historical descriptive cost only |
| registry:quadrant | repeat | render_png_ms | 15 | 17.9260 | 19.9714 | historical descriptive cost only |
| registry:quadrant | update | render_png_ms | 15 | 17.9420 | 27.0719 | historical descriptive cost only |
| registry:radar | fresh | render_png_ms | 15 | 46.3540 | 52.6066 | historical descriptive cost only |
| registry:radar | repeat | render_png_ms | 15 | 48.3190 | 53.6398 | historical descriptive cost only |
| registry:radar | update | render_png_ms | 15 | 48.8760 | 52.7182 | historical descriptive cost only |
| registry:requirement | fresh | render_png_ms | 15 | 12.3360 | 25.0140 | historical descriptive cost only |
| registry:requirement | repeat | render_png_ms | 15 | 11.9170 | 13.4852 | historical descriptive cost only |
| registry:requirement | update | render_png_ms | 15 | 12.1150 | 13.1770 | historical descriptive cost only |
| registry:sankey | fresh | render_png_ms | 15 | 52.3170 | 67.8667 | historical descriptive cost only |
| registry:sankey | repeat | render_png_ms | 15 | 49.2590 | 59.1443 | historical descriptive cost only |
| registry:sankey | update | render_png_ms | 15 | 48.7680 | 70.0349 | historical descriptive cost only |
| registry:sequence | fresh | render_png_ms | 15 | 10.9970 | 11.4941 | historical descriptive cost only |
| registry:sequence | repeat | render_png_ms | 15 | 12.0690 | 14.5523 | historical descriptive cost only |
| registry:sequence | update | render_png_ms | 15 | 11.2950 | 14.4038 | historical descriptive cost only |
| registry:state | fresh | render_png_ms | 15 | 6.3750 | 9.4565 | historical descriptive cost only |
| registry:state | repeat | render_png_ms | 15 | 6.4830 | 8.6887 | historical descriptive cost only |
| registry:state | update | render_png_ms | 15 | 6.5400 | 8.0519 | historical descriptive cost only |
| registry:timeline | fresh | render_png_ms | 15 | 22.1290 | 33.7449 | historical descriptive cost only |
| registry:timeline | repeat | render_png_ms | 15 | 20.8790 | 29.6332 | historical descriptive cost only |
| registry:timeline | update | render_png_ms | 15 | 21.7390 | 24.9577 | historical descriptive cost only |
| registry:treemap | fresh | render_png_ms | 15 | 41.9930 | 46.4155 | historical descriptive cost only |
| registry:treemap | repeat | render_png_ms | 15 | 43.8600 | 45.6444 | historical descriptive cost only |
| registry:treemap | update | render_png_ms | 15 | 41.1890 | 46.2102 | historical descriptive cost only |
| registry:xychart | fresh | render_png_ms | 15 | 23.3240 | 26.6095 | historical descriptive cost only |
| registry:xychart | repeat | render_png_ms | 15 | 24.2840 | 29.4684 | historical descriptive cost only |
| registry:xychart | update | render_png_ms | 15 | 25.0600 | 27.7478 | historical descriptive cost only |
| core:tree50-visible-edit | fresh | render_png_ms | 15 | 161.7090 | 184.9264 | historical descriptive cost only |
| core:tree50-visible-edit | repeat | render_png_ms | 15 | 147.5880 | 161.8891 | historical descriptive cost only |
| core:tree50-visible-edit | update | render_png_ms | 15 | 156.1780 | 184.1980 | historical descriptive cost only |

### Small-flowchart stage detail

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | fresh | render_png_ms | 15 | 11.6310 | 13.1104 | historical descriptive cost only |
| core:flow5 | fresh | validation_readback_ms | 15 | 1.2620 | 1.4047 | historical descriptive cost only |
| core:flow5 | repeat | render_png_ms | 15 | 11.0330 | 14.9353 | historical descriptive cost only |
| core:flow5 | repeat | validation_readback_ms | 15 | 1.2320 | 1.4691 | historical descriptive cost only |
| core:flow5 | update | render_png_ms | 15 | 11.1020 | 12.7925 | historical descriptive cost only |
| core:flow5 | update | validation_readback_ms | 15 | 1.2290 | 1.4253 | historical descriptive cost only |

### First use (separate population)

New processes after runtime startup; launch/import excluded and OS/font/graphics caches retained. No pooling with initialized-runtime calls.

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | fresh | render_png_ms | 5 | 145.6190 | 169.6616 | historical descriptive cost only |
| core:flow5 | fresh | validation_readback_ms | 5 | 1.9770 | 2.2472 | historical descriptive cost only |

## Evidence

[Publication index](../README.md)

Raw sample files for this interface (shared files retain API/phase/round/sample identities):

- [results/first-use-flutter/renderToPng/0/samples.jsonl](../evidence/results/first-use-flutter/renderToPng/0/samples.jsonl)
- [results/first-use-flutter/renderToPng/1/samples.jsonl](../evidence/results/first-use-flutter/renderToPng/1/samples.jsonl)
- [results/first-use-flutter/renderToPng/2/samples.jsonl](../evidence/results/first-use-flutter/renderToPng/2/samples.jsonl)
- [results/first-use-flutter/renderToPng/3/samples.jsonl](../evidence/results/first-use-flutter/renderToPng/3/samples.jsonl)
- [results/first-use-flutter/renderToPng/4/samples.jsonl](../evidence/results/first-use-flutter/renderToPng/4/samples.jsonl)
- [results/flutter/samples.jsonl](../evidence/results/flutter/samples.jsonl)
- [results/visible-edit-flutter/samples.jsonl](../evidence/results/visible-edit-flutter/samples.jsonl)

- [cases.json](../evidence/cases.json)
- [visible-edit/cases.json](../evidence/visible-edit/cases.json)
- [README.md](../evidence/README.md)
- [app/lib/main.dart](../evidence/app/lib/main.dart)
- [pele.mjs](../evidence/pele.mjs)
- [results/environment.txt](../evidence/results/environment.txt)
- [results/artifacts.sha256](../evidence/results/artifacts.sha256)
- [app/pubspec.lock](../evidence/app/pubspec.lock)
- [results/pele-package-lock.json](../evidence/results/pele-package-lock.json)
- [results/fonts.sha256](../evidence/results/fonts.sha256)
- [results/font-resolution.txt](../evidence/results/font-resolution.txt)
- [results/visual-findings.json](../evidence/results/visual-findings.json)
- [results/updates.csv](../evidence/results/updates.csv)
- [results/failures.jsonl](../evidence/results/failures.jsonl)
- [results/setup-failures.json](../evidence/results/setup-failures.json)
- [results/validation.txt](../evidence/results/validation.txt)
- [results/joined-samples.jsonl](../evidence/results/joined-samples.jsonl)
- [results/first-use.jsonl](../evidence/results/first-use.jsonl)
- [results/summary.csv](../evidence/results/summary.csv)
- [results/coverage.csv](../evidence/results/coverage.csv)
