# Pele 1.9.0: mount / Chromium

Suite: historical native-entrypoint campaign; current portable protocol qualification unavailable.
Environment receipt date: Wed Oct 28 18:18:43 UTC 2026. Mode: headed.

## Coverage

Main inventory: 31 inputs (29 positive, 2 negative/unavailable-support probes). Attempted distinct main inputs: 31. Unattempted: none.
Supplemental inventory: 1; attempted distinct supplemental inputs: 1.
Planned main input/phase cells: 93; recorded main cells: 93. Sampling counts are printed below and in the per-case CSV.
The scope is public development fixtures, not exhaustive family support or a production holdout. Lineage/branding selection receipt unavailable; this was an explicit two-package investigation.

| Population | Raw | Measured records | Warmups | Preparation failures (raw/measured) |
| --- | --- | --- | --- | --- |
| main | 1953 | 1395 | 558 | 0/0 |
| supplemental edit | 63 | 45 | 18 | 0/0 |
| first use | 5 | 5 | 0 | 0/0 |

## Outcomes

Counts below are records, not semantic passes. Errors include preparation failures; do not add those columns. An unattempted case has unavailable outcome. Unsupported ZenUML and malformed-source rejection are different observations.

| Input | Family | Measured | Nonblank | Errors | Blank | Preparation failures | Qualification |
| --- | --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:tree50 | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:seq20 | sequence | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:class80 | class | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:er40 | er | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:state80 | state | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:flowchart | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:state | state | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:sequence | sequence | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:timeline | timeline | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:class | class | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:er | er | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:journey | journey | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:architecture | architecture | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:xychart | xychart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:pie | pie | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:quadrant | quadrant | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:gantt | gantt | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:mindmap | mindmap | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:gitgraph | gitgraph | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:radar | radar | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:sankey | sankey | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:c4 | c4 | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:packet | packet | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:kanban | kanban | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:requirement | requirement | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:treemap | treemap | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:ishikawa | ishikawa | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:block | block | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| invalid:syntax | invalid | 45 | 0 | 45 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| unsupported:zenuml | zenuml | 45 | 0 | 45 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:tree50-visible-edit | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |

Native nonblank pixels come from widget capture or decoded PNG. Chromium nonblank pixels and hashes come from offscreen SVG rasterization; DOM screenshots cover selected fresh/update samples only. Manual findings apply to representative captures, not every recorded round/phase.

## Cost

Historical protocol qualifications:

- Pele render UPDATE is invalid as an alternating-transition workload: the harness
  restores the original baseline before each call. Its costs describe calls after
  that preparation, not alternating transitions or persistent mounted updates.
- MermaidView repeat includes a forced second frame. Report legacy two-frame cost
  only; it does not establish that an unchanged rebuild requires two render frames.
- Preparation failures are observations, not measured entrypoint calls. In particular,
  Pele render repeat/update can throw while preparing the original negative source.
- Pele nonblank counts and update hashes describe offscreen SVG rasterization.
  Retained DOM screenshots validate selected samples separately, not every call.
  Native widget counts use repaint-boundary captures; PNG counts use decoded output.
- Manual artifact/clipping findings qualify inspected captures. They are not full
  passes, automated per-sample assertions, or proof of a library-wide defect.
- Semantic/model fidelity, A/A calibration and confidence intervals are unavailable.
  This publication does not upgrade the historical campaign to the current portable
  protocol. Missing resources and observers are unavailable, never zero or passes.


Costs use only nonblank non-warmup records, including manually qualified clipped/artifact-bearing output. They do not imply complete-diagram delivery. Retained frame joins supply native raster-completion estimates; UI completion, capture raster, pixel readback and PNG conversion remain separate. renderToPng is an opaque combined export cost; Flutter PNG conversion includes another readback. Browser two-rAF is a paint opportunity, not compositor presentation. Canvas draw may defer work to readback.

Full per-case/phase/stage costs: [CSV](pele-mount.csv). Sampling is derived per cell; n counts observations, not independent processes or rounds. p95 uses linear interpolation and is descriptive, not a confidence bound.

### Family representatives and scaling within this entrypoint

Each input retains its own row; no aggregate across families or other interfaces. Primary recorded boundary: api_dom_ms.

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:class80 | fresh | api_dom_ms | 15 | 18.2000 | 22.0500 | historical descriptive cost only |
| core:class80 | repeat | api_dom_ms | 15 | 15.9000 | 22.5400 | historical descriptive cost only |
| core:class80 | update | api_dom_ms | 15 | 16.4000 | 19.9500 | historical descriptive cost only |
| core:er40 | fresh | api_dom_ms | 15 | 14.4000 | 19.7100 | historical descriptive cost only |
| core:er40 | repeat | api_dom_ms | 15 | 11.8000 | 14.5200 | historical descriptive cost only |
| core:er40 | update | api_dom_ms | 15 | 12.2000 | 15.0100 | historical descriptive cost only |
| core:flow5 | fresh | api_dom_ms | 15 | 1.9000 | 3.1200 | historical descriptive cost only |
| core:flow5 | repeat | api_dom_ms | 15 | 1.6000 | 2.7200 | historical descriptive cost only |
| core:flow5 | update | api_dom_ms | 15 | 1.8000 | 2.5300 | historical descriptive cost only |
| core:seq20 | fresh | api_dom_ms | 15 | 2.6000 | 3.6500 | historical descriptive cost only |
| core:seq20 | repeat | api_dom_ms | 15 | 2.2000 | 2.9300 | historical descriptive cost only |
| core:seq20 | update | api_dom_ms | 15 | 2.8000 | 4.1600 | historical descriptive cost only |
| core:state80 | fresh | api_dom_ms | 15 | 9.1000 | 13.2900 | historical descriptive cost only |
| core:state80 | repeat | api_dom_ms | 15 | 8.4000 | 13.3200 | historical descriptive cost only |
| core:state80 | update | api_dom_ms | 15 | 8.8000 | 12.0200 | historical descriptive cost only |
| core:tree50 | fresh | api_dom_ms | 15 | 9.7000 | 17.6500 | historical descriptive cost only |
| core:tree50 | repeat | api_dom_ms | 15 | 8.5000 | 11.5100 | historical descriptive cost only |
| core:tree50 | update | api_dom_ms | 15 | 8.5000 | 13.1800 | historical descriptive cost only |
| registry:architecture | fresh | api_dom_ms | 15 | 1.5000 | 2.1300 | historical descriptive cost only |
| registry:architecture | repeat | api_dom_ms | 15 | 1.3000 | 2.0600 | historical descriptive cost only |
| registry:architecture | update | api_dom_ms | 15 | 1.8000 | 2.1000 | historical descriptive cost only |
| registry:block | fresh | api_dom_ms | 15 | 1.1000 | 2.4600 | historical descriptive cost only |
| registry:block | repeat | api_dom_ms | 15 | 1.1000 | 2.0300 | historical descriptive cost only |
| registry:block | update | api_dom_ms | 15 | 1.2000 | 2.0200 | historical descriptive cost only |
| registry:c4 | fresh | api_dom_ms | 15 | 1.3000 | 2.5600 | historical descriptive cost only |
| registry:c4 | repeat | api_dom_ms | 15 | 1.2000 | 2.2500 | historical descriptive cost only |
| registry:c4 | update | api_dom_ms | 15 | 1.3000 | 2.0000 | historical descriptive cost only |
| registry:class | fresh | api_dom_ms | 15 | 1.5000 | 2.4000 | historical descriptive cost only |
| registry:class | repeat | api_dom_ms | 15 | 1.6000 | 2.3900 | historical descriptive cost only |
| registry:class | update | api_dom_ms | 15 | 1.7000 | 2.3800 | historical descriptive cost only |
| registry:er | fresh | api_dom_ms | 15 | 1.1000 | 1.4000 | historical descriptive cost only |
| registry:er | repeat | api_dom_ms | 15 | 1.1000 | 2.2200 | historical descriptive cost only |
| registry:er | update | api_dom_ms | 15 | 1.5000 | 2.1000 | historical descriptive cost only |
| registry:flowchart | fresh | api_dom_ms | 15 | 1.3000 | 1.7300 | historical descriptive cost only |
| registry:flowchart | repeat | api_dom_ms | 15 | 1.3000 | 1.9900 | historical descriptive cost only |
| registry:flowchart | update | api_dom_ms | 15 | 1.5000 | 2.5100 | historical descriptive cost only |
| registry:gantt | fresh | api_dom_ms | 15 | 1.5000 | 2.4100 | historical descriptive cost only |
| registry:gantt | repeat | api_dom_ms | 15 | 1.3000 | 1.7600 | historical descriptive cost only |
| registry:gantt | update | api_dom_ms | 15 | 1.4000 | 1.8000 | historical descriptive cost only |
| registry:gitgraph | fresh | api_dom_ms | 15 | 1.3000 | 1.8200 | historical descriptive cost only |
| registry:gitgraph | repeat | api_dom_ms | 15 | 1.4000 | 2.3600 | historical descriptive cost only |
| registry:gitgraph | update | api_dom_ms | 15 | 1.6000 | 2.4000 | historical descriptive cost only |
| registry:ishikawa | fresh | api_dom_ms | 15 | 1.2000 | 3.2000 | historical descriptive cost only |
| registry:ishikawa | repeat | api_dom_ms | 15 | 1.2000 | 2.5100 | historical descriptive cost only |
| registry:ishikawa | update | api_dom_ms | 15 | 1.1000 | 1.8300 | historical descriptive cost only |
| registry:journey | fresh | api_dom_ms | 15 | 1.3000 | 1.4300 | historical descriptive cost only |
| registry:journey | repeat | api_dom_ms | 15 | 1.6000 | 2.3900 | historical descriptive cost only |
| registry:journey | update | api_dom_ms | 15 | 1.4000 | 2.1200 | historical descriptive cost only |
| registry:kanban | fresh | api_dom_ms | 15 | 1.2000 | 2.2800 | historical descriptive cost only |
| registry:kanban | repeat | api_dom_ms | 15 | 1.0000 | 1.2300 | historical descriptive cost only |
| registry:kanban | update | api_dom_ms | 15 | 1.1000 | 1.5600 | historical descriptive cost only |
| registry:mindmap | fresh | api_dom_ms | 15 | 1.1000 | 1.6500 | historical descriptive cost only |
| registry:mindmap | repeat | api_dom_ms | 15 | 1.2000 | 1.8000 | historical descriptive cost only |
| registry:mindmap | update | api_dom_ms | 15 | 1.4000 | 2.3600 | historical descriptive cost only |
| registry:packet | fresh | api_dom_ms | 15 | 1.3000 | 1.7000 | historical descriptive cost only |
| registry:packet | repeat | api_dom_ms | 15 | 1.2000 | 1.9600 | historical descriptive cost only |
| registry:packet | update | api_dom_ms | 15 | 1.3000 | 1.6000 | historical descriptive cost only |
| registry:pie | fresh | api_dom_ms | 15 | 1.2000 | 1.6600 | historical descriptive cost only |
| registry:pie | repeat | api_dom_ms | 15 | 1.1000 | 1.8500 | historical descriptive cost only |
| registry:pie | update | api_dom_ms | 15 | 1.4000 | 1.6000 | historical descriptive cost only |
| registry:quadrant | fresh | api_dom_ms | 15 | 1.3000 | 1.4300 | historical descriptive cost only |
| registry:quadrant | repeat | api_dom_ms | 15 | 1.2000 | 1.5000 | historical descriptive cost only |
| registry:quadrant | update | api_dom_ms | 15 | 1.4000 | 1.6300 | historical descriptive cost only |
| registry:radar | fresh | api_dom_ms | 15 | 1.4000 | 2.1900 | historical descriptive cost only |
| registry:radar | repeat | api_dom_ms | 15 | 1.4000 | 3.7800 | historical descriptive cost only |
| registry:radar | update | api_dom_ms | 15 | 1.4000 | 1.9700 | historical descriptive cost only |
| registry:requirement | fresh | api_dom_ms | 15 | 1.6000 | 2.5400 | historical descriptive cost only |
| registry:requirement | repeat | api_dom_ms | 15 | 1.7000 | 1.9900 | historical descriptive cost only |
| registry:requirement | update | api_dom_ms | 15 | 1.7000 | 2.1900 | historical descriptive cost only |
| registry:sankey | fresh | api_dom_ms | 15 | 1.5000 | 2.5300 | historical descriptive cost only |
| registry:sankey | repeat | api_dom_ms | 15 | 1.7000 | 2.8500 | historical descriptive cost only |
| registry:sankey | update | api_dom_ms | 15 | 1.7000 | 2.3200 | historical descriptive cost only |
| registry:sequence | fresh | api_dom_ms | 15 | 1.2000 | 1.6300 | historical descriptive cost only |
| registry:sequence | repeat | api_dom_ms | 15 | 1.1000 | 3.4800 | historical descriptive cost only |
| registry:sequence | update | api_dom_ms | 15 | 1.3000 | 2.0500 | historical descriptive cost only |
| registry:state | fresh | api_dom_ms | 15 | 1.1000 | 1.8600 | historical descriptive cost only |
| registry:state | repeat | api_dom_ms | 15 | 1.1000 | 2.1100 | historical descriptive cost only |
| registry:state | update | api_dom_ms | 15 | 1.3000 | 2.2400 | historical descriptive cost only |
| registry:timeline | fresh | api_dom_ms | 15 | 1.2000 | 1.9500 | historical descriptive cost only |
| registry:timeline | repeat | api_dom_ms | 15 | 1.0000 | 1.3000 | historical descriptive cost only |
| registry:timeline | update | api_dom_ms | 15 | 1.1000 | 1.3300 | historical descriptive cost only |
| registry:treemap | fresh | api_dom_ms | 15 | 1.1000 | 1.9000 | historical descriptive cost only |
| registry:treemap | repeat | api_dom_ms | 15 | 1.4000 | 2.0000 | historical descriptive cost only |
| registry:treemap | update | api_dom_ms | 15 | 1.4000 | 1.8600 | historical descriptive cost only |
| registry:xychart | fresh | api_dom_ms | 15 | 1.4000 | 2.5800 | historical descriptive cost only |
| registry:xychart | repeat | api_dom_ms | 15 | 1.4000 | 1.9300 | historical descriptive cost only |
| registry:xychart | update | api_dom_ms | 15 | 1.8000 | 2.9500 | historical descriptive cost only |
| core:tree50-visible-edit | fresh | api_dom_ms | 15 | 9.4000 | 13.0600 | historical descriptive cost only |
| core:tree50-visible-edit | repeat | api_dom_ms | 15 | 7.9000 | 10.9900 | historical descriptive cost only |
| core:tree50-visible-edit | update | api_dom_ms | 15 | 10.1000 | 14.4000 | historical descriptive cost only |

### Small-flowchart stage detail

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | fresh | api_dom_ms | 15 | 1.9000 | 3.1200 | historical descriptive cost only |
| core:flow5 | fresh | canvas_draw_ms | 15 | 0.5000 | 0.8000 | historical descriptive cost only |
| core:flow5 | fresh | mount_update_ms | 15 | 1.9000 | 3.1200 | historical descriptive cost only |
| core:flow5 | fresh | pixel_readback_ms | 15 | 0.3000 | 0.7000 | historical descriptive cost only |
| core:flow5 | fresh | png_encode_ms | 15 | 1.9000 | 2.7200 | historical descriptive cost only |
| core:flow5 | fresh | svg_decode_ms | 15 | 4.1000 | 6.1500 | historical descriptive cost only |
| core:flow5 | fresh | two_raf_ms | 15 | 19.6000 | 23.6700 | historical descriptive cost only |
| core:flow5 | repeat | api_dom_ms | 15 | 1.6000 | 2.7200 | historical descriptive cost only |
| core:flow5 | repeat | canvas_draw_ms | 15 | 0.6000 | 2.0600 | historical descriptive cost only |
| core:flow5 | repeat | mount_update_ms | 15 | 1.6000 | 2.7200 | historical descriptive cost only |
| core:flow5 | repeat | pixel_readback_ms | 15 | 0.3000 | 0.7600 | historical descriptive cost only |
| core:flow5 | repeat | png_encode_ms | 15 | 2.0000 | 2.6000 | historical descriptive cost only |
| core:flow5 | repeat | svg_decode_ms | 15 | 4.1000 | 5.3500 | historical descriptive cost only |
| core:flow5 | repeat | two_raf_ms | 15 | 19.2000 | 21.5400 | historical descriptive cost only |
| core:flow5 | update | api_dom_ms | 15 | 1.8000 | 2.5300 | historical descriptive cost only |
| core:flow5 | update | canvas_draw_ms | 15 | 0.5000 | 1.0500 | historical descriptive cost only |
| core:flow5 | update | mount_update_ms | 15 | 1.8000 | 2.5300 | historical descriptive cost only |
| core:flow5 | update | pixel_readback_ms | 15 | 0.3000 | 0.5600 | historical descriptive cost only |
| core:flow5 | update | png_encode_ms | 15 | 2.0000 | 2.6600 | historical descriptive cost only |
| core:flow5 | update | svg_decode_ms | 15 | 4.3000 | 7.5100 | historical descriptive cost only |
| core:flow5 | update | two_raf_ms | 15 | 20.8000 | 24.8600 | historical descriptive cost only |

### First use (separate population)

New processes after runtime startup; launch/import excluded and OS/font/graphics caches retained. No pooling with initialized-runtime calls.

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | fresh | api_dom_ms | 5 | 33.3000 | 52.0400 | historical descriptive cost only |
| core:flow5 | fresh | canvas_draw_ms | 5 | 4.5000 | 22.4600 | historical descriptive cost only |
| core:flow5 | fresh | mount_update_ms | 5 | 33.2000 | 52.0200 | historical descriptive cost only |
| core:flow5 | fresh | pixel_readback_ms | 5 | 0.6000 | 0.8800 | historical descriptive cost only |
| core:flow5 | fresh | png_encode_ms | 5 | 2.5000 | 3.0400 | historical descriptive cost only |
| core:flow5 | fresh | svg_decode_ms | 5 | 7.4000 | 9.2600 | historical descriptive cost only |
| core:flow5 | fresh | two_raf_ms | 5 | 238.1000 | 246.4600 | historical descriptive cost only |

## Evidence

[Publication index](../README.md)

Raw sample files for this interface (shared files retain API/phase/round/sample identities):

- [results/first-use-pele/mount/0/samples.jsonl](../evidence/results/first-use-pele/mount/0/samples.jsonl)
- [results/first-use-pele/mount/1/samples.jsonl](../evidence/results/first-use-pele/mount/1/samples.jsonl)
- [results/first-use-pele/mount/2/samples.jsonl](../evidence/results/first-use-pele/mount/2/samples.jsonl)
- [results/first-use-pele/mount/3/samples.jsonl](../evidence/results/first-use-pele/mount/3/samples.jsonl)
- [results/first-use-pele/mount/4/samples.jsonl](../evidence/results/first-use-pele/mount/4/samples.jsonl)
- [results/pele/samples.jsonl](../evidence/results/pele/samples.jsonl)
- [results/visible-edit-pele/samples.jsonl](../evidence/results/visible-edit-pele/samples.jsonl)

- [cases.json](../evidence/cases.json)
- [visible-edit/cases.json](../evidence/visible-edit/cases.json)
- [README.md](../evidence/README.md)
- [app/lib/main.dart](../evidence/app/lib/main.dart)
- [pele.mjs](../evidence/pele.mjs)
- [results/environment.txt](../evidence/results/environment.txt)
- [results/artifacts.sha256](../evidence/results/artifacts.sha256)
- [app/pubspec.lock](../evidence/app/pubspec.lock)
- [results/pele-package-lock.json](../evidence/results/pele-package-lock.json)
- [results/fonts.sha256](../evidence/results/fonts.sha256)
- [results/font-resolution.txt](../evidence/results/font-resolution.txt)
- [results/visual-findings.json](../evidence/results/visual-findings.json)
- [results/updates.csv](../evidence/results/updates.csv)
- [results/failures.jsonl](../evidence/results/failures.jsonl)
- [results/setup-failures.json](../evidence/results/setup-failures.json)
- [results/validation.txt](../evidence/results/validation.txt)
- [results/joined-samples.jsonl](../evidence/results/joined-samples.jsonl)
- [results/first-use.jsonl](../evidence/results/first-use.jsonl)
- [results/summary.csv](../evidence/results/summary.csv)
- [results/coverage.csv](../evidence/results/coverage.csv)
