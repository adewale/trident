# Pele 1.9.0: render / Chromium

Suite: historical native-entrypoint campaign; current portable protocol qualification unavailable.
Environment receipt date: Wed Oct 28 18:18:43 UTC 2026. Mode: headed.

## Coverage

Main inventory: 31 inputs (29 positive, 2 negative/unavailable-support probes). Attempted distinct main inputs: 31. Unattempted: none.
Supplemental inventory: 1; attempted distinct supplemental inputs: 1.
Planned main input/phase cells: 93; recorded main cells: 93. Sampling counts are printed below and in the per-case CSV.
The scope is public development fixtures, not exhaustive family support or a production holdout. Lineage/branding selection receipt unavailable; this was an explicit two-package investigation.

| Population | Raw | Measured records | Warmups | Preparation failures (raw/measured) |
| --- | --- | --- | --- | --- |
| main | 1953 | 1395 | 558 | 84/60 |
| supplemental edit | 63 | 45 | 18 | 0/0 |
| first use | 5 | 5 | 0 | 0/0 |

## Outcomes

Counts below are records, not semantic passes. Errors include preparation failures; do not add those columns. An unattempted case has unavailable outcome. Unsupported ZenUML and malformed-source rejection are different observations.

| Input | Family | Measured | Nonblank | Errors | Blank | Preparation failures | Qualification |
| --- | --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:tree50 | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:seq20 | sequence | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:class80 | class | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:er40 | er | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:state80 | state | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:flowchart | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:state | state | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:sequence | sequence | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:timeline | timeline | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:class | class | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:er | er | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:journey | journey | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:architecture | architecture | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:xychart | xychart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:pie | pie | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:quadrant | quadrant | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:gantt | gantt | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:mindmap | mindmap | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:gitgraph | gitgraph | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:radar | radar | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:sankey | sankey | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:c4 | c4 | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:packet | packet | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:kanban | kanban | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:requirement | requirement | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:treemap | treemap | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:ishikawa | ishikawa | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:block | block | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| invalid:syntax | invalid | 45 | 0 | 45 | 0 | 30 | nonblank only; semantic/fidelity qualification unavailable |
| unsupported:zenuml | zenuml | 45 | 0 | 45 | 0 | 30 | nonblank only; semantic/fidelity qualification unavailable |
| core:tree50-visible-edit | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |

Native nonblank pixels come from widget capture or decoded PNG. Chromium nonblank pixels and hashes come from offscreen SVG rasterization; DOM screenshots cover selected fresh/update samples only. Manual findings apply to representative captures, not every recorded round/phase.

## Cost

Historical protocol qualifications:

- Pele render UPDATE is invalid as an alternating-transition workload: the harness
  restores the original baseline before each call. Its costs describe calls after
  that preparation, not alternating transitions or persistent mounted updates.
- MermaidView repeat includes a forced second frame. Report legacy two-frame cost
  only; it does not establish that an unchanged rebuild requires two render frames.
- Preparation failures are observations, not measured entrypoint calls. In particular,
  Pele render repeat/update can throw while preparing the original negative source.
- Pele nonblank counts and update hashes describe offscreen SVG rasterization.
  Retained DOM screenshots validate selected samples separately, not every call.
  Native widget counts use repaint-boundary captures; PNG counts use decoded output.
- Manual artifact/clipping findings qualify inspected captures. They are not full
  passes, automated per-sample assertions, or proof of a library-wide defect.
- Semantic/model fidelity, A/A calibration and confidence intervals are unavailable.
  This publication does not upgrade the historical campaign to the current portable
  protocol. Missing resources and observers are unavailable, never zero or passes.


Costs use only nonblank non-warmup records, including manually qualified clipped/artifact-bearing output. They do not imply complete-diagram delivery. Retained frame joins supply native raster-completion estimates; UI completion, capture raster, pixel readback and PNG conversion remain separate. renderToPng is an opaque combined export cost; Flutter PNG conversion includes another readback. Browser two-rAF is a paint opportunity, not compositor presentation. Canvas draw may defer work to readback.

Full per-case/phase/stage costs: [CSV](pele-render.csv). Sampling is derived per cell; n counts observations, not independent processes or rounds. p95 uses linear interpolation and is descriptive, not a confidence bound.

### Family representatives and scaling within this entrypoint

Each input retains its own row; no aggregate across families or other interfaces. Primary recorded boundary: api_dom_ms.

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:class80 | fresh | api_dom_ms | 15 | 6.2000 | 9.2900 | historical descriptive cost only |
| core:class80 | repeat | api_dom_ms | 15 | 6.3000 | 7.8000 | historical descriptive cost only |
| core:class80 | update | api_dom_ms | 15 | 5.4000 | 8.0800 | alternating_transition_invalid_original_baseline_per_call |
| core:er40 | fresh | api_dom_ms | 15 | 5.2000 | 6.5500 | historical descriptive cost only |
| core:er40 | repeat | api_dom_ms | 15 | 5.5000 | 9.8700 | historical descriptive cost only |
| core:er40 | update | api_dom_ms | 15 | 5.6000 | 7.9600 | alternating_transition_invalid_original_baseline_per_call |
| core:flow5 | fresh | api_dom_ms | 15 | 1.4000 | 2.5700 | historical descriptive cost only |
| core:flow5 | repeat | api_dom_ms | 15 | 1.2000 | 1.7800 | historical descriptive cost only |
| core:flow5 | update | api_dom_ms | 15 | 1.1000 | 2.5500 | alternating_transition_invalid_original_baseline_per_call |
| core:seq20 | fresh | api_dom_ms | 15 | 1.0000 | 2.0900 | historical descriptive cost only |
| core:seq20 | repeat | api_dom_ms | 15 | 1.2000 | 1.5300 | historical descriptive cost only |
| core:seq20 | update | api_dom_ms | 15 | 1.1000 | 1.7000 | alternating_transition_invalid_original_baseline_per_call |
| core:state80 | fresh | api_dom_ms | 15 | 4.5000 | 6.4200 | historical descriptive cost only |
| core:state80 | repeat | api_dom_ms | 15 | 5.1000 | 6.5500 | historical descriptive cost only |
| core:state80 | update | api_dom_ms | 15 | 4.2000 | 6.6500 | alternating_transition_invalid_original_baseline_per_call |
| core:tree50 | fresh | api_dom_ms | 15 | 3.3000 | 4.8300 | historical descriptive cost only |
| core:tree50 | repeat | api_dom_ms | 15 | 3.7000 | 5.2200 | historical descriptive cost only |
| core:tree50 | update | api_dom_ms | 15 | 3.4000 | 6.0700 | alternating_transition_invalid_original_baseline_per_call |
| registry:architecture | fresh | api_dom_ms | 15 | 0.9000 | 1.5400 | historical descriptive cost only |
| registry:architecture | repeat | api_dom_ms | 15 | 0.8000 | 1.2500 | historical descriptive cost only |
| registry:architecture | update | api_dom_ms | 15 | 0.8000 | 1.1600 | alternating_transition_invalid_original_baseline_per_call |
| registry:block | fresh | api_dom_ms | 15 | 0.6000 | 1.0900 | historical descriptive cost only |
| registry:block | repeat | api_dom_ms | 15 | 0.6000 | 1.1600 | historical descriptive cost only |
| registry:block | update | api_dom_ms | 15 | 0.5000 | 0.9000 | alternating_transition_invalid_original_baseline_per_call |
| registry:c4 | fresh | api_dom_ms | 15 | 0.7000 | 1.3400 | historical descriptive cost only |
| registry:c4 | repeat | api_dom_ms | 15 | 0.8000 | 1.0000 | historical descriptive cost only |
| registry:c4 | update | api_dom_ms | 15 | 0.7000 | 0.8300 | alternating_transition_invalid_original_baseline_per_call |
| registry:class | fresh | api_dom_ms | 15 | 0.9000 | 1.8500 | historical descriptive cost only |
| registry:class | repeat | api_dom_ms | 15 | 1.1000 | 1.7200 | historical descriptive cost only |
| registry:class | update | api_dom_ms | 15 | 0.9000 | 1.2300 | alternating_transition_invalid_original_baseline_per_call |
| registry:er | fresh | api_dom_ms | 15 | 0.5000 | 0.8300 | historical descriptive cost only |
| registry:er | repeat | api_dom_ms | 15 | 0.8000 | 1.2900 | historical descriptive cost only |
| registry:er | update | api_dom_ms | 15 | 0.8000 | 1.5800 | alternating_transition_invalid_original_baseline_per_call |
| registry:flowchart | fresh | api_dom_ms | 15 | 0.8000 | 2.4400 | historical descriptive cost only |
| registry:flowchart | repeat | api_dom_ms | 15 | 0.9000 | 1.2300 | historical descriptive cost only |
| registry:flowchart | update | api_dom_ms | 15 | 0.8000 | 1.0000 | alternating_transition_invalid_original_baseline_per_call |
| registry:gantt | fresh | api_dom_ms | 15 | 0.8000 | 1.1000 | historical descriptive cost only |
| registry:gantt | repeat | api_dom_ms | 15 | 0.7000 | 1.1300 | historical descriptive cost only |
| registry:gantt | update | api_dom_ms | 15 | 0.9000 | 2.3400 | alternating_transition_invalid_original_baseline_per_call |
| registry:gitgraph | fresh | api_dom_ms | 15 | 0.7000 | 1.2000 | historical descriptive cost only |
| registry:gitgraph | repeat | api_dom_ms | 15 | 0.7000 | 0.8300 | historical descriptive cost only |
| registry:gitgraph | update | api_dom_ms | 15 | 0.7000 | 0.8300 | alternating_transition_invalid_original_baseline_per_call |
| registry:ishikawa | fresh | api_dom_ms | 15 | 0.5000 | 0.6300 | historical descriptive cost only |
| registry:ishikawa | repeat | api_dom_ms | 15 | 0.6000 | 0.8300 | historical descriptive cost only |
| registry:ishikawa | update | api_dom_ms | 15 | 0.6000 | 0.8300 | alternating_transition_invalid_original_baseline_per_call |
| registry:journey | fresh | api_dom_ms | 15 | 0.6000 | 0.9000 | historical descriptive cost only |
| registry:journey | repeat | api_dom_ms | 15 | 0.7000 | 0.8600 | historical descriptive cost only |
| registry:journey | update | api_dom_ms | 15 | 0.7000 | 1.0200 | alternating_transition_invalid_original_baseline_per_call |
| registry:kanban | fresh | api_dom_ms | 15 | 0.4000 | 0.7800 | historical descriptive cost only |
| registry:kanban | repeat | api_dom_ms | 15 | 0.7000 | 1.1300 | historical descriptive cost only |
| registry:kanban | update | api_dom_ms | 15 | 0.5000 | 0.8300 | alternating_transition_invalid_original_baseline_per_call |
| registry:mindmap | fresh | api_dom_ms | 15 | 0.5000 | 0.6300 | historical descriptive cost only |
| registry:mindmap | repeat | api_dom_ms | 15 | 0.6000 | 2.4000 | historical descriptive cost only |
| registry:mindmap | update | api_dom_ms | 15 | 0.6000 | 0.8300 | alternating_transition_invalid_original_baseline_per_call |
| registry:packet | fresh | api_dom_ms | 15 | 0.5000 | 1.0200 | historical descriptive cost only |
| registry:packet | repeat | api_dom_ms | 15 | 0.6000 | 0.9600 | historical descriptive cost only |
| registry:packet | update | api_dom_ms | 15 | 0.5000 | 0.6300 | alternating_transition_invalid_original_baseline_per_call |
| registry:pie | fresh | api_dom_ms | 15 | 0.5000 | 1.8100 | historical descriptive cost only |
| registry:pie | repeat | api_dom_ms | 15 | 0.7000 | 0.9600 | historical descriptive cost only |
| registry:pie | update | api_dom_ms | 15 | 0.7000 | 1.2500 | alternating_transition_invalid_original_baseline_per_call |
| registry:quadrant | fresh | api_dom_ms | 15 | 0.6000 | 1.2300 | historical descriptive cost only |
| registry:quadrant | repeat | api_dom_ms | 15 | 0.6000 | 0.9000 | historical descriptive cost only |
| registry:quadrant | update | api_dom_ms | 15 | 0.6000 | 0.7000 | alternating_transition_invalid_original_baseline_per_call |
| registry:radar | fresh | api_dom_ms | 15 | 0.7000 | 1.0500 | historical descriptive cost only |
| registry:radar | repeat | api_dom_ms | 15 | 0.6000 | 3.0400 | historical descriptive cost only |
| registry:radar | update | api_dom_ms | 15 | 0.7000 | 0.8300 | alternating_transition_invalid_original_baseline_per_call |
| registry:requirement | fresh | api_dom_ms | 15 | 0.9000 | 1.2600 | historical descriptive cost only |
| registry:requirement | repeat | api_dom_ms | 15 | 0.9000 | 1.3900 | historical descriptive cost only |
| registry:requirement | update | api_dom_ms | 15 | 0.9000 | 1.1000 | alternating_transition_invalid_original_baseline_per_call |
| registry:sankey | fresh | api_dom_ms | 15 | 0.6000 | 1.1000 | historical descriptive cost only |
| registry:sankey | repeat | api_dom_ms | 15 | 0.6000 | 0.8000 | historical descriptive cost only |
| registry:sankey | update | api_dom_ms | 15 | 0.6000 | 0.9600 | alternating_transition_invalid_original_baseline_per_call |
| registry:sequence | fresh | api_dom_ms | 15 | 0.6000 | 0.7900 | historical descriptive cost only |
| registry:sequence | repeat | api_dom_ms | 15 | 0.6000 | 0.7300 | historical descriptive cost only |
| registry:sequence | update | api_dom_ms | 15 | 0.7000 | 0.9600 | alternating_transition_invalid_original_baseline_per_call |
| registry:state | fresh | api_dom_ms | 15 | 0.6000 | 0.9300 | historical descriptive cost only |
| registry:state | repeat | api_dom_ms | 15 | 0.8000 | 1.1300 | historical descriptive cost only |
| registry:state | update | api_dom_ms | 15 | 0.9000 | 1.2000 | alternating_transition_invalid_original_baseline_per_call |
| registry:timeline | fresh | api_dom_ms | 15 | 0.5000 | 0.6600 | historical descriptive cost only |
| registry:timeline | repeat | api_dom_ms | 15 | 0.6000 | 0.8000 | historical descriptive cost only |
| registry:timeline | update | api_dom_ms | 15 | 0.6000 | 1.1600 | alternating_transition_invalid_original_baseline_per_call |
| registry:treemap | fresh | api_dom_ms | 15 | 0.5000 | 0.8000 | historical descriptive cost only |
| registry:treemap | repeat | api_dom_ms | 15 | 0.6000 | 0.7000 | historical descriptive cost only |
| registry:treemap | update | api_dom_ms | 15 | 0.6000 | 0.8600 | alternating_transition_invalid_original_baseline_per_call |
| registry:xychart | fresh | api_dom_ms | 15 | 0.6000 | 0.9000 | historical descriptive cost only |
| registry:xychart | repeat | api_dom_ms | 15 | 0.6000 | 2.3000 | historical descriptive cost only |
| registry:xychart | update | api_dom_ms | 15 | 0.6000 | 1.0200 | alternating_transition_invalid_original_baseline_per_call |
| core:tree50-visible-edit | fresh | api_dom_ms | 15 | 4.2000 | 6.2200 | historical descriptive cost only |
| core:tree50-visible-edit | repeat | api_dom_ms | 15 | 3.3000 | 4.9600 | historical descriptive cost only |
| core:tree50-visible-edit | update | api_dom_ms | 15 | 2.9000 | 6.5700 | alternating_transition_invalid_original_baseline_per_call |

### Small-flowchart stage detail

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | fresh | api_dom_ms | 15 | 1.4000 | 2.5700 | historical descriptive cost only |
| core:flow5 | fresh | canvas_draw_ms | 15 | 0.5000 | 0.6000 | historical descriptive cost only |
| core:flow5 | fresh | dom_insertion_ms | 15 | 0.4000 | 0.5300 | historical descriptive cost only |
| core:flow5 | fresh | pixel_readback_ms | 15 | 0.3000 | 0.4300 | historical descriptive cost only |
| core:flow5 | fresh | png_encode_ms | 15 | 2.0000 | 6.5200 | historical descriptive cost only |
| core:flow5 | fresh | svg_decode_ms | 15 | 4.1000 | 7.8200 | historical descriptive cost only |
| core:flow5 | fresh | svg_return_ms | 15 | 1.0000 | 2.1700 | historical descriptive cost only |
| core:flow5 | fresh | two_raf_ms | 15 | 18.5000 | 24.8800 | historical descriptive cost only |
| core:flow5 | repeat | api_dom_ms | 15 | 1.2000 | 1.7800 | historical descriptive cost only |
| core:flow5 | repeat | canvas_draw_ms | 15 | 0.5000 | 1.0900 | historical descriptive cost only |
| core:flow5 | repeat | dom_insertion_ms | 15 | 0.5000 | 0.6000 | historical descriptive cost only |
| core:flow5 | repeat | pixel_readback_ms | 15 | 0.3000 | 0.4300 | historical descriptive cost only |
| core:flow5 | repeat | png_encode_ms | 15 | 2.4000 | 4.1400 | historical descriptive cost only |
| core:flow5 | repeat | svg_decode_ms | 15 | 4.1000 | 5.4000 | historical descriptive cost only |
| core:flow5 | repeat | svg_return_ms | 15 | 0.7000 | 1.2100 | historical descriptive cost only |
| core:flow5 | repeat | two_raf_ms | 15 | 33.3000 | 34.1600 | historical descriptive cost only |
| core:flow5 | update | api_dom_ms | 15 | 1.1000 | 2.5500 | alternating_transition_invalid_original_baseline_per_call |
| core:flow5 | update | canvas_draw_ms | 15 | 0.6000 | 0.7300 | alternating_transition_invalid_original_baseline_per_call |
| core:flow5 | update | dom_insertion_ms | 15 | 0.5000 | 0.7000 | alternating_transition_invalid_original_baseline_per_call |
| core:flow5 | update | pixel_readback_ms | 15 | 0.3000 | 0.5000 | alternating_transition_invalid_original_baseline_per_call |
| core:flow5 | update | png_encode_ms | 15 | 1.8000 | 3.1500 | alternating_transition_invalid_original_baseline_per_call |
| core:flow5 | update | svg_decode_ms | 15 | 4.3000 | 6.4400 | alternating_transition_invalid_original_baseline_per_call |
| core:flow5 | update | svg_return_ms | 15 | 0.7000 | 1.9800 | alternating_transition_invalid_original_baseline_per_call |
| core:flow5 | update | two_raf_ms | 15 | 33.5000 | 34.0900 | alternating_transition_invalid_original_baseline_per_call |

### First use (separate population)

New processes after runtime startup; launch/import excluded and OS/font/graphics caches retained. No pooling with initialized-runtime calls.

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | fresh | api_dom_ms | 5 | 36.8000 | 42.9200 | historical descriptive cost only |
| core:flow5 | fresh | canvas_draw_ms | 5 | 3.7000 | 15.1200 | historical descriptive cost only |
| core:flow5 | fresh | dom_insertion_ms | 5 | 1.7000 | 3.9600 | historical descriptive cost only |
| core:flow5 | fresh | pixel_readback_ms | 5 | 0.7000 | 1.2800 | historical descriptive cost only |
| core:flow5 | fresh | png_encode_ms | 5 | 2.5000 | 5.9200 | historical descriptive cost only |
| core:flow5 | fresh | svg_decode_ms | 5 | 8.3000 | 10.2800 | historical descriptive cost only |
| core:flow5 | fresh | svg_return_ms | 5 | 34.6000 | 41.4600 | historical descriptive cost only |
| core:flow5 | fresh | two_raf_ms | 5 | 242.0000 | 255.0800 | historical descriptive cost only |

## Evidence

[Publication index](../README.md)

Raw sample files for this interface (shared files retain API/phase/round/sample identities):

- [results/first-use-pele/render/0/samples.jsonl](../evidence/results/first-use-pele/render/0/samples.jsonl)
- [results/first-use-pele/render/1/samples.jsonl](../evidence/results/first-use-pele/render/1/samples.jsonl)
- [results/first-use-pele/render/2/samples.jsonl](../evidence/results/first-use-pele/render/2/samples.jsonl)
- [results/first-use-pele/render/3/samples.jsonl](../evidence/results/first-use-pele/render/3/samples.jsonl)
- [results/first-use-pele/render/4/samples.jsonl](../evidence/results/first-use-pele/render/4/samples.jsonl)
- [results/pele/samples.jsonl](../evidence/results/pele/samples.jsonl)
- [results/visible-edit-pele/samples.jsonl](../evidence/results/visible-edit-pele/samples.jsonl)

- [cases.json](../evidence/cases.json)
- [visible-edit/cases.json](../evidence/visible-edit/cases.json)
- [README.md](../evidence/README.md)
- [app/lib/main.dart](../evidence/app/lib/main.dart)
- [pele.mjs](../evidence/pele.mjs)
- [results/environment.txt](../evidence/results/environment.txt)
- [results/artifacts.sha256](../evidence/results/artifacts.sha256)
- [app/pubspec.lock](../evidence/app/pubspec.lock)
- [results/pele-package-lock.json](../evidence/results/pele-package-lock.json)
- [results/fonts.sha256](../evidence/results/fonts.sha256)
- [results/font-resolution.txt](../evidence/results/font-resolution.txt)
- [results/visual-findings.json](../evidence/results/visual-findings.json)
- [results/updates.csv](../evidence/results/updates.csv)
- [results/failures.jsonl](../evidence/results/failures.jsonl)
- [results/setup-failures.json](../evidence/results/setup-failures.json)
- [results/validation.txt](../evidence/results/validation.txt)
- [results/joined-samples.jsonl](../evidence/results/joined-samples.jsonl)
- [results/first-use.jsonl](../evidence/results/first-use.jsonl)
- [results/summary.csv](../evidence/results/summary.csv)
- [results/coverage.csv](../evidence/results/coverage.csv)
