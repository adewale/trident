# mermaid_flutter 0.3.2: MermaidView / Native Linux Flutter

Suite: historical native-entrypoint campaign; current portable protocol qualification unavailable.
Environment receipt date: Wed Oct 28 18:18:43 UTC 2026. Mode: release.

## Coverage

Main inventory: 31 inputs (29 positive, 2 negative/unavailable-support probes). Attempted distinct main inputs: 31. Unattempted: none.
Supplemental inventory: 1; attempted distinct supplemental inputs: 1.
Planned main input/phase cells: 93; recorded main cells: 93. Sampling counts are printed below and in the per-case CSV.
The scope is public development fixtures, not exhaustive family support or a production holdout. Lineage/branding selection receipt unavailable; this was an explicit two-package investigation.

| Population | Raw | Measured records | Warmups | Preparation failures (raw/measured) |
| --- | --- | --- | --- | --- |
| main | 1953 | 1395 | 558 | 0/0 |
| supplemental edit | 63 | 45 | 18 | 0/0 |
| first use | 5 | 5 | 0 | 0/0 |

## Outcomes

Counts below are records, not semantic passes. Errors include preparation failures; do not add those columns. An unattempted case has unavailable outcome. Unsupported ZenUML and malformed-source rejection are different observations.

| Input | Family | Measured | Nonblank | Errors | Blank | Preparation failures | Qualification |
| --- | --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:tree50 | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable; manual finding on representative captures: Drawn content reaches/exceeds fixed viewport edges; representative images show incomplete diagram visibility. Default minScale retained for View. |
| core:seq20 | sequence | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:class80 | class | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable; manual finding on representative captures: Drawn content reaches/exceeds fixed viewport edges; representative images show incomplete diagram visibility. Default minScale retained for View. |
| core:er40 | er | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable; manual finding on representative captures: Drawn content reaches/exceeds fixed viewport edges; representative images show incomplete diagram visibility. Default minScale retained for View. |
| core:state80 | state | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable; manual finding on representative captures: Drawn content reaches/exceeds fixed viewport edges; representative images show incomplete diagram visibility. Default minScale retained for View. |
| registry:flowchart | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:state | state | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:sequence | sequence | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:timeline | timeline | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:class | class | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:er | er | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:journey | journey | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:architecture | architecture | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:xychart | xychart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:pie | pie | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable; manual finding on representative captures: Black triangular corner marks outside the pie circumference in native captures; cause not isolated between library and Impeller/software backend. |
| registry:quadrant | quadrant | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:gantt | gantt | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:mindmap | mindmap | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:gitgraph | gitgraph | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:radar | radar | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:sankey | sankey | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:c4 | c4 | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:packet | packet | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:kanban | kanban | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:requirement | requirement | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:treemap | treemap | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:ishikawa | ishikawa | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:block | block | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| invalid:syntax | invalid | 45 | 0 | 45 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| unsupported:zenuml | zenuml | 45 | 0 | 45 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:tree50-visible-edit | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |

Native nonblank pixels come from widget capture or decoded PNG. Chromium nonblank pixels and hashes come from offscreen SVG rasterization; DOM screenshots cover selected fresh/update samples only. Manual findings apply to representative captures, not every recorded round/phase.

## Cost

Historical protocol qualifications:

- Pele render UPDATE is invalid as an alternating-transition workload: the harness
  restores the original baseline before each call. Its costs describe calls after
  that preparation, not alternating transitions or persistent mounted updates.
- MermaidView repeat includes a forced second frame. Report legacy two-frame cost
  only; it does not establish that an unchanged rebuild requires two render frames.
- Preparation failures are observations, not measured entrypoint calls. In particular,
  Pele render repeat/update can throw while preparing the original negative source.
- Pele nonblank counts and update hashes describe offscreen SVG rasterization.
  Retained DOM screenshots validate selected samples separately, not every call.
  Native widget counts use repaint-boundary captures; PNG counts use decoded output.
- Manual artifact/clipping findings qualify inspected captures. They are not full
  passes, automated per-sample assertions, or proof of a library-wide defect.
- Semantic/model fidelity, A/A calibration and confidence intervals are unavailable.
  This publication does not upgrade the historical campaign to the current portable
  protocol. Missing resources and observers are unavailable, never zero or passes.


Costs use only nonblank non-warmup records, including manually qualified clipped/artifact-bearing output. They do not imply complete-diagram delivery. Retained frame joins supply native raster-completion estimates; UI completion, capture raster, pixel readback and PNG conversion remain separate. renderToPng is an opaque combined export cost; Flutter PNG conversion includes another readback. Browser two-rAF is a paint opportunity, not compositor presentation. Canvas draw may defer work to readback.

Full per-case/phase/stage costs: [CSV](flutter-MermaidView.csv). Sampling is derived per cell; n counts observations, not independent processes or rounds. p95 uses linear interpolation and is descriptive, not a confidence bound.

### Family representatives and scaling within this entrypoint

Each input retains its own row; no aggregate across families or other interfaces. Primary recorded boundary: raster_complete_ms.

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:class80 | fresh | raster_complete_ms | 15 | 70.3230 | 80.6948 | historical descriptive cost only |
| core:class80 | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 53.2130 | 67.0053 | legacy_forced_second_frame_no_required_render_inference |
| core:class80 | update | raster_complete_ms | 15 | 69.6700 | 82.5077 | historical descriptive cost only |
| core:er40 | fresh | raster_complete_ms | 15 | 65.0760 | 84.1238 | historical descriptive cost only |
| core:er40 | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 54.5170 | 71.5802 | legacy_forced_second_frame_no_required_render_inference |
| core:er40 | update | raster_complete_ms | 15 | 62.7710 | 78.6153 | historical descriptive cost only |
| core:flow5 | fresh | raster_complete_ms | 15 | 43.5040 | 47.0709 | historical descriptive cost only |
| core:flow5 | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 44.0130 | 57.6351 | legacy_forced_second_frame_no_required_render_inference |
| core:flow5 | update | raster_complete_ms | 15 | 44.4550 | 53.6881 | historical descriptive cost only |
| core:seq20 | fresh | raster_complete_ms | 15 | 52.1610 | 64.2303 | historical descriptive cost only |
| core:seq20 | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 56.2190 | 60.5321 | legacy_forced_second_frame_no_required_render_inference |
| core:seq20 | update | raster_complete_ms | 15 | 53.9150 | 57.3061 | historical descriptive cost only |
| core:state80 | fresh | raster_complete_ms | 15 | 50.8370 | 62.5039 | historical descriptive cost only |
| core:state80 | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 41.3340 | 48.6862 | legacy_forced_second_frame_no_required_render_inference |
| core:state80 | update | raster_complete_ms | 15 | 50.7640 | 66.7930 | historical descriptive cost only |
| core:tree50 | fresh | raster_complete_ms | 15 | 45.1740 | 62.7084 | historical descriptive cost only |
| core:tree50 | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 41.5810 | 49.0562 | legacy_forced_second_frame_no_required_render_inference |
| core:tree50 | update | raster_complete_ms | 15 | 44.0610 | 50.3052 | historical descriptive cost only |
| registry:architecture | fresh | raster_complete_ms | 15 | 45.6730 | 54.4050 | historical descriptive cost only |
| registry:architecture | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 50.2940 | 63.5841 | legacy_forced_second_frame_no_required_render_inference |
| registry:architecture | update | raster_complete_ms | 15 | 53.2560 | 62.2964 | historical descriptive cost only |
| registry:block | fresh | raster_complete_ms | 15 | 40.1980 | 44.7935 | historical descriptive cost only |
| registry:block | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 49.6500 | 56.4484 | legacy_forced_second_frame_no_required_render_inference |
| registry:block | update | raster_complete_ms | 15 | 53.2090 | 63.9108 | historical descriptive cost only |
| registry:c4 | fresh | raster_complete_ms | 15 | 44.2500 | 56.9296 | historical descriptive cost only |
| registry:c4 | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 52.5060 | 64.5085 | legacy_forced_second_frame_no_required_render_inference |
| registry:c4 | update | raster_complete_ms | 15 | 55.5270 | 59.0242 | historical descriptive cost only |
| registry:class | fresh | raster_complete_ms | 15 | 55.2120 | 65.4079 | historical descriptive cost only |
| registry:class | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 61.1430 | 72.2518 | legacy_forced_second_frame_no_required_render_inference |
| registry:class | update | raster_complete_ms | 15 | 58.3710 | 69.1676 | historical descriptive cost only |
| registry:er | fresh | raster_complete_ms | 15 | 42.0040 | 52.4405 | historical descriptive cost only |
| registry:er | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 45.7390 | 57.0455 | legacy_forced_second_frame_no_required_render_inference |
| registry:er | update | raster_complete_ms | 15 | 43.8710 | 59.0880 | historical descriptive cost only |
| registry:flowchart | fresh | raster_complete_ms | 15 | 43.1130 | 56.7129 | historical descriptive cost only |
| registry:flowchart | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 51.9600 | 57.1649 | legacy_forced_second_frame_no_required_render_inference |
| registry:flowchart | update | raster_complete_ms | 15 | 53.2630 | 57.1651 | historical descriptive cost only |
| registry:gantt | fresh | raster_complete_ms | 15 | 42.9310 | 47.2243 | historical descriptive cost only |
| registry:gantt | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 39.3350 | 44.8007 | legacy_forced_second_frame_no_required_render_inference |
| registry:gantt | update | raster_complete_ms | 15 | 38.9170 | 48.7629 | historical descriptive cost only |
| registry:gitgraph | fresh | raster_complete_ms | 15 | 55.7050 | 66.6704 | historical descriptive cost only |
| registry:gitgraph | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 57.6220 | 78.0253 | legacy_forced_second_frame_no_required_render_inference |
| registry:gitgraph | update | raster_complete_ms | 15 | 62.0890 | 69.7500 | historical descriptive cost only |
| registry:ishikawa | fresh | raster_complete_ms | 15 | 46.3150 | 59.6401 | historical descriptive cost only |
| registry:ishikawa | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 47.1040 | 56.4521 | legacy_forced_second_frame_no_required_render_inference |
| registry:ishikawa | update | raster_complete_ms | 15 | 50.6060 | 62.3078 | historical descriptive cost only |
| registry:journey | fresh | raster_complete_ms | 15 | 54.3400 | 64.9071 | historical descriptive cost only |
| registry:journey | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 53.1280 | 64.7423 | legacy_forced_second_frame_no_required_render_inference |
| registry:journey | update | raster_complete_ms | 15 | 54.2250 | 62.1345 | historical descriptive cost only |
| registry:kanban | fresh | raster_complete_ms | 15 | 45.8860 | 57.6737 | historical descriptive cost only |
| registry:kanban | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 54.8320 | 58.8706 | legacy_forced_second_frame_no_required_render_inference |
| registry:kanban | update | raster_complete_ms | 15 | 55.1470 | 67.4248 | historical descriptive cost only |
| registry:mindmap | fresh | raster_complete_ms | 15 | 50.3450 | 61.7218 | historical descriptive cost only |
| registry:mindmap | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 56.9750 | 66.2168 | legacy_forced_second_frame_no_required_render_inference |
| registry:mindmap | update | raster_complete_ms | 15 | 54.7330 | 69.8678 | historical descriptive cost only |
| registry:packet | fresh | raster_complete_ms | 15 | 35.7720 | 54.6701 | historical descriptive cost only |
| registry:packet | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 32.8940 | 44.1505 | legacy_forced_second_frame_no_required_render_inference |
| registry:packet | update | raster_complete_ms | 15 | 31.0840 | 39.5648 | historical descriptive cost only |
| registry:pie | fresh | raster_complete_ms | 15 | 55.5020 | 67.4277 | historical descriptive cost only |
| registry:pie | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 57.2200 | 71.0390 | legacy_forced_second_frame_no_required_render_inference |
| registry:pie | update | raster_complete_ms | 15 | 59.5170 | 73.7179 | historical descriptive cost only |
| registry:quadrant | fresh | raster_complete_ms | 15 | 54.4700 | 69.0965 | historical descriptive cost only |
| registry:quadrant | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 55.7010 | 74.9653 | legacy_forced_second_frame_no_required_render_inference |
| registry:quadrant | update | raster_complete_ms | 15 | 54.0900 | 58.3266 | historical descriptive cost only |
| registry:radar | fresh | raster_complete_ms | 15 | 80.4360 | 89.3926 | historical descriptive cost only |
| registry:radar | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 77.3600 | 100.9329 | legacy_forced_second_frame_no_required_render_inference |
| registry:radar | update | raster_complete_ms | 15 | 74.4620 | 86.5230 | historical descriptive cost only |
| registry:requirement | fresh | raster_complete_ms | 15 | 47.6470 | 55.1387 | historical descriptive cost only |
| registry:requirement | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 53.3200 | 60.5493 | legacy_forced_second_frame_no_required_render_inference |
| registry:requirement | update | raster_complete_ms | 15 | 51.4630 | 57.5927 | historical descriptive cost only |
| registry:sankey | fresh | raster_complete_ms | 15 | 92.6610 | 106.7432 | historical descriptive cost only |
| registry:sankey | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 93.1920 | 102.3965 | legacy_forced_second_frame_no_required_render_inference |
| registry:sankey | update | raster_complete_ms | 15 | 97.7720 | 106.2883 | historical descriptive cost only |
| registry:sequence | fresh | raster_complete_ms | 15 | 52.3390 | 67.3460 | historical descriptive cost only |
| registry:sequence | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 64.7470 | 72.9453 | legacy_forced_second_frame_no_required_render_inference |
| registry:sequence | update | raster_complete_ms | 15 | 64.7820 | 73.7140 | historical descriptive cost only |
| registry:state | fresh | raster_complete_ms | 15 | 31.2650 | 43.0633 | historical descriptive cost only |
| registry:state | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 43.3050 | 46.0953 | legacy_forced_second_frame_no_required_render_inference |
| registry:state | update | raster_complete_ms | 15 | 45.2810 | 49.5949 | historical descriptive cost only |
| registry:timeline | fresh | raster_complete_ms | 15 | 57.4750 | 65.9363 | historical descriptive cost only |
| registry:timeline | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 58.7460 | 69.3899 | legacy_forced_second_frame_no_required_render_inference |
| registry:timeline | update | raster_complete_ms | 15 | 60.8400 | 88.9065 | historical descriptive cost only |
| registry:treemap | fresh | raster_complete_ms | 15 | 76.9150 | 85.7625 | historical descriptive cost only |
| registry:treemap | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 72.1410 | 80.7557 | legacy_forced_second_frame_no_required_render_inference |
| registry:treemap | update | raster_complete_ms | 15 | 72.6980 | 81.9547 | historical descriptive cost only |
| registry:xychart | fresh | raster_complete_ms | 15 | 58.8950 | 69.6112 | historical descriptive cost only |
| registry:xychart | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 60.5850 | 67.1103 | legacy_forced_second_frame_no_required_render_inference |
| registry:xychart | update | raster_complete_ms | 15 | 61.9010 | 73.1221 | historical descriptive cost only |
| core:tree50-visible-edit | fresh | raster_complete_ms | 15 | 48.6980 | 93.7887 | historical descriptive cost only |
| core:tree50-visible-edit | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 40.8500 | 45.2584 | legacy_forced_second_frame_no_required_render_inference |
| core:tree50-visible-edit | update | raster_complete_ms | 15 | 41.7980 | 46.6799 | historical descriptive cost only |

### Small-flowchart stage detail

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | fresh | capture_raster_ms | 15 | 33.1490 | 38.8484 | historical descriptive cost only |
| core:flow5 | fresh | engine_build_sum_ms | 15 | 2.8570 | 3.4873 | historical descriptive cost only |
| core:flow5 | fresh | engine_raster_sum_ms | 15 | 15.6590 | 20.9990 | historical descriptive cost only |
| core:flow5 | fresh | pixel_readback_ms | 15 | 1.9540 | 5.4792 | historical descriptive cost only |
| core:flow5 | fresh | png_encode_and_readback_ms | 15 | 25.3480 | 28.9775 | historical descriptive cost only |
| core:flow5 | fresh | raster_complete_ms | 15 | 43.5040 | 47.0709 | historical descriptive cost only |
| core:flow5 | fresh | settled_ui_ms | 15 | 33.4440 | 37.1943 | historical descriptive cost only |
| core:flow5 | fresh | ui_frame_ms | 15 | 15.2860 | 18.8918 | historical descriptive cost only |
| core:flow5 | repeat | capture_raster_ms | 15 | 33.5700 | 39.4110 | legacy_forced_second_frame_no_required_render_inference |
| core:flow5 | repeat | engine_build_sum_ms | 15 | 1.2140 | 2.2260 | legacy_forced_second_frame_no_required_render_inference |
| core:flow5 | repeat | engine_raster_sum_ms | 15 | 20.1780 | 22.9332 | legacy_forced_second_frame_no_required_render_inference |
| core:flow5 | repeat | pixel_readback_ms | 15 | 1.8970 | 4.2265 | legacy_forced_second_frame_no_required_render_inference |
| core:flow5 | repeat | png_encode_and_readback_ms | 15 | 27.4970 | 31.0678 | legacy_forced_second_frame_no_required_render_inference |
| core:flow5 | repeat | raster_complete_ms (legacy forced two-frame cost) | 15 | 44.0130 | 57.6351 | legacy_forced_second_frame_no_required_render_inference |
| core:flow5 | repeat | settled_ui_ms (legacy forced two-frame cost) | 15 | 34.3210 | 47.7550 | legacy_forced_second_frame_no_required_render_inference |
| core:flow5 | repeat | ui_frame_ms | 15 | 12.1460 | 22.6927 | legacy_forced_second_frame_no_required_render_inference |
| core:flow5 | update | capture_raster_ms | 15 | 33.3420 | 47.3851 | historical descriptive cost only |
| core:flow5 | update | engine_build_sum_ms | 15 | 1.6010 | 2.6044 | historical descriptive cost only |
| core:flow5 | update | engine_raster_sum_ms | 15 | 21.1380 | 28.2195 | historical descriptive cost only |
| core:flow5 | update | pixel_readback_ms | 15 | 1.9690 | 2.2310 | historical descriptive cost only |
| core:flow5 | update | png_encode_and_readback_ms | 15 | 26.5890 | 28.5721 | historical descriptive cost only |
| core:flow5 | update | raster_complete_ms | 15 | 44.4550 | 53.6881 | historical descriptive cost only |
| core:flow5 | update | settled_ui_ms | 15 | 33.9120 | 42.8160 | historical descriptive cost only |
| core:flow5 | update | ui_frame_ms | 15 | 12.5880 | 17.1422 | historical descriptive cost only |

### First use (separate population)

New processes after runtime startup; launch/import excluded and OS/font/graphics caches retained. No pooling with initialized-runtime calls.

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | fresh | capture_raster_ms | 5 | 126.9260 | 145.5454 | historical descriptive cost only |
| core:flow5 | fresh | pixel_readback_ms | 5 | 22.9600 | 34.9284 | historical descriptive cost only |
| core:flow5 | fresh | png_encode_and_readback_ms | 5 | 27.8590 | 42.4618 | historical descriptive cost only |
| core:flow5 | fresh | raster_complete_ms | 5 | 124.8830 | 135.8556 | historical descriptive cost only |
| core:flow5 | fresh | settled_ui_ms | 5 | 88.9460 | 89.7520 | historical descriptive cost only |
| core:flow5 | fresh | ui_frame_ms | 5 | 79.3270 | 83.8432 | historical descriptive cost only |

## Evidence

[Publication index](../README.md)

Raw sample files for this interface (shared files retain API/phase/round/sample identities):

- [results/first-use-flutter/MermaidView/0/samples.jsonl](../evidence/results/first-use-flutter/MermaidView/0/samples.jsonl)
- [results/first-use-flutter/MermaidView/1/samples.jsonl](../evidence/results/first-use-flutter/MermaidView/1/samples.jsonl)
- [results/first-use-flutter/MermaidView/2/samples.jsonl](../evidence/results/first-use-flutter/MermaidView/2/samples.jsonl)
- [results/first-use-flutter/MermaidView/3/samples.jsonl](../evidence/results/first-use-flutter/MermaidView/3/samples.jsonl)
- [results/first-use-flutter/MermaidView/4/samples.jsonl](../evidence/results/first-use-flutter/MermaidView/4/samples.jsonl)
- [results/flutter/samples.jsonl](../evidence/results/flutter/samples.jsonl)
- [results/visible-edit-flutter/samples.jsonl](../evidence/results/visible-edit-flutter/samples.jsonl)

- [cases.json](../evidence/cases.json)
- [visible-edit/cases.json](../evidence/visible-edit/cases.json)
- [README.md](../evidence/README.md)
- [app/lib/main.dart](../evidence/app/lib/main.dart)
- [pele.mjs](../evidence/pele.mjs)
- [results/environment.txt](../evidence/results/environment.txt)
- [results/artifacts.sha256](../evidence/results/artifacts.sha256)
- [app/pubspec.lock](../evidence/app/pubspec.lock)
- [results/pele-package-lock.json](../evidence/results/pele-package-lock.json)
- [results/fonts.sha256](../evidence/results/fonts.sha256)
- [results/font-resolution.txt](../evidence/results/font-resolution.txt)
- [results/visual-findings.json](../evidence/results/visual-findings.json)
- [results/updates.csv](../evidence/results/updates.csv)
- [results/failures.jsonl](../evidence/results/failures.jsonl)
- [results/setup-failures.json](../evidence/results/setup-failures.json)
- [results/validation.txt](../evidence/results/validation.txt)
- [results/joined-samples.jsonl](../evidence/results/joined-samples.jsonl)
- [results/first-use.jsonl](../evidence/results/first-use.jsonl)
- [results/summary.csv](../evidence/results/summary.csv)
- [results/coverage.csv](../evidence/results/coverage.csv)
