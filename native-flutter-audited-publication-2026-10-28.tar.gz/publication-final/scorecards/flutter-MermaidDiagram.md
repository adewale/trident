# mermaid_flutter 0.3.2: MermaidDiagram / Native Linux Flutter

Suite: historical native-entrypoint campaign; current portable protocol qualification unavailable.
Environment receipt date: Wed Oct 28 18:18:43 UTC 2026. Mode: release.

## Coverage

Main inventory: 31 inputs (29 positive, 2 negative/unavailable-support probes). Attempted distinct main inputs: 31. Unattempted: none.
Supplemental inventory: 1; attempted distinct supplemental inputs: 1.
Planned main input/phase cells: 93; recorded main cells: 93. Sampling counts are printed below and in the per-case CSV.
The scope is public development fixtures, not exhaustive family support or a production holdout. Lineage/branding selection receipt unavailable; this was an explicit two-package investigation.

| Population | Raw | Measured records | Warmups | Preparation failures (raw/measured) |
| --- | --- | --- | --- | --- |
| main | 1953 | 1395 | 558 | 0/0 |
| supplemental edit | 63 | 45 | 18 | 0/0 |
| first use | 5 | 5 | 0 | 0/0 |

## Outcomes

Counts below are records, not semantic passes. Errors include preparation failures; do not add those columns. An unattempted case has unavailable outcome. Unsupported ZenUML and malformed-source rejection are different observations.

| Input | Family | Measured | Nonblank | Errors | Blank | Preparation failures | Qualification |
| --- | --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:tree50 | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable; manual finding on representative captures: Drawn content reaches/exceeds fixed viewport edges; representative images show incomplete diagram visibility. Default minScale retained for View. |
| core:seq20 | sequence | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:class80 | class | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable; manual finding on representative captures: Drawn content reaches/exceeds fixed viewport edges; representative images show incomplete diagram visibility. Default minScale retained for View. |
| core:er40 | er | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable; manual finding on representative captures: Drawn content reaches/exceeds fixed viewport edges; representative images show incomplete diagram visibility. Default minScale retained for View. |
| core:state80 | state | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable; manual finding on representative captures: Drawn content reaches/exceeds fixed viewport edges; representative images show incomplete diagram visibility. Default minScale retained for View. |
| registry:flowchart | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:state | state | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:sequence | sequence | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:timeline | timeline | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:class | class | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:er | er | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:journey | journey | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:architecture | architecture | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:xychart | xychart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:pie | pie | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable; manual finding on representative captures: Black triangular corner marks outside the pie circumference in native captures; cause not isolated between library and Impeller/software backend. |
| registry:quadrant | quadrant | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:gantt | gantt | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:mindmap | mindmap | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:gitgraph | gitgraph | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:radar | radar | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:sankey | sankey | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:c4 | c4 | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:packet | packet | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:kanban | kanban | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:requirement | requirement | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:treemap | treemap | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:ishikawa | ishikawa | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| registry:block | block | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| invalid:syntax | invalid | 45 | 0 | 45 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| unsupported:zenuml | zenuml | 45 | 0 | 45 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable |
| core:tree50-visible-edit | flowchart | 45 | 45 | 0 | 0 | 0 | nonblank only; semantic/fidelity qualification unavailable; manual finding on representative captures: Edited root label remains offscreen; raw captures unchanged despite changed full-scene PNG/View output. |

Native nonblank pixels come from widget capture or decoded PNG. Chromium nonblank pixels and hashes come from offscreen SVG rasterization; DOM screenshots cover selected fresh/update samples only. Manual findings apply to representative captures, not every recorded round/phase.

## Cost

Historical protocol qualifications:

- Pele render UPDATE is invalid as an alternating-transition workload: the harness
  restores the original baseline before each call. Its costs describe calls after
  that preparation, not alternating transitions or persistent mounted updates.
- MermaidView repeat includes a forced second frame. Report legacy two-frame cost
  only; it does not establish that an unchanged rebuild requires two render frames.
- Preparation failures are observations, not measured entrypoint calls. In particular,
  Pele render repeat/update can throw while preparing the original negative source.
- Pele nonblank counts and update hashes describe offscreen SVG rasterization.
  Retained DOM screenshots validate selected samples separately, not every call.
  Native widget counts use repaint-boundary captures; PNG counts use decoded output.
- Manual artifact/clipping findings qualify inspected captures. They are not full
  passes, automated per-sample assertions, or proof of a library-wide defect.
- Semantic/model fidelity, A/A calibration and confidence intervals are unavailable.
  This publication does not upgrade the historical campaign to the current portable
  protocol. Missing resources and observers are unavailable, never zero or passes.


Costs use only nonblank non-warmup records, including manually qualified clipped/artifact-bearing output. They do not imply complete-diagram delivery. Retained frame joins supply native raster-completion estimates; UI completion, capture raster, pixel readback and PNG conversion remain separate. renderToPng is an opaque combined export cost; Flutter PNG conversion includes another readback. Browser two-rAF is a paint opportunity, not compositor presentation. Canvas draw may defer work to readback.

Full per-case/phase/stage costs: [CSV](flutter-MermaidDiagram.csv). Sampling is derived per cell; n counts observations, not independent processes or rounds. p95 uses linear interpolation and is descriptive, not a confidence bound.

### Family representatives and scaling within this entrypoint

Each input retains its own row; no aggregate across families or other interfaces. Primary recorded boundary: raster_complete_ms.

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:class80 | fresh | raster_complete_ms | 15 | 29.6120 | 34.4145 | historical descriptive cost only |
| core:class80 | repeat | raster_complete_ms | 15 | 15.8150 | 21.7778 | historical descriptive cost only |
| core:class80 | update | raster_complete_ms | 15 | 34.9590 | 39.7117 | historical descriptive cost only |
| core:er40 | fresh | raster_complete_ms | 15 | 29.5960 | 34.4029 | historical descriptive cost only |
| core:er40 | repeat | raster_complete_ms | 15 | 18.1960 | 22.0857 | historical descriptive cost only |
| core:er40 | update | raster_complete_ms | 15 | 31.5100 | 35.0734 | historical descriptive cost only |
| core:flow5 | fresh | raster_complete_ms | 15 | 16.5120 | 19.3810 | historical descriptive cost only |
| core:flow5 | repeat | raster_complete_ms | 15 | 15.3720 | 18.5020 | historical descriptive cost only |
| core:flow5 | update | raster_complete_ms | 15 | 16.9040 | 25.3973 | historical descriptive cost only |
| core:seq20 | fresh | raster_complete_ms | 15 | 18.3060 | 25.5508 | historical descriptive cost only |
| core:seq20 | repeat | raster_complete_ms | 15 | 15.5710 | 24.4001 | historical descriptive cost only |
| core:seq20 | update | raster_complete_ms | 15 | 12.4750 | 26.2852 | historical descriptive cost only |
| core:state80 | fresh | raster_complete_ms | 15 | 33.5260 | 61.3684 | historical descriptive cost only |
| core:state80 | repeat | raster_complete_ms | 15 | 14.7440 | 22.8813 | historical descriptive cost only |
| core:state80 | update | raster_complete_ms | 15 | 27.9940 | 34.1250 | historical descriptive cost only |
| core:tree50 | fresh | raster_complete_ms | 15 | 26.5380 | 35.8139 | historical descriptive cost only |
| core:tree50 | repeat | raster_complete_ms | 15 | 23.0300 | 33.9905 | historical descriptive cost only |
| core:tree50 | update | raster_complete_ms | 15 | 32.4490 | 37.1026 | historical descriptive cost only |
| registry:architecture | fresh | raster_complete_ms | 15 | 14.6190 | 26.0869 | historical descriptive cost only |
| registry:architecture | repeat | raster_complete_ms | 15 | 15.7130 | 25.2099 | historical descriptive cost only |
| registry:architecture | update | raster_complete_ms | 15 | 17.4160 | 28.7378 | historical descriptive cost only |
| registry:block | fresh | raster_complete_ms | 15 | 13.8330 | 19.8433 | historical descriptive cost only |
| registry:block | repeat | raster_complete_ms | 15 | 16.6750 | 22.1728 | historical descriptive cost only |
| registry:block | update | raster_complete_ms | 15 | 15.0280 | 21.9777 | historical descriptive cost only |
| registry:c4 | fresh | raster_complete_ms | 15 | 17.5220 | 23.7820 | historical descriptive cost only |
| registry:c4 | repeat | raster_complete_ms | 15 | 14.2390 | 31.4395 | historical descriptive cost only |
| registry:c4 | update | raster_complete_ms | 15 | 18.0880 | 25.3971 | historical descriptive cost only |
| registry:class | fresh | raster_complete_ms | 15 | 17.5720 | 23.7726 | historical descriptive cost only |
| registry:class | repeat | raster_complete_ms | 15 | 17.1750 | 20.5970 | historical descriptive cost only |
| registry:class | update | raster_complete_ms | 15 | 15.6740 | 18.8920 | historical descriptive cost only |
| registry:er | fresh | raster_complete_ms | 15 | 17.2620 | 19.7023 | historical descriptive cost only |
| registry:er | repeat | raster_complete_ms | 15 | 15.9850 | 23.4292 | historical descriptive cost only |
| registry:er | update | raster_complete_ms | 15 | 17.4060 | 22.2879 | historical descriptive cost only |
| registry:flowchart | fresh | raster_complete_ms | 15 | 17.0270 | 24.3363 | historical descriptive cost only |
| registry:flowchart | repeat | raster_complete_ms | 15 | 18.2530 | 21.6063 | historical descriptive cost only |
| registry:flowchart | update | raster_complete_ms | 15 | 16.8670 | 22.6204 | historical descriptive cost only |
| registry:gantt | fresh | raster_complete_ms | 15 | 17.6240 | 28.0204 | historical descriptive cost only |
| registry:gantt | repeat | raster_complete_ms | 15 | 14.6510 | 21.4348 | historical descriptive cost only |
| registry:gantt | update | raster_complete_ms | 15 | 16.4930 | 19.0048 | historical descriptive cost only |
| registry:gitgraph | fresh | raster_complete_ms | 15 | 17.0660 | 23.1792 | historical descriptive cost only |
| registry:gitgraph | repeat | raster_complete_ms | 15 | 18.2560 | 22.9507 | historical descriptive cost only |
| registry:gitgraph | update | raster_complete_ms | 15 | 16.5890 | 21.5771 | historical descriptive cost only |
| registry:ishikawa | fresh | raster_complete_ms | 15 | 17.0190 | 27.6909 | historical descriptive cost only |
| registry:ishikawa | repeat | raster_complete_ms | 15 | 18.8330 | 28.7645 | historical descriptive cost only |
| registry:ishikawa | update | raster_complete_ms | 15 | 22.3410 | 28.3389 | historical descriptive cost only |
| registry:journey | fresh | raster_complete_ms | 15 | 22.4180 | 30.5046 | historical descriptive cost only |
| registry:journey | repeat | raster_complete_ms | 15 | 26.5320 | 28.2812 | historical descriptive cost only |
| registry:journey | update | raster_complete_ms | 15 | 20.4520 | 28.2710 | historical descriptive cost only |
| registry:kanban | fresh | raster_complete_ms | 15 | 15.4990 | 24.5132 | historical descriptive cost only |
| registry:kanban | repeat | raster_complete_ms | 15 | 15.3260 | 19.3297 | historical descriptive cost only |
| registry:kanban | update | raster_complete_ms | 15 | 14.3760 | 25.6282 | historical descriptive cost only |
| registry:mindmap | fresh | raster_complete_ms | 15 | 18.4780 | 26.8679 | historical descriptive cost only |
| registry:mindmap | repeat | raster_complete_ms | 15 | 19.3900 | 27.2033 | historical descriptive cost only |
| registry:mindmap | update | raster_complete_ms | 15 | 17.9030 | 30.4065 | historical descriptive cost only |
| registry:packet | fresh | raster_complete_ms | 15 | 16.1920 | 22.1242 | historical descriptive cost only |
| registry:packet | repeat | raster_complete_ms | 15 | 16.6660 | 22.5488 | historical descriptive cost only |
| registry:packet | update | raster_complete_ms | 15 | 17.6080 | 24.3680 | historical descriptive cost only |
| registry:pie | fresh | raster_complete_ms | 15 | 24.5520 | 28.7876 | historical descriptive cost only |
| registry:pie | repeat | raster_complete_ms | 15 | 24.0680 | 30.6856 | historical descriptive cost only |
| registry:pie | update | raster_complete_ms | 15 | 25.6570 | 29.2129 | historical descriptive cost only |
| registry:quadrant | fresh | raster_complete_ms | 15 | 24.9630 | 28.6954 | historical descriptive cost only |
| registry:quadrant | repeat | raster_complete_ms | 15 | 25.7360 | 29.0422 | historical descriptive cost only |
| registry:quadrant | update | raster_complete_ms | 15 | 23.7990 | 29.6881 | historical descriptive cost only |
| registry:radar | fresh | raster_complete_ms | 15 | 43.3420 | 50.4221 | historical descriptive cost only |
| registry:radar | repeat | raster_complete_ms | 15 | 44.5600 | 58.2392 | historical descriptive cost only |
| registry:radar | update | raster_complete_ms | 15 | 41.0170 | 54.2891 | historical descriptive cost only |
| registry:requirement | fresh | raster_complete_ms | 15 | 15.5090 | 26.8648 | historical descriptive cost only |
| registry:requirement | repeat | raster_complete_ms | 15 | 16.3380 | 26.0681 | historical descriptive cost only |
| registry:requirement | update | raster_complete_ms | 15 | 15.6920 | 25.7913 | historical descriptive cost only |
| registry:sankey | fresh | raster_complete_ms | 15 | 50.2070 | 60.8443 | historical descriptive cost only |
| registry:sankey | repeat | raster_complete_ms | 15 | 45.2180 | 60.9509 | historical descriptive cost only |
| registry:sankey | update | raster_complete_ms | 15 | 43.8420 | 50.4956 | historical descriptive cost only |
| registry:sequence | fresh | raster_complete_ms | 15 | 18.3940 | 26.2021 | historical descriptive cost only |
| registry:sequence | repeat | raster_complete_ms | 15 | 16.5560 | 21.3211 | historical descriptive cost only |
| registry:sequence | update | raster_complete_ms | 15 | 17.7160 | 33.2094 | historical descriptive cost only |
| registry:state | fresh | raster_complete_ms | 15 | 17.0720 | 22.6262 | historical descriptive cost only |
| registry:state | repeat | raster_complete_ms | 15 | 18.8530 | 21.4154 | historical descriptive cost only |
| registry:state | update | raster_complete_ms | 15 | 17.1820 | 21.5841 | historical descriptive cost only |
| registry:timeline | fresh | raster_complete_ms | 15 | 21.8650 | 28.0080 | historical descriptive cost only |
| registry:timeline | repeat | raster_complete_ms | 15 | 24.7280 | 29.6705 | historical descriptive cost only |
| registry:timeline | update | raster_complete_ms | 15 | 25.9020 | 29.2208 | historical descriptive cost only |
| registry:treemap | fresh | raster_complete_ms | 15 | 42.4240 | 44.8431 | historical descriptive cost only |
| registry:treemap | repeat | raster_complete_ms | 15 | 40.5230 | 49.9509 | historical descriptive cost only |
| registry:treemap | update | raster_complete_ms | 15 | 38.3870 | 42.0486 | historical descriptive cost only |
| registry:xychart | fresh | raster_complete_ms | 15 | 27.6780 | 31.9956 | historical descriptive cost only |
| registry:xychart | repeat | raster_complete_ms | 15 | 26.7310 | 34.0531 | historical descriptive cost only |
| registry:xychart | update | raster_complete_ms | 15 | 26.5080 | 32.7831 | historical descriptive cost only |
| core:tree50-visible-edit | fresh | raster_complete_ms | 15 | 28.1650 | 42.6628 | historical descriptive cost only |
| core:tree50-visible-edit | repeat | raster_complete_ms | 15 | 29.5390 | 35.6703 | historical descriptive cost only |
| core:tree50-visible-edit | update | raster_complete_ms | 15 | 31.5260 | 39.4504 | historical descriptive cost only |

### Small-flowchart stage detail

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | fresh | capture_raster_ms | 15 | 23.6490 | 28.9759 | historical descriptive cost only |
| core:flow5 | fresh | engine_build_sum_ms | 15 | 0.9810 | 1.4198 | historical descriptive cost only |
| core:flow5 | fresh | engine_raster_sum_ms | 15 | 5.9130 | 8.1692 | historical descriptive cost only |
| core:flow5 | fresh | pixel_readback_ms | 15 | 2.0960 | 2.3540 | historical descriptive cost only |
| core:flow5 | fresh | png_encode_and_readback_ms | 15 | 25.7610 | 40.8294 | historical descriptive cost only |
| core:flow5 | fresh | raster_complete_ms | 15 | 16.5120 | 19.3810 | historical descriptive cost only |
| core:flow5 | fresh | settled_ui_ms | 15 | 9.5430 | 13.8364 | historical descriptive cost only |
| core:flow5 | fresh | ui_frame_ms | 15 | 9.5400 | 13.8334 | historical descriptive cost only |
| core:flow5 | repeat | capture_raster_ms | 15 | 23.7730 | 27.2758 | historical descriptive cost only |
| core:flow5 | repeat | engine_build_sum_ms | 15 | 0.1770 | 0.2366 | historical descriptive cost only |
| core:flow5 | repeat | engine_raster_sum_ms | 15 | 5.6270 | 7.2579 | historical descriptive cost only |
| core:flow5 | repeat | pixel_readback_ms | 15 | 2.0750 | 4.0305 | historical descriptive cost only |
| core:flow5 | repeat | png_encode_and_readback_ms | 15 | 25.2610 | 28.9010 | historical descriptive cost only |
| core:flow5 | repeat | raster_complete_ms | 15 | 15.3720 | 18.5020 | historical descriptive cost only |
| core:flow5 | repeat | settled_ui_ms | 15 | 7.6890 | 13.0562 | historical descriptive cost only |
| core:flow5 | repeat | ui_frame_ms | 15 | 7.6860 | 13.0532 | historical descriptive cost only |
| core:flow5 | update | capture_raster_ms | 15 | 23.1240 | 25.7365 | historical descriptive cost only |
| core:flow5 | update | engine_build_sum_ms | 15 | 0.8750 | 1.0857 | historical descriptive cost only |
| core:flow5 | update | engine_raster_sum_ms | 15 | 5.4950 | 6.0544 | historical descriptive cost only |
| core:flow5 | update | pixel_readback_ms | 15 | 1.9840 | 2.8269 | historical descriptive cost only |
| core:flow5 | update | png_encode_and_readback_ms | 15 | 25.2370 | 32.8662 | historical descriptive cost only |
| core:flow5 | update | raster_complete_ms | 15 | 16.9040 | 25.3973 | historical descriptive cost only |
| core:flow5 | update | settled_ui_ms | 15 | 11.7160 | 19.4671 | historical descriptive cost only |
| core:flow5 | update | ui_frame_ms | 15 | 11.7110 | 19.4641 | historical descriptive cost only |

### First use (separate population)

New processes after runtime startup; launch/import excluded and OS/font/graphics caches retained. No pooling with initialized-runtime calls.

| Case | Phase | Stage | Samples (calls) | Median (ms) | p95 (ms) | Protocol qualification |
| --- | --- | --- | --- | --- | --- | --- |
| core:flow5 | fresh | capture_raster_ms | 5 | 101.5690 | 131.3768 | historical descriptive cost only |
| core:flow5 | fresh | pixel_readback_ms | 5 | 23.6370 | 26.4710 | historical descriptive cost only |
| core:flow5 | fresh | png_encode_and_readback_ms | 5 | 27.8550 | 31.9898 | historical descriptive cost only |
| core:flow5 | fresh | raster_complete_ms | 5 | 116.4040 | 125.3280 | historical descriptive cost only |
| core:flow5 | fresh | settled_ui_ms | 5 | 74.5520 | 84.8064 | historical descriptive cost only |
| core:flow5 | fresh | ui_frame_ms | 5 | 74.5480 | 84.8034 | historical descriptive cost only |

## Evidence

[Publication index](../README.md)

Raw sample files for this interface (shared files retain API/phase/round/sample identities):

- [results/first-use-flutter/MermaidDiagram/0/samples.jsonl](../evidence/results/first-use-flutter/MermaidDiagram/0/samples.jsonl)
- [results/first-use-flutter/MermaidDiagram/1/samples.jsonl](../evidence/results/first-use-flutter/MermaidDiagram/1/samples.jsonl)
- [results/first-use-flutter/MermaidDiagram/2/samples.jsonl](../evidence/results/first-use-flutter/MermaidDiagram/2/samples.jsonl)
- [results/first-use-flutter/MermaidDiagram/3/samples.jsonl](../evidence/results/first-use-flutter/MermaidDiagram/3/samples.jsonl)
- [results/first-use-flutter/MermaidDiagram/4/samples.jsonl](../evidence/results/first-use-flutter/MermaidDiagram/4/samples.jsonl)
- [results/flutter/samples.jsonl](../evidence/results/flutter/samples.jsonl)
- [results/visible-edit-flutter/samples.jsonl](../evidence/results/visible-edit-flutter/samples.jsonl)

- [cases.json](../evidence/cases.json)
- [visible-edit/cases.json](../evidence/visible-edit/cases.json)
- [README.md](../evidence/README.md)
- [app/lib/main.dart](../evidence/app/lib/main.dart)
- [pele.mjs](../evidence/pele.mjs)
- [results/environment.txt](../evidence/results/environment.txt)
- [results/artifacts.sha256](../evidence/results/artifacts.sha256)
- [app/pubspec.lock](../evidence/app/pubspec.lock)
- [results/pele-package-lock.json](../evidence/results/pele-package-lock.json)
- [results/fonts.sha256](../evidence/results/fonts.sha256)
- [results/font-resolution.txt](../evidence/results/font-resolution.txt)
- [results/visual-findings.json](../evidence/results/visual-findings.json)
- [results/updates.csv](../evidence/results/updates.csv)
- [results/failures.jsonl](../evidence/results/failures.jsonl)
- [results/setup-failures.json](../evidence/results/setup-failures.json)
- [results/validation.txt](../evidence/results/validation.txt)
- [results/joined-samples.jsonl](../evidence/results/joined-samples.jsonl)
- [results/first-use.jsonl](../evidence/results/first-use.jsonl)
- [results/summary.csv](../evidence/results/summary.csv)
- [results/coverage.csv](../evidence/results/coverage.csv)
