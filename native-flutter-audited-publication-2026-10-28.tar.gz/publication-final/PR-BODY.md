## What

Add a native Linux Flutter release adapter for `MermaidDiagram`, `MermaidView`
and `renderToPng()`, plus a Chromium harness for Pele `render()` with DOM insertion
and `mount()`/`update()`. Dependencies are pinned to mermaid_flutter/mermaid_core
0.3.2 and Pele 1.9.0. The campaign is standalone; it is not registered in the
standard CLI/catalog.

## Why

Refs #30. The existing Dart/Node SVG binding cannot establish native Flutter
widget or PNG performance. The new adapter invokes the advertised APIs directly
and records UI, raster, readback and export boundaries separately.

## How

The runner retains source transitions, preparation failures and timed-call state.
It checks the published Pele entry digest, atomically reserves output, supervises
process deadlines and associates Flutter framework errors with samples. Exact
sample identities replace count-only completion checks.

The publisher copies retained evidence without rerunning renderers or modifying
records. It produces coverage, outcomes, costs and owning evidence for each public
interface. The authored [result tables](docs/native-flutter-comparison.md) follow
Trident's reporting conventions, including units, versions, qualification and
withheld comparisons. Raw campaign output stays outside source commits; only
small invocation witnesses and an example receipt are included here.

## Results and adversarial audit

Three independent reviewers audited the first PR revision. They confirmed the
advertised entrypoints and native frame-clock reduction, but found ten runner,
workload and publication issues. The revised source addresses those issues;
[the audit](https://github.com/adewale/trident/releases/download/native-flutter-evidence-2026-10-28/AUDIT.md)
records each finding, its effect on the historical claims and its verification.

| Retained observation | Interpretation |
|---|---|
| 29 selected positive inputs produced nonblank output per entrypoint | Invocation/ink evidence; semantic correctness unavailable |
| Malformed flowchart and ZenUML probes rejected | Fresh rejection observed; some legacy repeat/update calls never began |
| Native pie corner marks and clipped large widget captures | Manual findings retained; responsible renderer/backend layer not isolated |
| 10,105 recorded campaign observations | Includes warmups and negative cases, not that many independent diagrams |
| 84 main preparation failures, including 60 non-warmup records | Not timed entrypoint calls |
| Legacy Pele render-update column | Withheld as an alternating-transition comparison: baseline restored per call |
| Legacy View repeat column | Withheld as required-render cost: harness forced a second frame |
| Cross-runtime relative speed | Withheld: different completion, dimensions/fonts and incomplete calibration |

The useful result is a set of qualified entrypoint costs and scaling observations.
For example, native encoded-PNG fresh medians rise from 11.63 ms on flow5 to
143.29 ms on tree50 and 290.74 ms on class80; those are one API's changing workload,
not a ratio against SVG/DOM calls. Separate tables preserve each runtime and
completion boundary. No full corrected benchmark campaign is claimed.

[Dated scorecards and full evidence](https://github.com/adewale/trident/releases/tag/native-flutter-evidence-2026-10-28)
include raw samples, images, the measured adapter snapshot, environment details,
checksums and separate revised-runner verification records. The original archive
SHA-256 is `576069ace64693beb8de81a34af5bb9d4237d0eb4e68d186bc16d08cc28b75d7`.
Historical timings belong to that archived source, not to later source fixes.

## Testing

- All 23 focused tests pass, including immutable publication against the original
  campaign, exact sample identities, pin enforcement, timeouts/child cleanup,
  output reservation and real Chromium invalid-original/valid-update behavior.
- The duplicate-ID regression fails when the old count-only guard is restored.
- Native release compilation and Dart static analysis pass. Static analysis uses
  `ANALYZER_STATE_LOCATION_OVERRIDE` for a writable sandbox cache.
- Separate runtime checks verify painted output, negative-call execution,
  one-frame View repeats, alternating source updates and framework-error capture.
  Concurrent native writers produce one row and one reservation rejection.
- Python, Node and shell syntax checks and `git diff --check` pass. The unmodified
  core suite cannot start here because its dispatcher requires Bun 1.4+, which
  is not installed. Its result is unavailable, not passed.

## Visual evidence

Claim: the new harness produces nonblank output for the named flowchart through
native release MermaidDiagram and Chromium Pele render plus DOM insertion.

Input/fixture: `core:flow5` from the frozen corpus, 1000×700 viewport, pixel ratio 1.

Baseline SHA: `8cfa06bf6b8395d5c4d254b8c2551117fd520064`

Current SHA: `26ad0f91f2f2f6e530f3c23177011e2fa3ce76b9`

The baseline has no native adapter. Its missing-file diagnostic is retained in
[the receipt](https://github.com/adewale/trident/blob/26ad0f91f2f2f6e530f3c23177011e2fa3ce76b9/docs/evidence/native-entrypoint-invocation/receipt.json);
no before image is fabricated. The producer source commit is recorded separately
and has the same adapter bytes as this witness commit.

| Native release after | Chromium after | What to inspect |
|---|---|---|
| ![Native release flow5 with the Start, Check, Do it, Skip and End nodes and labelled branches](https://raw.githubusercontent.com/adewale/trident/26ad0f91f2f2f6e530f3c23177011e2fa3ce76b9/docs/evidence/native-entrypoint-invocation/native-flow5.png) | ![Chromium Pele flow5 with five nodes and both decision branches visible](https://raw.githubusercontent.com/adewale/trident/26ad0f91f2f2f6e530f3c23177011e2fa3ce76b9/docs/evidence/native-entrypoint-invocation/chromium-flow5.png) | Five node labels and two labelled branches produce visible ink; styling and dimensions differ. |

Regenerate: follow the [release build and focused invocation commands](https://github.com/adewale/trident/blob/26ad0f91f2f2f6e530f3c23177011e2fa3ce76b9/native-flutter/README.md)
with `ONLY_CASE=core:flow5`, `ONLY_API=MermaidDiagram` or `render`, `ONLY_PHASE=fresh`
and a fresh output directory. The receipt binds input, source and image hashes.

Independent check: the existing capture pixel counts and retained verification
records check nonblank output; the [runner regression suite](https://github.com/adewale/trident/blob/26ad0f91f2f2f6e530f3c23177011e2fa3ce76b9/native-flutter/tests/test_browser_launcher.py)
checks call/error/version contracts. These are not a semantic diagram oracle.

Limitation: the images prove only this fixture/configuration. They do not prove
bitmap equality, complete compatibility or matched-work performance. The dated
publication links the larger contact sheet and observed defects.

## Risk

This adds a separate Linux/x86_64 campaign and reporting path. Shared renderer
implementations and the standard benchmark collectors are unchanged. The main
risk is over-interpreting unlike clocks or legacy workload defects; the docs and
publisher keep those comparisons withheld and preserve the original evidence.
