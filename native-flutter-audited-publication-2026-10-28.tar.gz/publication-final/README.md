# Historical native Flutter and Chromium entrypoint results

Environment receipt date: **Wed Oct 28 18:18:43 UTC 2026**. Measurement window: unavailable; no start/end campaign receipt. Publication time is separate in publication.json.

[Adversarial audit](AUDIT.md) · [Writing review](WRITING-REVIEW.md) · [Identity-aware validation](audited-validation.txt)

The revised protocol verification is retained separately under verification/. Those records do not replace this historical campaign.

## Coverage

Main selection: 31 inputs; 29 positive, 2 negative/unavailable-support probes. Supplemental selection: 1 corrected edit inputs. Inputs are frozen public development fixtures, not a production holdout or exhaustive compatibility suite.

| Population | Raw observations | Measured records | Warmups |
| --- | --- | --- | --- |
| main | 9765 | 6975 | 2790 |
| supplemental edit | 315 | 225 | 90 |
| first use | 25 | 25 | 0 |

Campaign total: **10105 observations**, including warmups and negative cases. This is a count of recorded observations, not entrypoint calls: the main campaign includes 84 preparation failures (60 non-warmup negative records) that did not reach the timed call. Other copied folders such as smoke checks are retained but excluded from these counts.

Five separate version/interface/runtime scorecards (no combined score):

- [flutter-MermaidDiagram](scorecards/flutter-MermaidDiagram.md)
- [flutter-MermaidView](scorecards/flutter-MermaidView.md)
- [flutter-renderToPng](scorecards/flutter-renderToPng.md)
- [pele-mount](scorecards/pele-mount.md)
- [pele-render](scorecards/pele-render.md)

## Outcomes

Initialized-runtime populations contain 6750 nonblank measured records, 450 error records and 0 blank records. Of the errors, **84 preparation failures / 60 measured negative records** did not reach the timed entrypoint. Those are not measured entrypoint calls or negative assertion passes.

Nonblank output, malformed-source errors, unavailable ZenUML support, manual visual findings and unavailable semantic checks remain separate. Per-input dispositions and missing attempts appear in each card.

Historical protocol qualifications:

- Pele render UPDATE is invalid as an alternating-transition workload: the harness
  restores the original baseline before each call. Its costs describe calls after
  that preparation, not alternating transitions or persistent mounted updates.
- MermaidView repeat includes a forced second frame. Report legacy two-frame cost
  only; it does not establish that an unchanged rebuild requires two render frames.
- Preparation failures are observations, not measured entrypoint calls. In particular,
  Pele render repeat/update can throw while preparing the original negative source.
- Pele nonblank counts and update hashes describe offscreen SVG rasterization.
  Retained DOM screenshots validate selected samples separately, not every call.
  Native widget counts use repaint-boundary captures; PNG counts use decoded output.
- Manual artifact/clipping findings qualify inspected captures. They are not full
  passes, automated per-sample assertions, or proof of a library-wide defect.
- Semantic/model fidelity, A/A calibration and confidence intervals are unavailable.
  This publication does not upgrade the historical campaign to the current portable
  protocol. Missing resources and observers are unavailable, never zero or passes.


## Cost

This campaign answers how each advertised entrypoint behaves and scales on the selected inputs on this cloud machine. Compare fresh, repeated and edited-source costs within an entrypoint, alongside its capabilities, visible limitations and stage boundary. Read the invalid render UPDATE and forced View repeat qualifications before drawing lifecycle conclusions.

A matched-work ratio is unavailable pending common raster/PNG, font and viewport controls and calibrated sampling. There is no cross-runtime latency table, ratio, overall winner, or semantic/fidelity pass. Software graphics is not a forecast of mobile GPU performance. Resources are unavailable.

[Full per-case/stage CSV](per-case.csv) · [Separate first-use CSV](first-use.csv)

Observed sample counts per nonempty initialized-runtime timing cell: 15; first-use timing cell counts: 5. Medians and interpolated p95 are recomputed from retained non-warmup raw records. No A/A calibration or confidence interval is inferred from these counts.

## Evidence

[Contact sheet with original captures](contact-sheet.html)

The entire supplied campaign is copied byte-for-byte under evidence/. Its original reports are historical records; the qualifications above govern this publication. Recorded absolute paths remain provenance, while publication links use portable copies. No collection, rerendering or input mutation occurred.

Recorded revision references (as listed in the environment receipt): 8cfa06bf6b8395d5c4d254b8c2551117fd520064, 737ba8f885dc774b53b442759999a312c9461e4e. These do not identify a committed adapter snapshot: use the copied measured source files and their hashes. Current PR source must not be substituted for that snapshot.

[Publication metadata and copied evidence hashes](publication.json)

- [cases.json](evidence/cases.json)
- [visible-edit/cases.json](evidence/visible-edit/cases.json)
- [README.md](evidence/README.md)
- [app/lib/main.dart](evidence/app/lib/main.dart)
- [pele.mjs](evidence/pele.mjs)
- [results/environment.txt](evidence/results/environment.txt)
- [results/artifacts.sha256](evidence/results/artifacts.sha256)
- [app/pubspec.lock](evidence/app/pubspec.lock)
- [results/pele-package-lock.json](evidence/results/pele-package-lock.json)
- [results/fonts.sha256](evidence/results/fonts.sha256)
- [results/font-resolution.txt](evidence/results/font-resolution.txt)
- [results/visual-findings.json](evidence/results/visual-findings.json)
- [results/updates.csv](evidence/results/updates.csv)
- [results/failures.jsonl](evidence/results/failures.jsonl)
- [results/setup-failures.json](evidence/results/setup-failures.json)
- [results/validation.txt](evidence/results/validation.txt)
- [results/joined-samples.jsonl](evidence/results/joined-samples.jsonl)
- [results/first-use.jsonl](evidence/results/first-use.jsonl)
- [results/summary.csv](evidence/results/summary.csv)
- [results/coverage.csv](evidence/results/coverage.csv)

![Retained contact sheet: native and browser flowchart/sequence examples; native pie shows corner marks](evidence/results/representative-images.jpg)
