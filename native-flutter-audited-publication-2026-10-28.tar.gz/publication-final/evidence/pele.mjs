import { chromium } from 'playwright';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
const base=path.dirname(new URL(import.meta.url).pathname),out=process.env.OUT||base+'/results/pele';fs.mkdirSync(out,{recursive:true});
const cases=JSON.parse(fs.readFileSync(process.env.CASES_FILE||base+'/cases.json')).filter(c=>!process.env.ONLY_CASE||c.id===process.env.ONLY_CASE);
const server=http.createServer((req,res)=>{if(req.url==='/pele.js'){res.setHeader('content-type','application/javascript');res.end(fs.readFileSync('/workspace/pele/node_modules/pele/dist/pele.js'));}else{res.end('<!doctype html><style>body{margin:0;background:white}#host{width:1000px;height:700px;overflow:hidden}svg{max-width:100%;max-height:100%}</style><div id="host"></div>');}}).listen(0,'127.0.0.1');await new Promise(r=>server.on('listening',r));
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:process.env.HEADED!=='1',args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const rows=[];
for(let round=0;round<Number(process.env.ROUNDS||3);round++){
 const page=await browser.newPage({viewport:{width:1000,height:700},deviceScaleFactor:1});await page.goto('http://127.0.0.1:'+server.address().port);await page.evaluate(async()=>{window.pele=await import('/pele.js');await document.fonts.ready;window.handle=null;});
 for(const c of cases)for(const api of ['render','mount'].filter(a=>!process.env.ONLY_API||a===process.env.ONLY_API))for(const phase of ['fresh','repeat','update'].filter(a=>!process.env.ONLY_PHASE||a===process.env.ONLY_PHASE)){
  for(let i=-Number(process.env.WARMUPS??2);i<Number(process.env.SAMPLES||11);i++){
   const row=await page.evaluate(async({c,api,phase,i})=>{
    const host=document.querySelector('#host'),p=window.pele;
    const frames=()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    const reset=()=>{window.handle?.destroy();window.handle=null;host.replaceChildren();};
    if(phase==='fresh'||!window.handle&&api==='mount'){reset();if(phase!=='fresh'){window.handle=p.mount(host,c.source);await frames();}}
    if(api==='render'&&phase!=='fresh'){host.innerHTML=p.render(c.source).svg;await frames();}
    const source=phase==='update'?(i%2===0?c.updatedSource:c.source):c.source;
    const row={id:c.id,api,phase,sample:i,sourceUpdated:source!==c.source};let svg;
    const start=performance.now();try{
     if(api==='render'){const result=p.render(source);row.svg_return_ms=performance.now()-start;svg=result.svg;const t=performance.now();host.innerHTML=svg;row.dom_insertion_ms=performance.now()-t;}
     else{if(phase==='fresh')window.handle=p.mount(host,source);else window.handle.update(source);row.mount_update_ms=performance.now()-start;if(window.handle.error)throw window.handle.error;svg=window.handle.result?.svg;}
     row.api_dom_ms=performance.now()-start;
     await frames();row.two_raf_ms=performance.now()-start;
     const el=host.querySelector('svg');if(!el)throw Error('no SVG DOM');row.svgLabels=[...el.querySelectorAll('text,foreignObject')].map(x=>x.textContent);row.dom_elements=el.querySelectorAll('*').length;
     // Separate offscreen SVG raster, readback, and encoding. Not a DOM screenshot.
     const t=performance.now(),blob=new Blob([svg],{type:'image/svg+xml'}),url=URL.createObjectURL(blob),img=new Image();img.src=url;await img.decode();row.svg_decode_ms=performance.now()-t;
     const canvas=document.createElement('canvas');canvas.width=Math.ceil(img.naturalWidth);canvas.height=Math.ceil(img.naturalHeight);if(!canvas.width||!canvas.height||canvas.width*canvas.height>64000000)throw Error('invalid raster size');const ctx=canvas.getContext('2d',{willReadFrequently:true});let a=performance.now();ctx.drawImage(img,0,0);row.canvas_draw_ms=performance.now()-a;a=performance.now();const pixels=ctx.getImageData(0,0,canvas.width,canvas.height);row.pixel_readback_ms=performance.now()-a;
     row.width=canvas.width;row.height=canvas.height;let hash=2166136261;for(const v of pixels.data)hash=Math.imul(hash^v,16777619)>>>0;row.pixel_hash=hash;let painted=0;for(let j=0;j<pixels.data.length;j+=4)if(pixels.data[j+3]&&Math.min(pixels.data[j],pixels.data[j+1],pixels.data[j+2])<240)painted++;row.painted_pixels=painted;
     a=performance.now();const png=await new Promise(r=>canvas.toBlob(r,'image/png'));row.png_encode_ms=performance.now()-a;row.png_bytes=png.size;URL.revokeObjectURL(url);row.status=painted?'painted':'blank';
    }catch(e){row.status='error';row.error=String(e);row.failed_after_ms=performance.now()-start;}
    return row;
   },{c,api,phase,i}).catch(e=>({id:c.id,api,phase,sample:i,status:'error',error:String(e)}));row.round=round;rows.push(row);fs.appendFileSync(out+'/samples.jsonl',JSON.stringify(row)+'\n');
   if(round===0&&i===0&&(phase==='fresh'||phase==='update')){await page.screenshot({path:out+'/'+c.id.replaceAll(':','_')+'_'+api+'_'+phase+'.png'});const svg=await page.locator('#host').innerHTML();fs.writeFileSync(out+'/'+c.id.replaceAll(':','_')+'_'+api+'_'+phase+'.html',svg);}
  }
 }
 await page.close();console.log('Pele round',round,'rows',rows.length);
}
fs.writeFileSync(out+'/browser.json',JSON.stringify({version:browser.version(),headless:process.env.HEADED!=='1',flags:['--use-gl=angle','--use-angle=swiftshader']},null,2));await browser.close();server.close();
