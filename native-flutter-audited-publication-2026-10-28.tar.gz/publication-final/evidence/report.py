import csv,json,statistics
from pathlib import Path
b=Path(__file__).parent;o=b/'results';summary=list(csv.DictReader((o/'summary.csv').open()));first=list(csv.DictReader((o/'first-use-summary.csv').open()))
def val(api,phase,stage,id='core:flow5',col='p50_ms'):
 return float(next(r for r in summary if r['api']==api and r['phase']==phase and r['stage']==stage and r['id']==id)[col])
def trio(api,stage):return ' | '.join(f'{val(api,p,stage):.2f}' for p in ['fresh','repeat','update'])
table='\n'.join(f'| {api} | {label} | {trio({'renderToPng()':'renderToPng','Pele render()':'render','Pele mount()/update()':'mount'}.get(api,api),stage)} |' for api,label,stage in [('MermaidDiagram','UI-frame end','settled_ui_ms'),('MermaidDiagram','engine raster finished','raster_complete_ms'),('MermaidView','second UI-frame end','settled_ui_ms'),('MermaidView','engine raster finished','raster_complete_ms'),('renderToPng()','encoded PNG returned','render_png_ms'),('Pele render()','SVG returned','svg_return_ms'),('Pele render()','SVG + DOM insertion','api_dom_ms'),('Pele mount()/update()','public call + DOM','api_dom_ms')])
firsttable='\n'.join(f'| '+{'render':'Pele render()','mount':'Pele mount()/update()','renderToPng':'renderToPng()'}.get(api,api)+f' | '+{'raster_complete_ms':'engine raster finished','api_dom_ms':'public call + DOM','render_png_ms':'encoded PNG returned'}.get(stage,stage)+f' | {float(next(r for r in first if r["api"]==api and r["stage"]==stage)["p50_ms"]):.2f} |' for api,stage in [('MermaidDiagram','raster_complete_ms'),('MermaidView','raster_complete_ms'),('renderToPng','render_png_ms'),('render','api_dom_ms'),('mount','api_dom_ms')] if any(r['api']==api and r['stage']==stage for r in first))
text=f'''Native Flutter and Pele: Trident comparison, 28 October 2026

Both pinned libraries painted all **29 positive fixtures** in this campaign; both rejected the malformed flowchart and unsupported ZenUML probe. Native captures also show pie-chart artifacts and clipping of large diagrams. The timings show small Pele SVG/DOM calls, measurable native Flutter scene-cache benefits, and additional native frame/raster/export work. They do **not** establish an overall speed winner: the public entrypoints finish different work.

The native adapter was implemented in this Trident checkout. It imports and executes **mermaid_flutter 0.3.2** (`mermaid_core 0.3.2`) in a **native Linux Flutter release application**. Pele **1.9.0** executes its published `render`, `mount` and `Mounted.update` in headed Chromium on the same machine. No handoff bundle was available.

Representative small flowchart (`core:flow5`), milliseconds, **median of 15 measured observations per cell**:

| Entrypoint | Completed work | Fresh | Repeat | Source update |
|---|---|---:|---:|---:|
{table}

Rows with different completion boundaries must not be compared as equivalent latency. Flutter engine raster completion comes from matching `FrameTiming` timestamps, separately from UI-frame completion. Chromium's two-rAF observations only indicate a paint opportunity; they are not equivalent to Flutter raster completion. Full per-case medians, p95, ranges and stage-specific samples are in [summary.csv](results/summary.csv) and the raw files.

For this flowchart, `MermaidDiagram`'s median engine build cost falls from **{val('MermaidDiagram','fresh','engine_build_sum_ms'):.2f} ms fresh to {val('MermaidDiagram','repeat','engine_build_sum_ms'):.2f} ms repeated**. This preserves the widget's documented scene memoization. `MermaidView` retains its default controls and fit behavior, including the second frame. Stateless `renderToPng()` repeats the public rendering/export pipeline; its fresh/repeat labels distinguish campaign placement, not a reusable widget cache.

Fresh-process first use of the same flowchart, **five processes per entrypoint**, no warmup, median milliseconds:

| Entrypoint | Completed work | Median ms |
|---|---|---:|
{firsttable}

These timers start after engine/window or browser-page launch; deferred font/shader work can still occur. They exclude process launch/import and retain OS/font/graphics caches. They are separate from initialized-runtime observations.

Paint and compatibility findings:

- Every positive fixture produced nonblank pixels through all five entrypoints. This is paint qualification, not proof of complete semantic fidelity. Captured PNGs, DOM SVG/HTML, expected-label diagnostics and representative OCR are retained.
- Native pie-chart captures contain black triangular corner marks outside the circle across the widget and PNG paths; Pele’s retained pie captures do not show those marks. The cause was not isolated between the library and Impeller/software graphics. See [visual-findings.json](results/visual-findings.json).
- Large core fixtures are clipped in the 1000×700 native widget viewport. The default interactive viewer's minimum scale can still leave content outside the viewport. Their timing samples and images remain present, with no claim that clipping is successful full-diagram delivery. The Pele host uses explicit SVG max-width/max-height CSS; this is a harness sizing choice.
- Some original tree source updates leave pixels unchanged because later repeated node declarations overwrite the first edited label. The separately identified `core:tree50-visible-edit` changes every declaration and changes pixels in View, native PNG and both Pele paths; the edited root remains outside Diagram’s clipped viewport. Clipped class/ER edits can also leave the fixed native Diagram capture unchanged.
- Both negative inputs and every failed attempt are retained in [failures.jsonl](results/failures.jsonl), with the source in the frozen manifests. Exception timings are excluded from painted-output timing summaries; timings for clipped/artifact-bearing output stay present and are explicitly qualified in coverage.csv.

PNG and capture stages stay separate. Native `renderToPng(pixelRatio:1)` returns a fully encoded PNG and exposes no internal stage clocks. Its total is not reported as isolated rasterization or encoding. Widget capture raster, raw pixel readback and PNG conversion are separately measured; Flutter's PNG conversion includes another readback. Pele's SVG return, DOM insertion, SVG decode, canvas draw, raw readback and PNG encoding have separate fields. The native PNG and browser canvas output have different intrinsic sizes and styling, so **no PNG speed ratio is valid**. Raw output dimensions are retained.

![Representative painted output](results/representative-images.jpg)

The actual native display is also captured in [native-x11-framebuffer.png](results/native-x11-framebuffer.png); most native evidence images use Flutter repaint-boundary capture, while Pele images are actual browser-page screenshots. These validate pixels independently of API-return timers.

The main campaign contains **9,765 raw samples**: 5,859 native and 3,906 Chromium, including warmups and expected failures. Each input/API/phase has three rounds × five measured samples plus two warmups per round. The corrected-edit pass adds 315 raw samples and first-use adds 25, for **10,105 campaign observations**. The bundle also retains 45 earlier smoke-test observations, excluded from all reported summaries. Warmups remain in the raw files with negative indices. Initialized-runtime rounds use one native process and one Chromium process with a fresh page per round; renderer campaigns run sequentially. Case/API order is fixed. This is an exploratory campaign, without A/A calibration or confidence intervals; estimated p95 values have only 15 observations per cell.

Environment: Debian 13.6 x86_64, Linux 6.18.55, AMD EPYC 9V74, 4 CPU-equivalents of cgroup quota and 16 GiB memory limit; no CPU affinity/frequency controls. Flutter **3.47.8**, Dart **3.13.7**, Impeller OpenGLES; `LIBGL_ALWAYS_SOFTWARE=1`. Chromium **154.0.8037.57**, ANGLE SwiftShader; Xvfb 1000×700, device pixel ratio 1. Node **24.19.0** orchestrates Chromium only. This is software-graphics cloud performance, not mobile GPU performance.

Trident revision **8cfa06bf6b8395d5c4d254b8c2551117fd520064**. Exact Flutter/engine revisions, toolchain versions, runtime package inventory, locks and artifact hashes are in [environment.txt](results/environment.txt), font resolution/hashes, [artifacts.sha256](results/artifacts.sha256) and adjacent metadata. Cases come from Trident's public frozen corpus, not a holdout; scope is six core/scaling fixtures and 23 registry fixtures, plus two negative probes, not exhaustive compatibility.

[Reproduction instructions and measurement contract](README.md) · [Validation results](results/validation.txt) · [Raw Flutter samples](results/flutter/samples.jsonl) · [Raw Chromium samples](results/pele/samples.jsonl) · [All joined samples](results/joined-samples.jsonl) · [First-use samples](results/first-use.jsonl) · [Coverage](results/coverage.csv) · [Pixel update checks](results/updates.csv)
'''
(b/'COMPARISON.md').write_text(text)
