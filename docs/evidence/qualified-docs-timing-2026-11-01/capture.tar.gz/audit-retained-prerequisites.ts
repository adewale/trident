import{readFileSync,writeFileSync,mkdirSync}from'node:fs'
import{gunzipSync}from'node:zlib'
import{chromium}from'/workspace/trident/node_modules/playwright/index.mjs'
import{protocolIdentity}from'/workspace/trident-qualified-performance/unified/protocol-identity.ts'
import{reviewedDocsCase}from'/workspace/trident-qualified-performance/unified/docs-drawings.ts'
import{makeSvgCaseContract}from'/workspace/trident-qualified-performance/fidelity/svg-assessment.ts'
import{observeBrowserTimingSvg}from'/workspace/trident-qualified-performance/unified/timing-browser.ts'
import{evidenceDigest,evidenceBytesDigest}from'/workspace/trident-qualified-performance/portable/evidence-contract.ts'
const repo='/workspace/trident-qualified-performance',old='/workspace/trident-ecosystem-2026-10-31-campaign/docs/svg',out='/workspace/trident-representative-timing-2026-11-01',read=(p:string)=>JSON.parse(readFileSync(p,'utf8'))
mkdirSync(out,{recursive:true})
const frozen=read(out+'/collection/browser-inputs.json'), observerSha256=read(out+'/collection/plan.json').observerSha256
if(evidenceDigest(protocolIdentity(repo,['unified/timing-browser.ts']))!==evidenceDigest(frozen.producers))throw Error('Frozen observer producer changed')
for(const f of [...frozen.environment.fonts,...frozen.environment.fontConfiguration])if(evidenceBytesDigest(readFileSync(f.path))!==f.sha256)throw Error('Frozen font input changed')
if(evidenceBytesDigest(readFileSync(frozen.environment.browser.path))!==frozen.environment.browser.sha256)throw Error('Frozen browser changed')
const inventory=read(old+'/inventory.json'),reviews=read(repo+'/corpus/docs-reviewed.json'),observations=read(old+'/observations.json'),browser=await chromium.launch({headless:true,executablePath:frozen.environment.browser.path}),rows:any[]=[]
try{for(const index of[143,367,403,496,325,321,465])for(const project of['mermaid-js/mermaid','obsidianmd/pele']){
const source=inventory.cases[index],input=reviewedDocsCase(source,reviews.find((r:any)=>r.id===source.id)),oldRow=observations.find((r:any)=>r.caseId===source.id&&r.operation==='drawing-checks'&&r.metrics.project===project),witness=oldRow?.metrics.witness
if(!witness){rows.push({index,project,caseId:source.id,status:'missing'});continue}
const svg=gunzipSync(readFileSync(old+'/'+witness)),page=await browser.newPage(frozen.environment.rendering)
await page.route('**/*',(r:any)=>r.abort())
try{const checked=await observeBrowserTimingSvg(page,input,makeSvgCaseContract(input),svg,observerSha256);const row={index,project,caseId:source.id,family:input.family,sourceSha256:evidenceBytesDigest(input.source),outputSha256:evidenceBytesDigest(svg),witness:old+'/'+witness,checked,status:checked.checks.some(c=>c.status==='failed')?'incorrect':checked.checks.every(c=>c.status==='passed')?'correct':'unknown'};rows.push(row);console.log(JSON.stringify({index,project,status:row.status,nonPassing:checked.checks.filter(c=>c.status!=='passed').map(c=>[c.criterion,c.status])}))}finally{await page.close()}
}}finally{await browser.close()}
const file=out+'/docs-preflight-bound.json';writeFileSync(file,JSON.stringify({schema:'trident-representative-docs-timing-bound-prerequisite-audit-v1',observerSha256,observerProducers:frozen.producers,orchestrationScriptSha256:evidenceBytesDigest(readFileSync(import.meta.path)),auditTiming:'Postcollection offline recheck of unchanged retained prerequisite SVGs. Original preselection diagnostic retained unchanged; no claim this later audit preceded timing.',inventoryPin:inventory.pin,sourceInventorySha256:evidenceBytesDigest(readFileSync(old+'/inventory.json')),sourceContractsSha256:evidenceBytesDigest(readFileSync(repo+'/corpus/docs-reviewed.json')),priorObservationsSha256:evidenceBytesDigest(readFileSync(old+'/observations.json')),scope:'Fresh static full-contract observation of retained actual renderer SVGs only. Selection evidence, no new renderer call or timing sample.',rows},null,2)+'\n');console.log(JSON.stringify({file,sha256:evidenceBytesDigest(readFileSync(file))}))
