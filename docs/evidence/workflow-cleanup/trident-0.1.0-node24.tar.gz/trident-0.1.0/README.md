# Trident 0.1.0

Requires Node 24+, an installed target artifact and the pinned Mermaid oracle.

Run `node run.mjs --version` or `node run.mjs --help`. Set MERMAID_REFERENCE_DIR to the installed oracle. Target artifacts are installed separately.

Methods: https://github.com/adewale/trident/blob/cc9a897e63bbbf133c8b6ebfb593ad2f96094e16/BENCHMARKS.md
