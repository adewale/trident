import {writeFileSync} from 'node:fs'
import {portableCases} from '/workspace/trident/portable/cohorts.ts'
import {expandedFidelityCases} from '/workspace/trident/fidelity/cases.ts'
import {planFidelityCriteria} from '/workspace/trident/fidelity/ledger.ts'
import {docsInventory} from '/workspace/trident/unified/docs-benchmark.ts'
import {inventoryOriginalDeclarations} from '/workspace/trident/unified/upstream-fidelity-census.ts'
const out='/workspace/trident-b0-2026-10-29/freeze/inputs',portable=portableCases(),fidelity=expandedFidelityCases(),criteria=planFidelityCriteria(fidelity),docs=docsInventory('/workspace/.cloud-tools/mermaid'),upstream=inventoryOriginalDeclarations('/workspace/.cloud-tools/mermaid')
for(const [name,value] of Object.entries({portable,fidelity,criteria,docs,upstream}))writeFileSync(out+'/'+name+'.json',JSON.stringify(value,null,2)+'\n')
console.log(JSON.stringify({portable:portable.length,fidelityCases:fidelity.length,criteria:criteria.length,docsOccurrences:docs.occurrences,docsDistinct:docs.distinct,upstream:upstream.counts}))
