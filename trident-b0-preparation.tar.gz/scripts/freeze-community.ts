import {writeFileSync} from 'node:fs'
import {communityCoreWorkloads} from '/workspace/trident/unified/community.ts'
import {corpusWorkloads} from '/workspace/trident/unified/corpus.ts'
import {withReferenceLabels} from '/workspace/trident/unified/qualification.ts'
const enriched=await withReferenceLabels(corpusWorkloads('full'),{root:'/workspace/trident'})
const value={workloads:[...communityCoreWorkloads(),...enriched.workloads],reference:enriched.provenance??null,gaps:enriched.gaps}
writeFileSync('/workspace/trident-b0-2026-10-29/freeze/inputs/community-inputs.json',JSON.stringify(value,null,2)+'\n')
console.log('Frozen',value.workloads.length,'community inputs;',value.gaps.length,'reference expectation gaps')
