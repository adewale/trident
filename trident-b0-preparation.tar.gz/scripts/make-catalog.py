import copy,json,hashlib,subprocess
from pathlib import Path
root=Path('/workspace/trident');base=Path('/workspace/trident-b0-2026-10-29');r=json.loads((base/'freeze/artifact-resolution.json').read_text());cat=json.loads((root/'catalog/mermaid-community.json').read_text());ledger={x['project']:x for x in r['ledger']}
assert not r['errors'],r['errors']
for n in cat['nodes']:
 if n['id'] not in ledger:continue
 row=ledger[n['id']];d=row['resolution'];b=n['benchmark']
 if b.get('package'):
  b['version']=d['version'];b['versionPolicy']='recorded'
  for p in n.get('packages',[]):
   if p['registry']=='npm' and p['name']==b['package']:
    p['version']=d['version']
    for key in ['gitHead','provenanceCommit','provenanceCommit','publishedFromDefaultBranch']:p.pop(key,None)
    if d.get('gitHead'):p['gitHead']=d['gitHead']
 elif b['adapter'] in ['dart','native-flutter','termaid','bezel']:
  for p in n.get('packages',[]):p['version']=d['version']
  b['version']=d['version']
 elif b['adapter']=='franken':
  n['distribution']['revision']='d5ade10ac414a8c9eb07bd42b3df6a62c6474f6f'
  n['distribution'].pop('wasmSha256',None)
  row['adopted']={'version':'0.4.0','releaseCommit':n['distribution']['revision'],'policy':'public WASM directory at the stable v0.4.0 release commit, plus separately identified public CLI release'}
 elif b['adapter']=='source-cli':
  old=n.get('release',{});version=lambda s:tuple(map(int,s.lstrip('v').split('.')))
  if old and version(old['tag'])>=version(d['version']):
   row['adopted']={**old,'policy':'highest stable tag already recorded before cutoff; GitHub Release objects may lag tags'}
  else:raise RuntimeError('New source CLI release requires immutable tag resolution: '+n['id'])
(base/'freeze/catalog.json').write_text(json.dumps(cat,indent=2)+'\n')
r['stage']='registry and selection frozen; artifact admission pending';(base/'freeze/artifact-resolution.json').write_text(json.dumps(r,indent=2)+'\n')
provided={};selected=set(r['selectedProjects']);byid={n['id']:n for n in cat['nodes']}
for path in ['/workspace/trident-release/0.1/support-prepared-current.json','/workspace/trident-brand-split-review/prepared/prepared.json']:
 for row in json.loads(Path(path).read_text()):
  n=row['node'];a=row.get('artifact');b=byid.get(n['id'],{}).get('benchmark',{})
  if n['id'] not in selected or not a:continue
  if b.get('package') or b.get('adapter') in ['dart','termaid','bezel','native-flutter']:
   if a['version']!=b.get('version'):continue
  if b.get('adapter')=='franken':continue
  if b.get('adapter')=='extra-source' and a.get('sourceRevision')!=b.get('sourcePin'):continue
  if b.get('adapter')=='source-cli' and a.get('revision')!=byid[n['id']].get('release',{}).get('commit'):continue
  provided[n['id']]=a
(base/'freeze/provided-artifacts.json').write_text(json.dumps(provided,indent=2)+'\n')
(base/'freeze/preparation-policy.json').write_text(json.dumps({'baselineId':'ecosystem-b0','harnessRevision':r['harnessRevision'],'cutoff':r['cutoff'],'preparationBudgetMinutes':60,'pilotBudgetMinutes':30,'budgetBehavior':'Stop new preparation/pilot boundaries at the budget; active jobs retain their deadline; unfinished work stays incomplete. No baseline timing collection until the pilot sampling/budget decision is recorded.','pilotPurpose':'Estimate preparation/collection cost and repeatability; pilot observations are never B0 scores.','proposedPortableProfile':{'rounds':5,'samples':31,'coldSamples':5,'tailClaims':False},'collectionBudget':'pending pilot','reuse':'Immutable verified artifact bytes may be reused; historical measurements never supply B0 observations.'},indent=2)+'\n')
print('Catalog nodes:',len(cat['nodes']),'Selected:',len(selected),'Provisional reusable artifacts:',len(provided))
