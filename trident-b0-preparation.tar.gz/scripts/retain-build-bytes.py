from pathlib import Path
import hashlib,json,shutil
b=Path('/workspace/trident-b0-2026-10-29');out=b/'retained-builds';out.mkdir(exist_ok=True);rows=[]
def retain(project,a):
 if a.get('kind') in ['cli','global','franken']:
  files={str(Path(f['path'])) for f in a.get('files',[])}
  files.update(a[k] for k in ['executable','module','wasm'] if a.get(k))
  for p in sorted(files):
   source=Path(p)
   if not source.is_file():raise RuntimeError('Missing artifact '+p)
   digest=hashlib.sha256(source.read_bytes()).hexdigest();target=out/digest
   if not target.exists():shutil.copy2(source,target)
   rows.append({'project':project,'originalPath':p,'sha256':digest,'bytes':source.stat().st_size,'retained':digest})
 for c in a.get('additionalCli',[]):
  if c.get('artifact'):retain(project,c['artifact'])
for e in json.loads((b/'preparation-published/community-prepared.json').read_text()):retain(e['node']['id'],e['artifact'])
(out/'index.json').write_text(json.dumps({'scope':'Exact compiled CLI/Dart/WASM bytes and public release archives. Registry packages retain URLs/integrities and dependency/lock identities in freeze. Native Flutter bundle is retained at its separately linked immutable evidence commit. This preparation archive is not the final runnable B0 distribution.','nativeFlutterEvidence':'https://github.com/adewale/trident/tree/1a3be2b6bddde6d4d5cd9f5fa1ad525d77e9c30f','files':rows},indent=2)+'\n')
print('Retained',len(rows),'file bindings;',len(list(out.iterdir()))-1,'unique files')
