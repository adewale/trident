import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {prepareCommunity} from '/workspace/trident/unified/community.ts'
import {prepareCommunityBrowsers} from '/workspace/trident/unified/community-browser.ts'
const base='/workspace/trident-b0-2026-10-29',options={root:'/workspace/trident',harnessRoot:'/workspace/trident',out:base+'/crafter-preparation',communityProjects:['crafter-station/mermaid'],communityCatalogFile:base+'/freeze/catalog.json',communityArtifactPolicy:'frozen' as const,profile:'full' as const,rounds:5,executable:'/usr/bin/chromium'}
const replacement=await prepareCommunity(options);if(!replacement[0]?.artifact)throw Error(replacement[0]?.error)
const browsers=await prepareCommunityBrowsers(replacement,options),entries=JSON.parse(readFileSync(base+'/preparation/community-prepared.json','utf8')),oldBrowsers=JSON.parse(readFileSync(base+'/preparation/community-browser-prepared.json','utf8'))
mkdirSync(base+'/preparation-admitted',{recursive:true})
writeFileSync(base+'/preparation-admitted/community-prepared.json',JSON.stringify(entries.map((x:any)=>replacement.find(p=>p.node.id===x.node.id)??x),null,2)+'\n')
writeFileSync(base+'/preparation-admitted/community-browser-prepared.json',JSON.stringify(oldBrowsers.map((x:any)=>browsers.find(p=>p.node.id===x.node.id)??x),null,2)+'\n')
