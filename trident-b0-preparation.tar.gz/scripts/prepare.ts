import { readFileSync,writeFileSync } from 'node:fs'
import { prepareCommunity } from '/workspace/trident/unified/community.ts'
import { prepareCommunityBrowsers } from '/workspace/trident/unified/community-browser.ts'
const base='/workspace/trident-b0-2026-10-29', plan=JSON.parse(readFileSync(base+'/freeze/original-plan.json','utf8'))
const options={root:'/workspace/trident',harnessRoot:'/workspace/trident',out:base+'/preparation',communityProjects:plan.selection,communityCatalogFile:base+'/freeze/catalog.json',communityArtifacts:base+'/freeze/provided-artifacts.json',communityArtifactPolicy:'frozen' as const,profile:'full' as const,rounds:5,executable:'/usr/bin/chromium'}
const prepared=await prepareCommunity(options)
const browsers=await prepareCommunityBrowsers(prepared,options)
writeFileSync(base+'/preparation/summary.json',JSON.stringify({projects:prepared.length,artifactsReady:prepared.filter(x=>x.artifact).length,artifactFailures:prepared.filter(x=>!x.artifact).map(x=>({project:x.node.id,error:x.error})),browsersReady:browsers.filter(x=>x.browserStatus==='prepared').length,browserFailures:browsers.filter(x=>x.browserStatus==='blocked').map(x=>({project:x.node.id,error:x.browserDetail}))},null,2)+'\n')
