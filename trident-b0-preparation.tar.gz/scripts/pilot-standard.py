from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,time,hashlib
base=Path('/workspace/trident-b0-2026-10-29');harness=Path('/workspace/trident');out=base/'pilot-standard';out.mkdir(exist_ok=False)
prepared=json.loads((base/'preparation-admitted/community-prepared.json').read_text());plan=json.loads((base/'freeze/plan.json').read_text());eligible={r['project'] for r in plan['rows'] if r['suite']=='portable' and r['capability']['state']=='configured'}
entries=sorted([p for p in prepared if p['node']['id'] in eligible],key=lambda p:hashlib.sha256(('ecosystem-b0-pilot:'+p['node']['id']).encode()).hexdigest())
# Every project receives the small case before any project starts the scale case.
# This schedule is fixed before looking at pilot results.
schedule=[(case,p) for case in ['family:flowchart','scaling:class:128'] for p in entries]
policy={'mode':'pilot diagnostics only; never B0 scores','rounds':5,'warmSampleMeans':31,'coldProcessesPerReplicaRound':20,'budgetSeconds':1428,'maximumBoundarySeconds':360,'workerDeadlineMs':300000,'budgetBehavior':'SIGTERM cancels an unfinished pilot boundary at its recorded wall deadline; completed samples stay raw and no completed record is fabricated. No later boundary starts after overall exhaustion. This pilot cancellation budget differs from the ordinary campaign boundary-only budget.','scope':'Two explicit cases, ordered by a fixed SHA256 schedule seed; all projects get the small case before scaling. No full-portfolio score or tail claim.','schedule':[{'caseId':case,'project':p['node']['id']} for case,p in schedule],'harnessRevision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=harness,text=True).strip(),'startedAt':datetime.now(timezone.utc).isoformat()}
(out/'policy.json').write_text(json.dumps(policy,indent=2)+'\n');rows=[];started=time.monotonic()
for index,(case,p) in enumerate(schedule):
 elapsed=time.monotonic()-started;remaining=policy['budgetSeconds']-elapsed
 if remaining<=0:
  rows.extend({'caseId':c,'project':entry['node']['id'],'status':'not-started-budget-exhausted'} for c,entry in schedule[index:]);break
 n=p['node'];a=p.get('artifact');stem=f'{index:02d}-{n["id"].replace("/","--").replace(":","--")}';directory=out/stem
 if not a or not a.get('module') or not a.get('root'):
  rows.append({'caseId':case,'project':n['id'],'status':'artifact-unavailable','reason':p.get('error')});continue
 b=n['benchmark'];portable=b.get('portable',{});adapter=portable.get('adapter',b['adapter'])
 args=['bun',str(harness/'portable/run.ts'),'--project',n['id'],'--artifact-root',a['root'],'--entry',a['module'],'--adapter',adapter,'--out',str(directory),'--records',str(out/'records'),'--rounds','5','--samples','31','--cold-samples','20','--cases',case,'--observer','/workspace/.cloud-tools/gnu-time-root/usr/bin/time','--allow-partial']
 if adapter=='declared':args+=['--binding',json.dumps(portable.get('binding') or b['api']['svg'])]
 if adapter=='public-package':args+=['--public-config',json.dumps(b)]
 boundary=min(policy['maximumBoundarySeconds'],remaining);before=time.monotonic();timedout=False
 print('START',index+1,len(schedule),n['id'],case,'wallBudgetSeconds',round(boundary,1),flush=True)
 with (out/(stem+'.log')).open('w') as log:
  child=subprocess.Popen(args,cwd=harness,stdout=log,stderr=subprocess.STDOUT)
  try:code=child.wait(timeout=boundary)
  except subprocess.TimeoutExpired:
   timedout=True;child.terminate()
   try:code=child.wait(timeout=20)
   except subprocess.TimeoutExpired:child.kill();code=child.wait()
 report=directory/'report.json';result=json.loads(report.read_text()) if report.exists() else None
 row={'project':n['id'],'caseId':case,'seconds':time.monotonic()-before,'exitCode':code,'cancelledForBudget':timedout,'wallBudgetSeconds':boundary,'status':result.get('status') if result else 'no-report','report':str(report) if result else None,'command':args}
 if result and 'summary' in result:row['summary']=result['summary']
 rows.append(row);(out/'progress.json').write_text(json.dumps({'policy':policy,'elapsedSeconds':time.monotonic()-started,'rows':rows},indent=2)+'\n');print('END',n['id'],case,'seconds',round(row['seconds'],1),'exit',code,'cancelled',timedout,'status',row['status'],flush=True)
(out/'summary.json').write_text(json.dumps({'policy':policy,'finishedAt':datetime.now(timezone.utc).isoformat(),'elapsedSeconds':time.monotonic()-started,'rows':rows},indent=2)+'\n')
