import {writeFileSync,readFileSync,mkdirSync,copyFileSync} from 'node:fs'
import {qualifyOriginalRuntime} from '/workspace/trident/unified/upstream-runtime-qualification.ts'
const source='/workspace/trident-pr21-review/mermaid-original-source',runtime='/workspace/trident-pr21-review/mermaid-original-runtime',base='/workspace/trident-b0-2026-10-29/freeze/original-runner'
const qualification=qualifyOriginalRuntime(source,runtime,'node');mkdirSync(base,{recursive:true});writeFileSync(base+'/readiness.json',JSON.stringify({mode:'Current read-only environment qualification; not original-test execution or B0 scores',observedAt:new Date().toISOString(),source,runtime,qualification},null,2)+'\n')
for(const file of ['package.json','package-lock.json','preparation.json','canvas-install.log'])copyFileSync(runtime+'/'+file,base+'/'+file)
console.log('Original runner sealed closure and real Canvas/jsdom pixel checks verified; version',qualification.runnerVersion)
