import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { projectPackageIdentity } from '/workspace/trident/unified/project-update.ts'
import { verifyFrozenBrowserEngine } from '/workspace/trident/unified/community.ts'
const base='/workspace/trident-b0-2026-10-29',entries=JSON.parse(readFileSync(base+'/preparation-admitted/community-prepared.json','utf8')),browsers=JSON.parse(readFileSync(base+'/preparation-admitted/community-browser-prepared.json','utf8'))
mkdirSync(base+'/freeze/artifact-identities',{recursive:true})
const rows=[]
for(const entry of entries){const id=entry.node.id;try{const identity=projectPackageIdentity(entry),browser=browsers.find((b:any)=>b.node.id===id);if(browser)verifyFrozenBrowserEngine(browser);writeFileSync(base+'/freeze/artifact-identities/'+encodeURIComponent(id)+'.json',JSON.stringify({project:id,artifact:identity,browser:browser?.browser??null},null,2)+'\n');rows.push({project:id,version:entry.artifact?.version,identity:encodeURIComponent(id)+'.json'});console.log('sealed',id)}catch(error){const failure={project:id,status:'blocked-dependency-admission',error:String(error),artifact:entry.artifact};writeFileSync(base+'/freeze/artifact-identities/'+encodeURIComponent(id)+'.json',JSON.stringify(failure,null,2)+'\n');rows.push({project:id,status:'blocked-dependency-admission',identity:encodeURIComponent(id)+'.json'});console.log('blocked',id,String(error))}}
writeFileSync(base+'/freeze/artifact-identities/index.json',JSON.stringify(rows,null,2)+'\n')
