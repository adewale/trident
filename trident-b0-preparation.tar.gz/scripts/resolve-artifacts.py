from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime
import copy,json,re,subprocess,urllib.parse
root=Path('/workspace/trident'); out=Path('/workspace/trident-b0-2026-10-29/freeze'); raw=out/'registry';raw.mkdir(exist_ok=True)
cutoff='2026-10-29T18:42:38Z'; cutoff_dt=datetime.fromisoformat(cutoff.replace('Z','+00:00'))
catalog=json.loads((root/'catalog/mermaid-community.json').read_text()); plan=json.loads((out/'original-plan.json').read_text()); selected=set(plan['selection'])
nodes=[n for n in catalog['nodes'] if n['id'] in selected or n.get('benchmark',{}).get('skip')]
def stable(v):return bool(re.fullmatch(r'\d+\.\d+\.\d+',v))
def eligible(t):return bool(t) and datetime.fromisoformat(t.replace('Z','+00:00'))<=cutoff_dt
def fetch(kind,name,url):
 f=raw/(kind+'--'+urllib.parse.quote(name,safe='')+'.json')
 if f.exists():return json.loads(f.read_text()),str(f)
 cmd=['gh','api',url] if kind=='github' else ['curl','--fail','--silent','--show-error','--max-time','90','-H','User-Agent: Trident benchmark (https://github.com/adewale/trident)',url]
 run=subprocess.run(cmd,capture_output=True,text=True,timeout=100)
 if run.returncode:raise RuntimeError((run.stderr or run.stdout)[-800:])
 data=json.loads(run.stdout);f.write_text(json.dumps(data,ensure_ascii=False)+'\n');return data,str(f)
jobs={}
for n in nodes:
 b=n.get('benchmark',{})
 if b.get('package'):jobs[('npm',b['package'])]='https://registry.npmjs.org/'+urllib.parse.quote(b['package'],safe='')
 elif b.get('adapter') in ['dart','native-flutter']:
  name='mermaid_core' if b['adapter']=='dart' else 'mermaid_flutter';jobs[('pub',name)]='https://pub.dev/api/packages/'+name
 elif b.get('adapter')=='termaid':jobs[('pypi','termaid')]='https://pypi.org/pypi/termaid/json'
 elif b.get('adapter')=='bezel':jobs[('crates','bezel-mermaid')]='https://crates.io/api/v1/crates/bezel-mermaid'
 elif b.get('adapter') in ['source-cli','franken']:jobs[('github',n['id'])]='repos/'+n['id']+'/releases?per_page=100'
resolved={};errors=[]
def resolve(key,url):
 kind,name=key; data,path=fetch(kind,name,url)
 if kind=='npm':
  versions=[v for v in data['versions'] if stable(v) and eligible(data.get('time',{}).get(v))];version=max(versions,key=lambda v:tuple(map(int,v.split('.'))));d=data['versions'][version]
  row={'registry':kind,'package':name,'version':version,'published':data['time'][version],'dist':d.get('dist'),'gitHead':d.get('gitHead'),'deprecated':d.get('deprecated'),'currentDistTags':data.get('dist-tags'),'selection':'highest stable semantic version published no later than cutoff','metadata':path}
 elif kind=='pub':
  versions=[v for v in data['versions'] if stable(v['version']) and eligible(v.get('published'))];v=max(versions,key=lambda v:tuple(map(int,v['version'].split('.'))));row={'registry':kind,'package':name,**{k:v.get(k) for k in ['version','published','archive_url','archive_sha256','pubspec']},'metadata':path}
 elif kind=='pypi':
  versions=[v for v,fs in data['releases'].items() if stable(v) and any(eligible(f.get('upload_time_iso_8601')) for f in fs)];v=max(versions,key=lambda v:tuple(map(int,v.split('.'))));row={'registry':kind,'package':name,'version':v,'files':data['releases'][v],'metadata':path}
 elif kind=='crates':
  versions=[v for v in data['versions'] if stable(v['num']) and eligible(v['created_at'])];v=max(versions,key=lambda v:tuple(map(int,v['num'].split('.'))));row={'registry':kind,'package':name,'version':v['num'],'published':v['created_at'],'checksum':v['checksum'],'yanked':v['yanked'],'metadata':path}
 else:
  versions=[v for v in data if not v['draft'] and not v['prerelease'] and eligible(v.get('published_at'))]
  if not versions:row={'registry':'github','repository':name,'selection':'no stable GitHub release before cutoff','metadata':path}
  else:
   v=max(versions,key=lambda v:v['published_at']);row={'registry':'github','repository':name,'version':v['tag_name'],'published':v['published_at'],'target_commitish':v['target_commitish'],'assets':[{k:a[k] for k in ['name','size','browser_download_url','digest']} for a in v['assets']],'metadata':path}
 return key,row
with ThreadPoolExecutor(max_workers=5) as pool:
 futures={pool.submit(resolve,key,url):key for key,url in jobs.items()}
 for future in as_completed(futures):
  key=futures[future]
  try:
   k,r=future.result();resolved[':'.join(k)]=r;print(k[0],k[1],r.get('version',r['selection'] if 'selection' in r else 'unknown'),flush=True)
  except Exception as e:errors.append({'key':key,'error':str(e)});print('ERROR',key,str(e),flush=True)
ledger=[]
for n in nodes:
 b=n.get('benchmark',{});key=('npm:'+b['package']) if b.get('package') else ('pub:'+('mermaid_core' if b['adapter']=='dart' else 'mermaid_flutter')) if b.get('adapter') in ['dart','native-flutter'] else 'pypi:termaid' if b.get('adapter')=='termaid' else 'crates:bezel-mermaid' if b.get('adapter')=='bezel' else 'github:'+n['id'] if b.get('adapter') in ['source-cli','franken'] else None
 ledger.append({'project':n['id'],'normallySelected':n['id'] in selected,'adapter':b.get('adapter'),'resolutionKey':key,'resolution':resolved.get(key) if key else {'selection':'recorded immutable source pin; no separately published benchmark component bound','revision':b.get('sourcePin')},'originalBenchmark':b,'originalPackages':n.get('packages'),'originalRelease':n.get('release'),'originalDistribution':n.get('distribution')})
record={'baselineId':'ecosystem-b0','stage':'artifact-resolution; artifacts not yet admitted','cutoff':cutoff,'harnessRevision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'selectedProjects':plan['selection'],'selection':plan['comparisonSelection'],'ledger':ledger,'errors':errors}
(out/'artifact-resolution.json').write_text(json.dumps(record,indent=2)+'\n')
print('DONE:',len(ledger),'projects,',len(resolved),'registry/release resolutions,',len(errors),'errors',flush=True)
