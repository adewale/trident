import {readFileSync} from 'node:fs'
import {verifySupport} from '/workspace/trident/unified/support-verification.ts'
const base='/workspace/trident-b0-2026-10-29',plan=JSON.parse(readFileSync(base+'/freeze/plan.json','utf8'))
await verifySupport(base+'/preparation/community-prepared.json',base+'/public-admission',{projects:plan.selection,catalog:base+'/freeze/catalog.json',browserPrepared:base+'/preparation/community-browser-prepared.json',executable:'/usr/bin/chromium'})
