from pathlib import Path
import json,hashlib,subprocess,shutil
b=Path('/workspace/trident-b0-2026-10-29');o=Path('/workspace/trident-b0-publication');o.mkdir(exist_ok=True)
items=json.loads((b/'archive-items.json').read_text());paths=[]
for item in items:
 if item=='CONTENTS.sha256':continue
 p=b/item;paths.extend([p] if p.is_file() else sorted(f for f in p.rglob('*') if f.is_file()))
assert not any(p.is_symlink() for p in paths)
(b/'CONTENTS.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(b))+'\n' for p in paths))
subprocess.run(['tar','-czf',str(o/'trident-b0-preparation.tar.gz'),'-C',str(b),*items],check=True)
for src,dst in [('PREPARATION.md','README.md'),('freeze/sampling-decision.json','sampling-decision.json'),('freeze/pilot-summary.json','pilot-summary.json')]:shutil.copy2(b/src,o/dst)
p=o/'README.md';s=p.read_text();s=s.replace('## Freeze', 'Download [the evidence archive](trident-b0-preparation.tar.gz), verify [SHA256SUMS](SHA256SUMS), then extract it and run `sha256sum -c CONTENTS.sha256`. Paths below refer to the extracted archive. The sampling decision and pilot summary also have JSON previews alongside this page.\n\n## Freeze',1)
for n in [57,58,59]:s=s.replace('PR'+str(n)+' ', '[PR #'+str(n)+'](https://github.com/adewale/trident/pull/'+str(n)+') ')
p.write_text(s)
(o/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(o.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print('Packaged',len(paths),'files;', (o/'trident-b0-preparation.tar.gz').stat().st_size,'archive bytes')
