import {readFileSync,writeFileSync,mkdirSync} from 'node:fs'
import {prepareCommunity} from '/workspace/trident/unified/community.ts'
import {projectPackageIdentity} from '/workspace/trident/unified/project-update.ts'
const base='/workspace/trident-b0-2026-10-29',options={root:'/workspace/trident',harnessRoot:'/workspace/trident',out:base+'/opencode-preparation',communityProjects:['anomalyco/opencode'],communityCatalogFile:base+'/freeze/catalog.json',communityArtifactPolicy:'frozen' as const,profile:'full' as const,rounds:5}
const replacement=await prepareCommunity(options);if(!replacement[0]?.artifact)throw Error(replacement[0]?.error)
const identity=projectPackageIdentity(replacement[0]);writeFileSync(base+'/opencode-preparation/dependency-identity.json',JSON.stringify(identity,null,2)+'\n')
const entries=JSON.parse(readFileSync(base+'/preparation-admitted/community-prepared.json','utf8')),browsers=JSON.parse(readFileSync(base+'/preparation-admitted/community-browser-prepared.json','utf8'))
mkdirSync(base+'/preparation-final',{recursive:true})
writeFileSync(base+'/preparation-final/community-prepared.json',JSON.stringify(entries.map((x:any)=>replacement.find(p=>p.node.id===x.node.id)??x),null,2)+'\n')
writeFileSync(base+'/preparation-final/community-browser-prepared.json',JSON.stringify(browsers.map((x:any)=>x.node.id==='anomalyco/opencode'?{...x,...replacement[0]}:x),null,2)+'\n')
console.log('Sealed actual OpenCode runtime package roots:',replacement[0].artifact.runtimeDependencyRoots?.length)
